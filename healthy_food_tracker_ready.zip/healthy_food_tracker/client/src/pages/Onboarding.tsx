import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  ChevronLeft,
  Flame,
  Leaf,
  Loader2,
  Ruler,
  Scale,
  Scan,
  ScanSearch,
  Sparkles,
  Target,
  Trophy,
  User,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

function calculateBMRClient(gender: string, weight: number, height: number, age: number): number {
  const base = 10 * weight + 6.25 * height - 5 * age;
  return Math.round(gender === "male" ? base + 5 : base - 161);
}

const ACTIVITY_MULTIPLIERS: Record<string, number> = {
  sedentary: 1.2, lightly_active: 1.375, moderately_active: 1.55, very_active: 1.725, extra_active: 1.9,
};

function calculateTDEEClient(bmr: number, activityLevel: string): number {
  return Math.round(bmr * (ACTIVITY_MULTIPLIERS[activityLevel] ?? 1.2));
}

function calculateCalorieTargetClient(tdee: number, goal: string): number {
  if (goal === "lose_weight") return Math.max(1200, tdee - 500);
  if (goal === "gain_muscle") return tdee + 300;
  return tdee;
}

const GOALS = [
  { value: "lose_weight", label: "Lose weight", icon: "🔥", desc: "Calorie deficit tailored to you" },
  { value: "maintain", label: "Stay healthy", icon: "⚖️", desc: "Maintain weight, improve nutrition" },
  { value: "gain_muscle", label: "Build muscle", icon: "💪", desc: "Calorie surplus for muscle gain" },
];

const ACTIVITY_LEVELS = [
  { value: "sedentary", label: "Sedentary", icon: "🪑", desc: "Little or no exercise" },
  { value: "lightly_active", label: "Lightly active", icon: "🚶", desc: "Light exercise 1–3 days/week" },
  { value: "moderately_active", label: "Moderately active", icon: "🏃", desc: "Moderate exercise 3–5 days/week" },
  { value: "very_active", label: "Very active", icon: "🏋️", desc: "Hard exercise 6–7 days/week" },
  { value: "extra_active", label: "Extra active", icon: "⚡", desc: "Very hard exercise + physical job" },
];

const STEP_LABELS = ["Goal", "Body", "Activity", "Ready"];

function OptionCard({ selected, onClick, icon, title, desc }: {
  selected: boolean; onClick: () => void; icon: string; title: string; desc: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
        selected ? "border-primary bg-primary/5 shadow-sm" : "border-border bg-card hover:border-primary/40"
      }`}
    >
      <span className="text-3xl">{icon}</span>
      <div className="flex-1">
        <p className="font-semibold text-foreground text-sm">{title}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
      </div>
      {selected && <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />}
    </button>
  );
}

function ProgressDots({ total, current }: { total: number; current: number }) {
  return (
    <div className="flex items-center justify-center gap-1.5">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className="h-1.5 rounded-full transition-all duration-300"
          style={{
            width: i === current ? 24 : 8,
            background: i <= current ? "var(--primary)" : "var(--muted)",
            opacity: i < current ? 0.5 : 1,
          }}
        />
      ))}
    </div>
  );
}

export default function Onboarding() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<number>(-1);
  const [goal, setGoal] = useState<"lose_weight" | "maintain" | "gain_muscle">("maintain");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [activityLevel, setActivityLevel] = useState<
    "sedentary" | "lightly_active" | "moderately_active" | "very_active" | "extra_active"
  >("moderately_active");

  const saveProfile = trpc.profile.save.useMutation({
    onSuccess: () => navigate("/dashboard?tour=1"),
    onError: (e) => toast.error(e.message),
  });

  const ageNum = parseInt(age) || 0;
  const weightNum = parseFloat(weight) || 0;
  const heightNum = parseFloat(height) || 0;

  const bmr = ageNum && weightNum && heightNum
    ? calculateBMRClient(gender, weightNum, heightNum, ageNum) : 0;
  const tdee = bmr ? calculateTDEEClient(bmr, activityLevel) : 0;
  const calorieTarget = tdee ? calculateCalorieTargetClient(tdee, goal) : 0;
  const proteinTarget = calorieTarget ? Math.round((calorieTarget * 0.25) / 4) : 0;

  const canProceedStep2 =
    ageNum >= 10 && ageNum <= 120 && weightNum >= 20 && weightNum <= 400 && heightNum >= 100 && heightNum <= 250;

  const handleFinish = () => {
    if (!canProceedStep2) { toast.error("Please fill in all body data correctly"); return; }
    saveProfile.mutate({ gender, age: ageNum, weight: weightNum, height: heightNum, activityLevel, goal });
  };

  // ── SPLASH ──────────────────────────────────────────────────
  if (step === -1) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-emerald-50/30 flex flex-col items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm flex flex-col items-center">
          <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mb-5">
            <Leaf className="w-10 h-10 text-primary" />
          </div>
          <p className="text-xs font-semibold tracking-widest text-primary uppercase mb-3">
            Healthy Food Tracker
          </p>
          <h1 className="text-3xl font-bold text-foreground text-center leading-tight mb-3">
            Eat smart,<br />feel great
          </h1>
          <p className="text-sm text-muted-foreground text-center leading-relaxed mb-8 max-w-xs">
            Track calories, scan food instantly, and hit your goals — all in one place.
          </p>
          <div className="w-full flex flex-col gap-2 mb-8">
            {[
              { Icon: Scan, text: "Scan barcodes & AI food photos" },
              { Icon: ScanSearch, text: "Personalised calorie & macro targets" },
              { Icon: Trophy, text: "Streaks, challenges & rewards" },
            ].map(({ Icon, text }) => (
              <div key={text} className="flex items-center gap-3 bg-card border border-border rounded-xl px-4 py-3">
                <Icon className="w-4 h-4 text-primary shrink-0" />
                <span className="text-sm text-foreground">{text}</span>
              </div>
            ))}
          </div>
          <Button className="w-full h-12 text-base gap-2" onClick={() => setStep(0)}>
            Get started <ArrowRight className="w-4 h-4" />
          </Button>
          <p className="text-xs text-muted-foreground mt-4">Takes about 2 minutes to set up</p>
        </div>
      </div>
    );
  }

  // ── STEPS ───────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-emerald-50/30 flex flex-col">
      <div className="px-4 pt-8 pb-4 max-w-lg mx-auto w-full">
        <div className="flex items-center justify-between mb-5">
          <button
            onClick={() => setStep((s) => s - 1)}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
          <span className="text-xs text-muted-foreground font-medium">
            Step {step + 1} of {STEP_LABELS.length}
          </span>
        </div>
        <ProgressDots total={STEP_LABELS.length} current={step} />
        <div className="flex justify-between mt-2">
          {STEP_LABELS.map((s, i) => (
            <span key={s} className={`text-[10px] font-medium ${i <= step ? "text-primary" : "text-muted-foreground"}`}>{s}</span>
          ))}
        </div>
      </div>

      <div className="flex-1 px-4 pb-8 max-w-lg mx-auto w-full">

        {/* Step 0: Goal */}
        {step === 0 && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">What's your goal?</h1>
              <p className="text-muted-foreground mt-1 text-sm">We'll personalise your calorie target and recommendations.</p>
            </div>
            <div className="space-y-3">
              {GOALS.map((g) => (
                <OptionCard key={g.value} selected={goal === g.value} onClick={() => setGoal(g.value as typeof goal)}
                  icon={g.icon} title={g.label} desc={g.desc} />
              ))}
            </div>
            <Button onClick={() => setStep(1)} className="w-full h-12 text-base gap-2">
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 1: Body Data */}
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Your body data</h1>
              <p className="text-muted-foreground mt-1 text-sm">Used to calculate your personalised daily calorie target.</p>
            </div>
            <div className="space-y-2">
              <Label>Biological sex</Label>
              <div className="grid grid-cols-2 gap-3">
                {[{ value: "male", label: "Male", icon: "♂️" }, { value: "female", label: "Female", icon: "♀️" }].map((g) => (
                  <button key={g.value} type="button" onClick={() => setGender(g.value as "male" | "female")}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border-2 font-medium transition-all text-sm ${
                      gender === g.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
                    }`}>
                    <span>{g.icon}</span> {g.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: "Age", Icon: User, placeholder: "25", value: age, onChange: setAge, unit: "years" },
                { label: "Weight", Icon: Scale, placeholder: "70", value: weight, onChange: setWeight, unit: "kg" },
                { label: "Height", Icon: Ruler, placeholder: "175", value: height, onChange: setHeight, unit: "cm" },
              ].map(({ label, Icon, placeholder, value, onChange, unit }) => (
                <div key={label} className="space-y-1.5">
                  <Label className="flex items-center gap-1.5"><Icon className="w-3.5 h-3.5" /> {label}</Label>
                  <Input type="number" placeholder={placeholder} value={value}
                    onChange={(e) => onChange(e.target.value)} className="text-center" />
                  <p className="text-[10px] text-muted-foreground text-center">{unit}</p>
                </div>
              ))}
            </div>
            {bmr > 0 && (
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-2">Your estimates</p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Basal Metabolic Rate</span>
                  <span className="font-semibold text-foreground">{bmr.toLocaleString()} kcal</span>
                </div>
                <p className="text-[11px] text-muted-foreground mt-1">We'll refine this with your activity level next.</p>
              </div>
            )}
            <Button onClick={() => setStep(2)} disabled={!canProceedStep2} className="w-full h-12 text-base gap-2">
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 2: Activity */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h1 className="text-2xl font-bold text-foreground">How active are you?</h1>
              <p className="text-muted-foreground mt-1 text-sm">Choose your typical weekly activity level.</p>
            </div>
            <div className="space-y-2">
              {ACTIVITY_LEVELS.map((a) => (
                <OptionCard key={a.value} selected={activityLevel === a.value}
                  onClick={() => setActivityLevel(a.value as typeof activityLevel)}
                  icon={a.icon} title={a.label} desc={a.desc} />
              ))}
            </div>
            {tdee > 0 && (
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-3">Your calorie plan</p>
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <p className="text-xl font-bold text-foreground">{tdee.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">TDEE (kcal)</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{calorieTarget.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Daily target</p>
                  </div>
                </div>
              </div>
            )}
            <Button onClick={() => setStep(3)} className="w-full h-12 text-base gap-2">
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 3: Ready */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center py-2">
              <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-2xl font-bold text-foreground">You're all set!</h1>
              <p className="text-muted-foreground mt-2 text-sm">Here's your personalised nutrition plan:</p>
            </div>
            {calorieTarget > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {[
                  { Icon: Flame, label: "Daily calories", value: `${calorieTarget.toLocaleString()} kcal`, color: "text-orange-500", bg: "bg-orange-50" },
                  { Icon: Zap, label: "Protein target", value: `${proteinTarget}g`, color: "text-purple-500", bg: "bg-purple-50" },
                  { Icon: Target, label: "Your goal", value: GOALS.find((g) => g.value === goal)?.label ?? "", color: "text-primary", bg: "bg-primary/5" },
                  { Icon: Activity, label: "Activity level", value: ACTIVITY_LEVELS.find((a) => a.value === activityLevel)?.label ?? "", color: "text-blue-500", bg: "bg-blue-50" },
                ].map(({ Icon, label, value, color, bg }) => (
                  <div key={label} className={`${bg} rounded-2xl p-4`}>
                    <Icon className={`w-5 h-5 ${color} mb-2`} />
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className={`font-bold text-sm ${color} mt-0.5`}>{value}</p>
                  </div>
                ))}
              </div>
            )}
            <div className="bg-card border border-dashed border-primary/30 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-sm text-foreground">We'll give you a quick dashboard tour</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    A 4-step guided tour will show you how to log meals, track water, and keep your streak going.
                  </p>
                </div>
              </div>
            </div>
            <Button onClick={handleFinish} disabled={saveProfile.isPending} className="w-full h-12 text-base gap-2">
              {saveProfile.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Go to dashboard <ArrowRight className="w-4 h-4" /></>}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
