import DashboardLayout from "@/components/DashboardLayout";
import { TutorialOverlay, useShouldShowTutorial } from "@/components/TutorialOverlay";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  Apple,
  Camera,
  Coffee,
  Flame,
  Moon,
  Plus,
  Sun,
  TrendingUp,
  Utensils,
  Zap,
  User,
  ScanBarcode,
  Brain,
  Search,
  Heart,
  Droplets,
  Weight,
  Trophy,
  Watch,
  CalendarDays,
  Users,
  Swords,
  Star,
  BookOpen,
} from "lucide-react";
import { useState } from "react";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useLocation } from "wouter";
import { NutriScoreBadge } from "../components/NutriScoreBadge";
import { toast } from "sonner";

const SCORE_COLORS: Record<string, string> = {
  A: "oklch(0.5 0.18 145)",
  B: "oklch(0.6 0.15 130)",
  C: "oklch(0.7 0.16 85)",
  D: "oklch(0.62 0.18 45)",
  E: "oklch(0.52 0.22 25)",
};

const MEAL_CONFIG = [
  { key: "breakfast", label: "Breakfast", icon: Coffee, color: "text-amber-500", bg: "bg-amber-50", border: "border-amber-200" },
  { key: "lunch",     label: "Lunch",     icon: Sun,    color: "text-orange-500", bg: "bg-orange-50", border: "border-orange-200" },
  { key: "dinner",    label: "Dinner",    icon: Moon,   color: "text-indigo-500", bg: "bg-indigo-50", border: "border-indigo-200" },
  { key: "snacks",    label: "Snacks",    icon: Apple,  color: "text-green-600",  bg: "bg-green-50",  border: "border-green-200" },
] as const;

type MealKey = "breakfast" | "lunch" | "dinner" | "snacks";

// Calorie progress ring (SVG)
function CalorieRing({ consumed, target }: { consumed: number; target: number | null }) {
  const pct = target ? Math.min(consumed / target, 1) : 0;
  const r = 54;
  const circ = 2 * Math.PI * r;
  const dash = pct * circ;
  const over = consumed > (target ?? Infinity);

  return (
    <div className="relative flex items-center justify-center" style={{ width: 140, height: 140 }}>
      <svg width={140} height={140} className="-rotate-90">
        <circle cx={70} cy={70} r={r} fill="none" stroke="var(--muted)" strokeWidth={12} />
        <circle
          cx={70} cy={70} r={r} fill="none"
          stroke={over ? "oklch(0.52 0.22 25)" : "oklch(0.42 0.15 145)"}
          strokeWidth={12}
          strokeDasharray={`${dash} ${circ}`}
          strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-xl font-bold text-foreground leading-tight">{consumed.toLocaleString()}</span>
        <span className="text-xs text-muted-foreground">kcal</span>
        {target && (
          <span className={`text-xs font-medium mt-0.5 ${over ? "text-destructive" : "text-primary"}`}>
            {over ? `+${(consumed - target).toLocaleString()}` : `${(target - consumed).toLocaleString()} left`}
          </span>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: todayLogs, isLoading: logsLoading, refetch } = trpc.consumption.getToday.useQuery();
  const { data: profile } = trpc.profile.get.useQuery();
  const { show: showTutorial, dismiss: dismissTutorial } = useShouldShowTutorial();

  const deleteMutation = trpc.consumption.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("Entry removed"); },
    onError: () => toast.error("Failed to remove entry"),
  });
  const updateMutation = trpc.consumption.update.useMutation({
    onSuccess: () => { refetch(); toast.success("Updated"); },
    onError: () => toast.error("Failed to update"),
  });

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editQty, setEditQty] = useState(1);

  const scoreData = stats
    ? Object.entries(stats.today.scoreCounts).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value }))
    : [];

  const weeklyData = stats
    ? Object.entries(stats.weeklyCalories)
        .sort(([a], [b]) => a.localeCompare(b))
        .slice(-7)
        .map(([date, calories]) => ({
          date: new Date(date).toLocaleDateString("en", { weekday: "short" }),
          calories: Math.round(calories as number),
          target: stats.calorieTarget ?? undefined,
        }))
    : [];

  // Group today's logs by meal type
  const logsByMeal: Record<MealKey, typeof todayLogs> = {
    breakfast: [], lunch: [], dinner: [], snacks: [],
  };
  if (todayLogs) {
    for (const entry of todayLogs) {
      const meal = (entry.log.mealType ?? "snacks") as MealKey;
      logsByMeal[meal]?.push(entry);
    }
  }

  const calorieTarget = stats?.calorieTarget ?? null;
  const macroTargets = stats?.macroTargets ?? null;
  const consumed = stats?.today.totalCalories ?? 0;

  // Mobile icon grid config
  const iconGroups = [
    {
      label: "Log Food",
      items: [
        { icon: ScanBarcode, label: "Scan Barcode", route: "/scan/barcode", color: "bg-green-100 text-green-700" },
        { icon: Brain,       label: "AI Scanner",  route: "/scan/photo",   color: "bg-purple-100 text-purple-700" },
        { icon: Search,      label: "Search Food", route: "/search",        color: "bg-blue-100 text-blue-700" },
        { icon: Star,        label: "Favourites",  route: "/favourites",   color: "bg-yellow-100 text-yellow-700" },
        { icon: BookOpen,    label: "Recipes",     route: "/recipes",      color: "bg-orange-100 text-orange-700" },
        { icon: CalendarDays,label: "Meal Plan",   route: "/meal-plan",    color: "bg-teal-100 text-teal-700" },
        { icon: Plus,        label: "Add Product", route: "/products/new", color: "bg-indigo-100 text-indigo-700" },
      ],
    },
    {
      label: "Health",
      items: [
        { icon: Droplets,    label: "Water",       route: "/water",        color: "bg-sky-100 text-sky-700" },
        { icon: Activity,    label: "Weight",      route: "/weight",       color: "bg-rose-100 text-rose-700" },
        { icon: Trophy,      label: "Streaks",     route: "/streaks",      color: "bg-amber-100 text-amber-700" },
        { icon: Watch,       label: "Wearable",    route: "/wearable",     color: "bg-cyan-100 text-cyan-700" },
      ],
    },
    {
      label: "Social",
      items: [
        { icon: Users,       label: "Friends",     route: "/friends",      color: "bg-pink-100 text-pink-700" },
        { icon: Swords,      label: "Challenges",  route: "/challenges",   color: "bg-violet-100 text-violet-700" },
        { icon: Heart,       label: "History",     route: "/history",      color: "bg-red-100 text-red-700" },
      ],
    },
  ];

  const macroCards = stats
    ? [
        { label: "Calories", value: stats.today.totalCalories, target: calorieTarget, unit: "kcal", icon: Flame, color: "text-orange-500", bg: "bg-orange-50" },
        { label: "Protein",  value: stats.today.totalProteins, target: macroTargets?.proteins ?? null, unit: "g", icon: Zap, color: "text-blue-500", bg: "bg-blue-50" },
        { label: "Carbs",    value: stats.today.totalCarbs, target: macroTargets?.carbohydrates ?? null, unit: "g", icon: Activity, color: "text-yellow-600", bg: "bg-yellow-50" },
        { label: "Fat",      value: stats.today.totalFat, target: macroTargets?.fat ?? null, unit: "g", icon: TrendingUp, color: "text-red-500", bg: "bg-red-50" },
      ]
    : [];

  return (
    <DashboardLayout>
      {showTutorial && <TutorialOverlay onDone={dismissTutorial} />}
      <div className="p-6 space-y-6 max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-0.5">
              {new Date().toLocaleDateString("en", { weekday: "long", month: "long", day: "numeric" })}
            </p>
          </div>
          <Button onClick={() => navigate("/scan")} className="gap-2">
            <Camera className="w-4 h-4" />
            Scan Product
          </Button>
        </div>

        {/* Profile prompt if no profile */}
        {!isLoading && !profile && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-4 pb-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-primary shrink-0" />
                <div>
                  <p className="text-sm font-medium text-foreground">Set up your profile to get personalised calorie targets</p>
                  <p className="text-xs text-muted-foreground">Enter your body data and activity level to unlock daily goals.</p>
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={() => navigate("/profile")} className="shrink-0">
                Set Up Profile
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Calorie Progress + Macro Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-start">
          {/* Calorie Ring */}
          <Card id="tutorial-calorie-ring" className="border-border/60 lg:col-span-1 flex flex-col items-center justify-center py-4">
            {isLoading ? (
              <Skeleton className="w-[140px] h-[140px] rounded-full" />
            ) : (
              <>
                <CalorieRing consumed={consumed} target={calorieTarget} />
                {calorieTarget && (
                  <p className="text-xs text-muted-foreground mt-2">
                    of {calorieTarget.toLocaleString()} kcal goal
                  </p>
                )}
              </>
            )}
          </Card>

          {/* Macro Cards */}
          <div className="lg:col-span-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {isLoading
              ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
              : macroCards.map((m) => (
                  <Card key={m.label} className="border-border/60">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">{m.label}</span>
                        <div className={`w-8 h-8 rounded-lg ${m.bg} flex items-center justify-center`}>
                          <m.icon className={`w-4 h-4 ${m.color}`} />
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-foreground">
                        {m.value}
                        <span className="text-sm font-normal text-muted-foreground ml-1">{m.unit}</span>
                      </div>
                      {m.target && (
                        <div className="mt-2 space-y-1">
                          <Progress
                            value={Math.min((m.value / m.target) * 100, 100)}
                            className="h-1.5"
                          />
                          <p className="text-xs text-muted-foreground">
                            {m.target} {m.unit} goal
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
          </div>
        </div>

        {/* Mobile Quick-Access Icon Grid — hidden on lg+ */}
        <div id="tutorial-scan-btn" className="block lg:hidden">
          <div className="space-y-4">
            {iconGroups.map((group) => (
              <div key={group.label}>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-0.5">{group.label}</h3>
                <div className="grid grid-cols-4 gap-2">
                  {group.items.map(({ icon: Icon, label, route, color }) => (
                    <button
                      key={route}
                      onClick={() => navigate(route)}
                      className="flex flex-col items-center gap-1.5 p-2 rounded-xl active:scale-95 transition-transform duration-150 hover:bg-muted/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                    >
                      <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center shadow-sm`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-[10px] font-medium text-foreground leading-tight text-center">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Meal Breakdown */}
        <div id="tutorial-meal-cards">
          <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
            <Utensils className="w-4 h-4 text-primary" /> Today's Meals
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {MEAL_CONFIG.map(({ key, label, icon: Icon, color, bg, border }) => {
              const entries = logsByMeal[key] ?? [];
              const mealCal = entries.reduce((sum, { log, product }) => sum + (product.calories ?? 0) * log.quantity, 0);
              const mealTarget = calorieTarget ? Math.round(calorieTarget * (
                key === "breakfast" ? 0.25 : key === "lunch" ? 0.35 : key === "dinner" ? 0.30 : 0.10
              )) : null;

              return (
                <Card key={key} className={`border ${border} ${bg}`}>
                  <CardHeader className="pb-2 pt-4 px-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-4 h-4 ${color}`} />
                        <span className="font-semibold text-sm text-foreground">{label}</span>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 rounded-full"
                        onClick={() => navigate(`/scan?meal=${key}`)}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="px-4 pb-4 space-y-2">
                    <div className="flex items-baseline gap-1">
                      <span className={`text-xl font-bold ${color}`}>{Math.round(mealCal)}</span>
                      <span className="text-xs text-muted-foreground">
                        kcal{mealTarget ? ` / ${mealTarget}` : ""}
                      </span>
                    </div>
                    {mealTarget && (
                      <Progress value={Math.min((mealCal / mealTarget) * 100, 100)} className="h-1" />
                    )}
                    {logsLoading ? (
                      <Skeleton className="h-8 w-full rounded" />
                    ) : entries.length === 0 ? (
                      <p className="text-xs text-muted-foreground italic">Nothing logged yet</p>
                    ) : (
                      <div className="space-y-1">
                        {entries.slice(0, 3).map(({ log, product }) => (
                          <div key={log.id} className="flex items-center gap-1.5 text-xs">
                            <NutriScoreBadge score={product.nutriScore} size="sm" />
                            <span className="truncate text-foreground flex-1">{product.name}</span>
                            <span className="text-muted-foreground shrink-0">
                              {product.calories != null ? `${Math.round(product.calories * log.quantity)} kcal` : ""}
                            </span>
                          </div>
                        ))}
                        {entries.length > 3 && (
                          <p className="text-xs text-muted-foreground">+{entries.length - 3} more</p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Charts Row */}
        <div id="tutorial-water-streak" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Weekly Calories</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-40 w-full" />
              ) : weeklyData.length > 0 ? (
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={weeklyData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", fontSize: 12 }}
                      formatter={(v: number) => [`${v} kcal`, "Calories"]}
                    />
                    <Bar dataKey="calories" fill="oklch(0.42 0.15 145)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">
                  No data yet — start scanning!
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Today's Health Scores</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-40 w-full" />
              ) : scoreData.length > 0 ? (
                <div className="flex items-center gap-4">
                  <ResponsiveContainer width="50%" height={160}>
                    <PieChart>
                      <Pie data={scoreData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={3}>
                        {scoreData.map((entry) => (
                          <Cell key={entry.name} fill={SCORE_COLORS[entry.name] ?? "#ccc"} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", fontSize: 12 }}
                        formatter={(v: number, name: string) => [v, `Score ${name}`]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2">
                    {scoreData.map((s) => (
                      <div key={s.name} className="flex items-center gap-2">
                        <NutriScoreBadge score={s.name as "A" | "B" | "C" | "D" | "E"} size="sm" />
                        <span className="text-sm text-muted-foreground">{s.value} item{s.value !== 1 ? "s" : ""}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">
                  No items logged today
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Full Today's Log */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <Utensils className="w-4 h-4 text-primary" />
                Full Today's Log
                {todayLogs && (
                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-normal">
                    {todayLogs.length} item{todayLogs.length !== 1 ? "s" : ""}
                  </span>
                )}
              </CardTitle>
              <Button variant="outline" size="sm" onClick={() => navigate("/scan")} className="gap-1 text-xs">
                <Plus className="w-3 h-3" /> Add
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {logsLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-lg" />)}
              </div>
            ) : !todayLogs || todayLogs.length === 0 ? (
              <div className="py-12 text-center">
                <Apple className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">No items logged today</p>
                <Button variant="outline" size="sm" className="mt-4" onClick={() => navigate("/scan")}>
                  <Camera className="w-4 h-4 mr-2" />
                  Scan your first product
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {todayLogs.map(({ log, product }) => {
                  const mealCfg = MEAL_CONFIG.find((m) => m.key === log.mealType);
                  const MealIcon = mealCfg?.icon ?? Utensils;
                  return (
                    <div
                      key={log.id}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                    >
                      <NutriScoreBadge score={product.nutriScore} size="sm" />
                      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => navigate(`/products/${product.id}`)}>
                        <p className="text-sm font-medium text-foreground truncate">{product.name}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{product.calories != null ? `${Math.round(product.calories * log.quantity)} kcal` : "—"}</span>
                          <span>·</span>
                          <MealIcon className={`w-3 h-3 ${mealCfg?.color ?? ""}`} />
                          <span className="capitalize">{log.mealType ?? "snacks"}</span>
                          <span>·</span>
                          <span>{new Date(log.consumedAt).toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" })}</span>
                        </div>
                      </div>

                      {editingId === log.id ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number" min={1} max={99} value={editQty}
                            onChange={(e) => setEditQty(Number(e.target.value))}
                            className="w-12 text-center text-sm border border-border rounded px-1 py-0.5 bg-background"
                            autoFocus
                          />
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-primary"
                            onClick={() => { updateMutation.mutate({ logId: log.id, quantity: editQty }); setEditingId(null); }}>
                            Save
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs"
                            onClick={() => setEditingId(null)}>
                            Cancel
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-xs text-muted-foreground">×{log.quantity}</span>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs"
                            onClick={() => { setEditingId(log.id); setEditQty(log.quantity); }}>
                            Edit
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                            onClick={() => deleteMutation.mutate({ logId: log.id })}>
                            Remove
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
