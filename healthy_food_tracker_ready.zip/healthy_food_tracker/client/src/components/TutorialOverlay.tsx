import { useEffect, useRef, useState } from "react";
import { X, ArrowRight, Check } from "lucide-react";

const TUTORIAL_KEY = "hft_tutorial_done";

interface TutorialStep {
  targetId: string;
  title: string;
  desc: string;
  position: "above" | "below";
}

const STEPS: TutorialStep[] = [
  {
    targetId: "tutorial-calorie-ring",
    title: "Your calorie ring",
    desc: "This ring tracks how much of your daily budget you've used. It updates every time you log a meal.",
    position: "below",
  },
  {
    targetId: "tutorial-scan-btn",
    title: "Log food in seconds",
    desc: "Tap here to scan a barcode, photograph a dish with AI, or search our database of 3 million+ foods.",
    position: "below",
  },
  {
    targetId: "tutorial-meal-cards",
    title: "Your meal breakdown",
    desc: "Breakfast, lunch, dinner, and snacks tracked separately. Tap the '+' on any meal to add food.",
    position: "above",
  },
  {
    targetId: "tutorial-water-streak",
    title: "Water & streaks",
    desc: "Track daily hydration and keep your logging streak alive. Consistent logging unlocks badges and rewards.",
    position: "above",
  },
];

interface SpotlightRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

export function TutorialOverlay({ onDone }: { onDone?: () => void }) {
  const [step, setStep] = useState(0);
  const [rect, setRect] = useState<SpotlightRect | null>(null);
  const [visible, setVisible] = useState(true);
  const overlayRef = useRef<HTMLDivElement>(null);

  const current = STEPS[step];

  useEffect(() => {
    if (!visible) return;
    const updateRect = () => {
      const el = document.getElementById(current.targetId);
      if (!el) return;
      const r = el.getBoundingClientRect();
      setRect({ top: r.top, left: r.left, width: r.width, height: r.height });
    };
    updateRect();
    window.addEventListener("resize", updateRect);
    window.addEventListener("scroll", updateRect, true);
    return () => {
      window.removeEventListener("resize", updateRect);
      window.removeEventListener("scroll", updateRect, true);
    };
  }, [step, visible, current.targetId]);

  const finish = () => {
    setVisible(false);
    localStorage.setItem(TUTORIAL_KEY, "1");
    onDone?.();
  };

  const next = () => {
    if (step < STEPS.length - 1) {
      setStep((s) => s + 1);
    } else {
      finish();
    }
  };

  if (!visible || !rect) return null;

  const PAD = 6;
  const holeTop = rect.top - PAD;
  const holeLeft = rect.left - PAD;
  const holeW = rect.width + PAD * 2;
  const holeH = rect.height + PAD * 2;
  const TOOLTIP_W = 300;

  // Tooltip horizontal position: clamp inside viewport
  const tooltipLeft = Math.min(
    Math.max(16, holeLeft + holeW / 2 - TOOLTIP_W / 2),
    window.innerWidth - TOOLTIP_W - 16
  );

  const tooltipStyle: React.CSSProperties =
    current.position === "below"
      ? { top: holeTop + holeH + 14 }
      : { bottom: window.innerHeight - holeTop + 14 };

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50"
      style={{ pointerEvents: "none" }}
      aria-modal="true"
      role="dialog"
      aria-label="App tutorial"
    >
      {/* Dark mask using clip-path to cut out spotlight */}
      <svg
        style={{
          position: "fixed",
          inset: 0,
          width: "100%",
          height: "100%",
          pointerEvents: "all",
        }}
        onClick={next}
      >
        <defs>
          <mask id="hft-spotlight-mask">
            <rect width="100%" height="100%" fill="white" />
            <rect
              x={holeLeft}
              y={holeTop}
              width={holeW}
              height={holeH}
              rx="10"
              fill="black"
            />
          </mask>
        </defs>
        <rect
          width="100%"
          height="100%"
          fill="rgba(0,0,0,0.65)"
          mask="url(#hft-spotlight-mask)"
        />
        {/* Spotlight border ring */}
        <rect
          x={holeLeft}
          y={holeTop}
          width={holeW}
          height={holeH}
          rx="10"
          fill="none"
          stroke="rgba(255,255,255,0.5)"
          strokeWidth="2"
        />
      </svg>

      {/* Tooltip card */}
      <div
        style={{
          position: "fixed",
          left: tooltipLeft,
          width: TOOLTIP_W,
          pointerEvents: "all",
          ...tooltipStyle,
        }}
        className="bg-white rounded-2xl shadow-2xl p-4 z-50"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-1">
          <p className="font-semibold text-sm text-gray-900">{current.title}</p>
          <button
            onClick={finish}
            className="text-gray-400 hover:text-gray-600 transition-colors ml-2 mt-0.5"
            aria-label="Skip tutorial"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-gray-500 leading-relaxed mb-3">{current.desc}</p>
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className="rounded-full transition-all duration-300"
                style={{
                  width: i === step ? 20 : 6,
                  height: 6,
                  background: i <= step ? "#16a34a" : "#e5e7eb",
                }}
              />
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={finish}
              className="text-xs text-gray-400 hover:text-gray-600"
            >
              Skip
            </button>
            <button
              onClick={next}
              className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-colors"
            >
              {step < STEPS.length - 1 ? (
                <>Next <ArrowRight className="w-3 h-3" /></>
              ) : (
                <>Done <Check className="w-3 h-3" /></>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function useShouldShowTutorial() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const done = localStorage.getItem(TUTORIAL_KEY);
    if (!done) setShow(true);
  }, []);
  return { show, dismiss: () => setShow(false) };
}
