import mysql from "mysql2/promise";
import { readFileSync } from "fs";

const sql = readFileSync("./drizzle/0004_next_human_torch.sql", "utf8");
const statements = sql
  .split("--> statement-breakpoint")
  .map((s) => s.trim())
  .filter(Boolean);

const conn = await mysql.createConnection(process.env.DATABASE_URL);

for (const stmt of statements) {
  try {
    await conn.execute(stmt);
    console.log("✓", stmt.slice(0, 60).replace(/\n/g, " "));
  } catch (err) {
    if (err.code === "ER_TABLE_EXISTS_ERROR" || err.code === "ER_DUP_KEYNAME") {
      console.log("⚠ Already exists, skipping:", stmt.slice(0, 60).replace(/\n/g, " "));
    } else {
      console.error("✗ Error:", err.message, "\n  SQL:", stmt.slice(0, 80));
    }
  }
}

await conn.end();
console.log("Migration complete.");
