import { readFileSync } from 'fs';
import mysql from 'mysql2/promise';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, '..', '.env') });

const sql = readFileSync(join(__dirname, 'seed_foods.sql'), 'utf8');

const conn = await mysql.createConnection(process.env.DATABASE_URL);
try {
  const [result] = await conn.query(sql);
  console.log('Inserted rows:', result.affectedRows ?? 'N/A');
} catch(e) {
  console.error('Error:', e.message);
} finally {
  await conn.end();
}
