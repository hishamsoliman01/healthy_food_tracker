import { createConnection } from "mysql2/promise";

const templates = [
  {
    title: "7-Day Streak Challenge",
    description: "Log every meal for 7 days straight. Build the habit of consistent tracking.",
    challengeType: "streak",
    targetValue: 7,
    targetUnit: "days",
    durationDays: 7,
    icon: "🔥",
    isSocial: true,
  },
  {
    title: "Hydration Hero",
    description: "Hit your daily water goal (2L) for 14 consecutive days.",
    challengeType: "water",
    targetValue: 14,
    targetUnit: "days",
    durationDays: 14,
    icon: "💧",
    isSocial: true,
  },
  {
    title: "Nutri-Score Upgrade",
    description: "Achieve an average Nutri-Score of B or better across all meals logged in 10 days.",
    challengeType: "nutriscore",
    targetValue: 10,
    targetUnit: "days",
    durationDays: 10,
    icon: "🥗",
    isSocial: false,
  },
  {
    title: "Calorie Control Month",
    description: "Stay within your calorie target every day for 30 days.",
    challengeType: "calories",
    targetValue: 30,
    targetUnit: "days",
    durationDays: 30,
    icon: "⚖️",
    isSocial: true,
  },
  {
    title: "Weight Loss Sprint",
    description: "Log your weight daily and lose at least 1 kg over 21 days.",
    challengeType: "weight",
    targetValue: 21,
    targetUnit: "days",
    durationDays: 21,
    icon: "📉",
    isSocial: false,
  },
];

const conn = await createConnection(process.env.DATABASE_URL);

console.log("Seeding challenge templates...");

// Clear existing templates first to avoid duplicates
await conn.execute("DELETE FROM challenge_templates");

for (const t of templates) {
  await conn.execute(
    `INSERT INTO challenge_templates (title, description, challengeType, targetValue, targetUnit, durationDays, icon, isSocial)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [t.title, t.description, t.challengeType, t.targetValue, t.targetUnit, t.durationDays, t.icon, t.isSocial]
  );
  console.log(`  ✓ ${t.icon} ${t.title}`);
}

await conn.end();
console.log("Done — 5 challenge templates seeded.");
