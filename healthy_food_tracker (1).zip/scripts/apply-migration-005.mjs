import { createConnection } from "mysql2/promise";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));

const sql = readFileSync(
  join(__dirname, "../drizzle/0005_premium_the_watchers.sql"),
  "utf8"
);

// Split on the drizzle statement breakpoint marker
const statements = sql
  .split("--> statement-breakpoint")
  .map((s) => s.trim())
  .filter((s) => s.length > 0);

const conn = await createConnection(process.env.DATABASE_URL);

console.log(`Applying ${statements.length} SQL statements...`);

for (let i = 0; i < statements.length; i++) {
  const stmt = statements[i];
  console.log(`[${i + 1}/${statements.length}] ${stmt.substring(0, 80)}...`);
  try {
    await conn.execute(stmt);
    console.log(`  ✓ OK`);
  } catch (err) {
    if (err.code === "ER_TABLE_EXISTS_ERROR" || err.code === "ER_DUP_FIELDNAME" || err.code === "ER_DUP_KEYNAME") {
      console.log(`  ⚠ Already exists, skipping`);
    } else {
      console.error(`  ✗ Error: ${err.message}`);
      // Don't throw — continue with remaining statements
    }
  }
}

await conn.end();
console.log("Migration complete.");
