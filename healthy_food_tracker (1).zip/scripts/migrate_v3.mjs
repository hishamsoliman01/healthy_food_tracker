import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';
import dotenv from 'dotenv';
dotenv.config();

const sql = readFileSync('./drizzle/0003_bent_namor.sql', 'utf8');
const statements = sql.split('--> statement-breakpoint').map(s => s.trim()).filter(Boolean);

const conn = await mysql.createConnection(process.env.DATABASE_URL);
console.log('Connected to DB');

for (const stmt of statements) {
  try {
    await conn.execute(stmt);
    console.log('OK:', stmt.slice(0, 60).replace(/\n/g, ' '));
  } catch (e) {
    if (e.code === 'ER_TABLE_EXISTS_ERROR' || e.code === 'ER_DUP_KEYNAME' || e.code === 'ER_DUP_FIELDNAME') {
      console.log('SKIP (already exists):', stmt.slice(0, 60).replace(/\n/g, ' '));
    } else {
      console.error('ERROR:', e.message, '\nSQL:', stmt.slice(0, 100));
    }
  }
}

await conn.end();
console.log('Migration complete');
