import {
  bigint,
  boolean,
  date,
  float,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User body profiles — stores physical data for calorie calculation.
 */
export const userProfiles = mysqlTable("user_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  gender: mysqlEnum("gender", ["male", "female"]).notNull(),
  age: int("age").notNull(),
  weight: float("weight").notNull(),
  height: float("height").notNull(),
  activityLevel: mysqlEnum("activityLevel", [
    "sedentary",
    "lightly_active",
    "moderately_active",
    "very_active",
    "extra_active",
  ]).notNull(),
  goal: mysqlEnum("goal", ["lose_weight", "maintain", "gain_muscle"]).default("maintain").notNull(),
  waterGoalMl: int("waterGoalMl").default(2000).notNull(),
  isPrivate: boolean("isPrivate").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

/**
 * Products table — stores food product data with health classification.
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  barcode: varchar("barcode", { length: 64 }).unique(),
  name: varchar("name", { length: 255 }).notNull(),
  brand: varchar("brand", { length: 128 }),
  category: varchar("category", { length: 128 }),
  imageUrl: text("imageUrl"),
  nutriScore: mysqlEnum("nutriScore", ["A", "B", "C", "D", "E"]).default("C"),
  novaGroup: int("novaGroup").default(3),
  ingredients: text("ingredients"),
  calories: float("calories"),
  fat: float("fat"),
  saturatedFat: float("saturatedFat"),
  carbohydrates: float("carbohydrates"),
  sugars: float("sugars"),
  fiber: float("fiber"),
  proteins: float("proteins"),
  salt: float("salt"),
  sodium: float("sodium"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Consumption logs — tracks what users eat each day, grouped by meal.
 */
export const consumptionLogs = mysqlTable("consumption_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  productId: int("productId").notNull().references(() => products.id),
  quantity: int("quantity").default(1).notNull(),
  mealType: mysqlEnum("mealType", ["breakfast", "lunch", "dinner", "snacks"]).default("snacks").notNull(),
  consumedAt: timestamp("consumedAt").defaultNow().notNull(),
  notes: text("notes"),
});

export type ConsumptionLog = typeof consumptionLogs.$inferSelect;
export type InsertConsumptionLog = typeof consumptionLogs.$inferInsert;

/**
 * Weight logs — daily weigh-in entries for progress tracking.
 */
export const weightLogs = mysqlTable("weight_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  weightKg: float("weightKg").notNull(),
  loggedAt: timestamp("loggedAt").defaultNow().notNull(),
  notes: text("notes"),
});

export type WeightLog = typeof weightLogs.$inferSelect;
export type InsertWeightLog = typeof weightLogs.$inferInsert;

/**
 * Water logs — daily water intake tracking.
 */
export const waterLogs = mysqlTable("water_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  amountMl: int("amountMl").notNull(),
  loggedAt: timestamp("loggedAt").defaultNow().notNull(),
});

export type WaterLog = typeof waterLogs.$inferSelect;
export type InsertWaterLog = typeof waterLogs.$inferInsert;

/**
 * User streaks — tracks consecutive logging days and earned badges.
 */
export const userStreaks = mysqlTable("user_streaks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  currentStreak: int("currentStreak").default(0).notNull(),
  longestStreak: int("longestStreak").default(0).notNull(),
  lastLogDate: date("lastLogDate"),
  totalLogDays: int("totalLogDays").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserStreak = typeof userStreaks.$inferSelect;
export type InsertUserStreak = typeof userStreaks.$inferInsert;

/**
 * Favourites — user's saved foods for quick logging.
 */
export const favourites = mysqlTable("favourites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  productId: int("productId").notNull().references(() => products.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Favourite = typeof favourites.$inferSelect;
export type InsertFavourite = typeof favourites.$inferInsert;

/**
 * Recipes — user-created meals composed of multiple ingredients.
 */
export const recipes = mysqlTable("recipes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  servings: int("servings").default(1).notNull(),
  imageUrl: text("imageUrl"),
  isPublic: boolean("isPublic").default(false).notNull(),
  // Calculated totals per serving
  totalCalories: float("totalCalories"),
  totalProtein: float("totalProtein"),
  totalCarbs: float("totalCarbs"),
  totalFat: float("totalFat"),
  totalFiber: float("totalFiber"),
  nutriScore: mysqlEnum("nutriScore", ["A", "B", "C", "D", "E"]).default("C"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = typeof recipes.$inferInsert;

/**
 * Recipe ingredients — links products to recipes with quantities.
 */
export const recipeIngredients = mysqlTable("recipe_ingredients", {
  id: int("id").autoincrement().primaryKey(),
  recipeId: int("recipeId").notNull().references(() => recipes.id),
  productId: int("productId").notNull().references(() => products.id),
  amountGrams: float("amountGrams").notNull(),
});

export type RecipeIngredient = typeof recipeIngredients.$inferSelect;
export type InsertRecipeIngredient = typeof recipeIngredients.$inferInsert;

// ─── Meal Plan ────────────────────────────────────────────────────────────────
export const mealPlans = mysqlTable("meal_plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: varchar("userId", { length: 255 }).notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  mealType: mysqlEnum("mealType", ["breakfast", "lunch", "dinner", "snacks"]).notNull(),
  productId: int("productId").notNull().references(() => products.id),
  amountGrams: float("amountGrams").notNull().default(100),
  notes: varchar("notes", { length: 500 }),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = typeof mealPlans.$inferInsert;

// ─── Friendships ──────────────────────────────────────────────────────────────
export const friendships = mysqlTable("friendships", {
  id: int("id").autoincrement().primaryKey(),
  userId: varchar("userId", { length: 255 }).notNull(),
  friendId: varchar("friendId", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "declined"]).notNull().default("pending"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export type Friendship = typeof friendships.$inferSelect;
export type InsertFriendship = typeof friendships.$inferInsert;

// ─── Challenges ───────────────────────────────────────────────────────────────
export const challenges = mysqlTable("challenges", {
  id: int("id").autoincrement().primaryKey(),
  creatorId: varchar("creatorId", { length: 255 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: varchar("description", { length: 500 }),
  type: mysqlEnum("type", ["streak", "calories", "water", "steps"]).notNull().default("streak"),
  targetValue: int("targetValue").notNull().default(7),
  startDate: varchar("startDate", { length: 10 }).notNull(),
  endDate: varchar("endDate", { length: 10 }).notNull(),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).notNull().default("active"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
});

export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = typeof challenges.$inferInsert;

export const challengeParticipants = mysqlTable("challenge_participants", {
  id: int("id").autoincrement().primaryKey(),
  challengeId: int("challengeId").notNull().references(() => challenges.id),
  userId: varchar("userId", { length: 255 }).notNull(),
  userName: varchar("userName", { length: 255 }).notNull(),
  currentScore: int("currentScore").notNull().default(0),
  joinedAt: bigint("joinedAt", { mode: "number" }).notNull(),
});

export type ChallengeParticipant = typeof challengeParticipants.$inferSelect;
export type InsertChallengeParticipant = typeof challengeParticipants.$inferInsert;

// ─── Friend Activity Feed ─────────────────────────────────────────────────────
export const friendActivity = mysqlTable("friend_activity", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  activityType: mysqlEnum("activityType", [
    "logged_meal",
    "hit_streak",
    "completed_challenge",
    "hit_water_goal",
  ]).notNull(),
  calories: int("calories"),
  streakCount: int("streakCount"),
  challengeTitle: varchar("challengeTitle", { length: 200 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FriendActivity = typeof friendActivity.$inferSelect;
export type InsertFriendActivity = typeof friendActivity.$inferInsert;

// ─── Notifications ────────────────────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  type: mysqlEnum("type", [
    "friend_request",
    "friend_accepted",
    "challenge_completed",
    "challenge_milestone",
    "friend_challenge_completed",
    "meal_plan_reminder",
    "general",
  ]).notNull().default("general"),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  relatedId: int("relatedId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Challenge Templates ──────────────────────────────────────────────────────
// System-defined challenge templates (seeded, not user-created)
export const challengeTemplates = mysqlTable("challenge_templates", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  challengeType: mysqlEnum("challengeType", ["streak", "water", "nutriscore", "calories", "weight", "custom"]).notNull(),
  targetValue: int("targetValue").notNull(),
  targetUnit: varchar("targetUnit", { length: 50 }).notNull(),
  durationDays: int("durationDays").notNull(),
  icon: varchar("icon", { length: 10 }).notNull(),
  isSocial: boolean("isSocial").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChallengeTemplate = typeof challengeTemplates.$inferSelect;
export type InsertChallengeTemplate = typeof challengeTemplates.$inferInsert;

// ─── User Challenge Participation ─────────────────────────────────────────────
export const userChallenges = mysqlTable("user_challenges", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  templateId: int("templateId").notNull().references(() => challengeTemplates.id),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  currentProgress: int("currentProgress").default(0).notNull(),
  status: mysqlEnum("status", ["active", "completed", "failed", "abandoned"]).notNull().default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserChallenge = typeof userChallenges.$inferSelect;
export type InsertUserChallenge = typeof userChallenges.$inferInsert;
