CREATE TABLE `challenge_participants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`challengeId` int NOT NULL,
	`userId` varchar(255) NOT NULL,
	`userName` varchar(255) NOT NULL,
	`currentScore` int NOT NULL DEFAULT 0,
	`joinedAt` bigint NOT NULL,
	CONSTRAINT `challenge_participants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorId` varchar(255) NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` varchar(500),
	`type` enum('streak','calories','water','steps') NOT NULL DEFAULT 'streak',
	`targetValue` int NOT NULL DEFAULT 7,
	`startDate` varchar(10) NOT NULL,
	`endDate` varchar(10) NOT NULL,
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`createdAt` bigint NOT NULL,
	CONSTRAINT `challenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `friendships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` varchar(255) NOT NULL,
	`friendId` varchar(255) NOT NULL,
	`status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
	`createdAt` bigint NOT NULL,
	CONSTRAINT `friendships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `meal_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` varchar(255) NOT NULL,
	`date` varchar(10) NOT NULL,
	`mealType` enum('breakfast','lunch','dinner','snacks') NOT NULL,
	`productId` int NOT NULL,
	`amountGrams` float NOT NULL DEFAULT 100,
	`notes` varchar(500),
	`createdAt` bigint NOT NULL,
	CONSTRAINT `meal_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `challenge_participants` ADD CONSTRAINT `challenge_participants_challengeId_challenges_id_fk` FOREIGN KEY (`challengeId`) REFERENCES `challenges`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `meal_plans` ADD CONSTRAINT `meal_plans_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE no action ON UPDATE no action;