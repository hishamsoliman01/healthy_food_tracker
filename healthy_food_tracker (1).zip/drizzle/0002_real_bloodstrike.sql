CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gender` enum('male','female') NOT NULL,
	`age` int NOT NULL,
	`weight` float NOT NULL,
	`height` float NOT NULL,
	`activityLevel` enum('sedentary','lightly_active','moderately_active','very_active','extra_active') NOT NULL,
	`goal` enum('lose_weight','maintain','gain_muscle') NOT NULL DEFAULT 'maintain',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `consumption_logs` ADD `mealType` enum('breakfast','lunch','dinner','snacks') DEFAULT 'snacks' NOT NULL;--> statement-breakpoint
ALTER TABLE `user_profiles` ADD CONSTRAINT `user_profiles_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;