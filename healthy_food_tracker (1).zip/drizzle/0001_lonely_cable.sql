CREATE TABLE `consumption_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productId` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`consumedAt` timestamp NOT NULL DEFAULT (now()),
	`notes` text,
	CONSTRAINT `consumption_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`barcode` varchar(64),
	`name` varchar(255) NOT NULL,
	`brand` varchar(128),
	`category` varchar(128),
	`imageUrl` text,
	`nutriScore` enum('A','B','C','D','E') DEFAULT 'C',
	`novaGroup` int DEFAULT 3,
	`ingredients` text,
	`calories` float,
	`fat` float,
	`saturatedFat` float,
	`carbohydrates` float,
	`sugars` float,
	`fiber` float,
	`proteins` float,
	`salt` float,
	`sodium` float,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_barcode_unique` UNIQUE(`barcode`)
);
--> statement-breakpoint
ALTER TABLE `consumption_logs` ADD CONSTRAINT `consumption_logs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `consumption_logs` ADD CONSTRAINT `consumption_logs_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE no action ON UPDATE no action;