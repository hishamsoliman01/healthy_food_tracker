import { and, desc, eq, gte, like, lte, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  consumptionLogs,
  InsertUser,
  InsertUserProfile,
  products,
  userProfiles,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Calorie calculation helpers ─────────────────────────────────────────────

const ACTIVITY_MULTIPLIERS: Record<string, number> = {
  sedentary: 1.2,
  lightly_active: 1.375,
  moderately_active: 1.55,
  very_active: 1.725,
  extra_active: 1.9,
};

/**
 * Mifflin-St Jeor BMR formula:
 *   Male:   10×weight(kg) + 6.25×height(cm) − 5×age + 5
 *   Female: 10×weight(kg) + 6.25×height(cm) − 5×age − 161
 */
export function calculateBMR(gender: string, weight: number, height: number, age: number): number {
  const base = 10 * weight + 6.25 * height - 5 * age;
  return Math.round(gender === "male" ? base + 5 : base - 161);
}

export function calculateTDEE(bmr: number, activityLevel: string): number {
  const multiplier = ACTIVITY_MULTIPLIERS[activityLevel] ?? 1.2;
  return Math.round(bmr * multiplier);
}

export function calculateCalorieTarget(tdee: number, goal: string): number {
  if (goal === "lose_weight") return Math.max(1200, tdee - 500);
  if (goal === "gain_muscle") return tdee + 300;
  return tdee;
}

/** Macro targets as % of calorie target (standard balanced split). */
export function calculateMacroTargets(calorieTarget: number) {
  return {
    proteins: Math.round((calorieTarget * 0.25) / 4),   // 25% of calories, 4 kcal/g
    carbohydrates: Math.round((calorieTarget * 0.50) / 4), // 50% of calories
    fat: Math.round((calorieTarget * 0.25) / 9),          // 25% of calories, 9 kcal/g
  };
}

// ─── User helpers ────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── User profile helpers ─────────────────────────────────────────────────────

export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertUserProfile(data: InsertUserProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(userProfiles).values(data).onDuplicateKeyUpdate({
    set: {
      gender: data.gender,
      age: data.age,
      weight: data.weight,
      height: data.height,
      activityLevel: data.activityLevel,
      goal: data.goal,
    },
  });
  return getUserProfile(data.userId);
}

// ─── Product helpers ──────────────────────────────────────────────────────────

export async function getProductByBarcode(barcode: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.barcode, barcode)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function searchProducts(query: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  const pattern = `%${query}%`;
  return db
    .select()
    .from(products)
    .where(or(like(products.name, pattern), like(products.brand, pattern), like(products.category, pattern), like(products.barcode, pattern)))
    .orderBy(products.name)
    .limit(limit);
}

export async function createProduct(data: {
  barcode?: string; name: string; brand?: string; category?: string;
  nutriScore?: "A" | "B" | "C" | "D" | "E"; novaGroup?: number; ingredients?: string;
  calories?: number; fat?: number; saturatedFat?: number; carbohydrates?: number;
  sugars?: number; fiber?: number; proteins?: number; salt?: number; sodium?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(products).values(data);
  const insertId = (result as unknown as [{ insertId: number }])[0]?.insertId;
  return getProductById(insertId);
}

export async function findProductByExactName(name: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.name, name)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllProducts(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).orderBy(products.name).limit(limit);
}

// ─── Consumption log helpers ──────────────────────────────────────────────────

export async function addConsumptionLog(
  userId: number,
  productId: number,
  quantity = 1,
  mealType: "breakfast" | "lunch" | "dinner" | "snacks" = "snacks",
  notes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(consumptionLogs).values({ userId, productId, quantity, mealType, notes });
  const insertId = (result as unknown as [{ insertId: number }])[0]?.insertId;
  return getConsumptionLogById(insertId);
}

export async function getConsumptionLogById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(consumptionLogs).where(eq(consumptionLogs.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getDailyConsumptionLogs(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];
  const start = new Date(date); start.setUTCHours(0, 0, 0, 0);
  const end = new Date(date); end.setUTCHours(23, 59, 59, 999);

  return db
    .select({ log: consumptionLogs, product: products })
    .from(consumptionLogs)
    .innerJoin(products, eq(consumptionLogs.productId, products.id))
    .where(and(eq(consumptionLogs.userId, userId), gte(consumptionLogs.consumedAt, start), lte(consumptionLogs.consumedAt, end)))
    .orderBy(desc(consumptionLogs.consumedAt));
}

export async function getConsumptionHistory(userId: number, days = 7) {
  const db = await getDb();
  if (!db) return [];
  const since = new Date();
  since.setDate(since.getDate() - days);
  since.setUTCHours(0, 0, 0, 0);

  return db
    .select({ log: consumptionLogs, product: products })
    .from(consumptionLogs)
    .innerJoin(products, eq(consumptionLogs.productId, products.id))
    .where(and(eq(consumptionLogs.userId, userId), gte(consumptionLogs.consumedAt, since)))
    .orderBy(desc(consumptionLogs.consumedAt));
}

export async function updateConsumptionLog(
  id: number,
  userId: number,
  quantity: number,
  mealType?: "breakfast" | "lunch" | "dinner" | "snacks",
  notes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: Record<string, unknown> = { quantity };
  if (mealType) updateData.mealType = mealType;
  if (notes !== undefined) updateData.notes = notes;
  await db.update(consumptionLogs).set(updateData).where(and(eq(consumptionLogs.id, id), eq(consumptionLogs.userId, userId)));
  return getConsumptionLogById(id);
}

export async function deleteConsumptionLog(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(consumptionLogs).where(and(eq(consumptionLogs.id, id), eq(consumptionLogs.userId, userId)));
  return { success: true };
}

export async function getDashboardStats(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const today = new Date();
  const todayLogs = await getDailyConsumptionLogs(userId, today);
  const weekLogs = await getConsumptionHistory(userId, 7);

  // Today totals
  let totalCalories = 0, totalProteins = 0, totalCarbs = 0, totalFat = 0;
  const scoreCounts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0 };
  const mealCalories: Record<string, number> = { breakfast: 0, lunch: 0, dinner: 0, snacks: 0 };
  const mealItems: Record<string, number> = { breakfast: 0, lunch: 0, dinner: 0, snacks: 0 };

  for (const { log, product } of todayLogs) {
    const qty = log.quantity;
    const cal = (product.calories ?? 0) * qty;
    totalCalories += cal;
    totalProteins += (product.proteins ?? 0) * qty;
    totalCarbs += (product.carbohydrates ?? 0) * qty;
    totalFat += (product.fat ?? 0) * qty;
    if (product.nutriScore) scoreCounts[product.nutriScore] = (scoreCounts[product.nutriScore] ?? 0) + qty;
    const meal = log.mealType ?? "snacks";
    mealCalories[meal] = (mealCalories[meal] ?? 0) + cal;
    mealItems[meal] = (mealItems[meal] ?? 0) + 1;
  }

  // Weekly daily calorie breakdown
  const dailyCalories: Record<string, number> = {};
  for (const { log, product } of weekLogs) {
    const dateKey = log.consumedAt.toISOString().split("T")[0]!;
    dailyCalories[dateKey] = (dailyCalories[dateKey] ?? 0) + (product.calories ?? 0) * log.quantity;
  }

  return {
    today: {
      totalCalories: Math.round(totalCalories),
      totalProteins: Math.round(totalProteins * 10) / 10,
      totalCarbs: Math.round(totalCarbs * 10) / 10,
      totalFat: Math.round(totalFat * 10) / 10,
      itemCount: todayLogs.length,
      scoreCounts,
      mealCalories: {
        breakfast: Math.round(mealCalories.breakfast ?? 0),
        lunch: Math.round(mealCalories.lunch ?? 0),
        dinner: Math.round(mealCalories.dinner ?? 0),
        snacks: Math.round(mealCalories.snacks ?? 0),
      },
      mealItems,
    },
    weeklyCalories: dailyCalories,
    recentLogs: weekLogs.slice(0, 10),
  };
}

// ─── Weight log helpers ───────────────────────────────────────────────────────

import {
  favourites,
  InsertFavourite,
  InsertRecipe,
  InsertRecipeIngredient,
  InsertWaterLog,
  InsertWeightLog,
  recipeIngredients,
  recipes,
  userStreaks,
  waterLogs,
  weightLogs,
} from "../drizzle/schema";

export async function addWeightLog(userId: number, weightKg: number, notes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(weightLogs).values({ userId, weightKg, notes });
  const insertId = (result as unknown as [{ insertId: number }])[0]?.insertId;
  const rows = await db.select().from(weightLogs).where(eq(weightLogs.id, insertId)).limit(1);
  return rows[0] ?? null;
}

export async function getWeightLogs(userId: number, days = 90) {
  const db = await getDb();
  if (!db) return [];
  const since = new Date();
  since.setDate(since.getDate() - days);
  return db
    .select()
    .from(weightLogs)
    .where(and(eq(weightLogs.userId, userId), gte(weightLogs.loggedAt, since)))
    .orderBy(weightLogs.loggedAt);
}

export async function deleteWeightLog(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(weightLogs).where(and(eq(weightLogs.id, id), eq(weightLogs.userId, userId)));
  return { success: true };
}

// ─── Water log helpers ────────────────────────────────────────────────────────

export async function addWaterLog(userId: number, amountMl: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(waterLogs).values({ userId, amountMl });
  return getDailyWaterTotal(userId, new Date());
}

export async function getDailyWaterTotal(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return 0;
  const start = new Date(date); start.setUTCHours(0, 0, 0, 0);
  const end = new Date(date); end.setUTCHours(23, 59, 59, 999);
  const rows = await db
    .select()
    .from(waterLogs)
    .where(and(eq(waterLogs.userId, userId), gte(waterLogs.loggedAt, start), lte(waterLogs.loggedAt, end)));
  return rows.reduce((sum, r) => sum + r.amountMl, 0);
}

export async function getWaterLogs(userId: number, date: Date) {
  const db = await getDb();
  if (!db) return [];
  const start = new Date(date); start.setUTCHours(0, 0, 0, 0);
  const end = new Date(date); end.setUTCHours(23, 59, 59, 999);
  return db
    .select()
    .from(waterLogs)
    .where(and(eq(waterLogs.userId, userId), gte(waterLogs.loggedAt, start), lte(waterLogs.loggedAt, end)))
    .orderBy(waterLogs.loggedAt);
}

export async function deleteWaterLog(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(waterLogs).where(and(eq(waterLogs.id, id), eq(waterLogs.userId, userId)));
  return { success: true };
}

// ─── Streak helpers ───────────────────────────────────────────────────────────

export async function getOrCreateStreak(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(userStreaks).where(eq(userStreaks.userId, userId)).limit(1);
  if (rows.length > 0) return rows[0]!;
  await db.insert(userStreaks).values({ userId, currentStreak: 0, longestStreak: 0, totalLogDays: 0 });
  const newRows = await db.select().from(userStreaks).where(eq(userStreaks.userId, userId)).limit(1);
  return newRows[0] ?? null;
}

export async function updateStreak(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const streak = await getOrCreateStreak(userId);
  if (!streak) return null;

  const todayStr = new Date().toISOString().split("T")[0]!;
  const lastStr = streak.lastLogDate ? new Date(streak.lastLogDate).toISOString().split("T")[0] : null;

  if (lastStr === todayStr) return streak; // already updated today

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split("T")[0]!;

  const newCurrent = lastStr === yesterdayStr ? streak.currentStreak + 1 : 1;
  const newLongest = Math.max(streak.longestStreak, newCurrent);
  const newTotal = streak.totalLogDays + 1;

  await db
    .update(userStreaks)
    .set({ currentStreak: newCurrent, longestStreak: newLongest, totalLogDays: newTotal, lastLogDate: new Date() })
    .where(eq(userStreaks.userId, userId));

  const updated = await db.select().from(userStreaks).where(eq(userStreaks.userId, userId)).limit(1);
  return updated[0] ?? null;
}

// ─── Favourites helpers ───────────────────────────────────────────────────────

export async function getFavourites(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ favourite: favourites, product: products })
    .from(favourites)
    .innerJoin(products, eq(favourites.productId, products.id))
    .where(eq(favourites.userId, userId))
    .orderBy(desc(favourites.createdAt));
}

export async function addFavourite(userId: number, productId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Check if already exists
  const existing = await db
    .select()
    .from(favourites)
    .where(and(eq(favourites.userId, userId), eq(favourites.productId, productId)))
    .limit(1);
  if (existing.length > 0) return existing[0]!;
  await db.insert(favourites).values({ userId, productId });
  const rows = await db
    .select()
    .from(favourites)
    .where(and(eq(favourites.userId, userId), eq(favourites.productId, productId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function removeFavourite(userId: number, productId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(favourites).where(and(eq(favourites.userId, userId), eq(favourites.productId, productId)));
  return { success: true };
}

export async function isFavourite(userId: number, productId: number) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db
    .select()
    .from(favourites)
    .where(and(eq(favourites.userId, userId), eq(favourites.productId, productId)))
    .limit(1);
  return rows.length > 0;
}

// ─── Recipe helpers ───────────────────────────────────────────────────────────

export async function getUserRecipes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(recipes).where(eq(recipes.userId, userId)).orderBy(desc(recipes.createdAt));
}

export async function getRecipeById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(recipes).where(eq(recipes.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getRecipeIngredients(recipeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ ingredient: recipeIngredients, product: products })
    .from(recipeIngredients)
    .innerJoin(products, eq(recipeIngredients.productId, products.id))
    .where(eq(recipeIngredients.recipeId, recipeId));
}

export async function createRecipe(data: InsertRecipe, ingredients: { productId: number; amountGrams: number }[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(recipes).values(data);
  const recipeId = (result as unknown as [{ insertId: number }])[0]?.insertId;
  if (ingredients.length > 0) {
    await db.insert(recipeIngredients).values(ingredients.map(i => ({ recipeId, ...i })));
  }
  return getRecipeById(recipeId);
}

export async function deleteRecipe(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(recipeIngredients).where(eq(recipeIngredients.recipeId, id));
  await db.delete(recipes).where(and(eq(recipes.id, id), eq(recipes.userId, userId)));
  return { success: true };
}

// ─── Weekly report helper ─────────────────────────────────────────────────────

export async function getWeeklyReport(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const since = new Date();
  since.setDate(since.getDate() - 6);
  since.setUTCHours(0, 0, 0, 0);

  const logs = await db
    .select({ log: consumptionLogs, product: products })
    .from(consumptionLogs)
    .innerJoin(products, eq(consumptionLogs.productId, products.id))
    .where(and(eq(consumptionLogs.userId, userId), gte(consumptionLogs.consumedAt, since)))
    .orderBy(consumptionLogs.consumedAt);

  const dailyData: Record<string, { calories: number; protein: number; carbs: number; fat: number; fiber: number; items: number; scores: Record<string, number> }> = {};

  for (const { log, product } of logs) {
    const dateKey = log.consumedAt.toISOString().split("T")[0]!;
    if (!dailyData[dateKey]) {
      dailyData[dateKey] = { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, items: 0, scores: {} };
    }
    const d = dailyData[dateKey]!;
    const qty = log.quantity;
    d.calories += (product.calories ?? 0) * qty;
    d.protein += (product.proteins ?? 0) * qty;
    d.carbs += (product.carbohydrates ?? 0) * qty;
    d.fat += (product.fat ?? 0) * qty;
    d.fiber += (product.fiber ?? 0) * qty;
    d.items += 1;
    if (product.nutriScore) d.scores[product.nutriScore] = (d.scores[product.nutriScore] ?? 0) + 1;
  }

  // Build 7-day array
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split("T")[0]!;
    const data = dailyData[key] ?? { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, items: 0, scores: {} };
    days.push({
      date: key,
      calories: Math.round(data.calories),
      protein: Math.round(data.protein * 10) / 10,
      carbs: Math.round(data.carbs * 10) / 10,
      fat: Math.round(data.fat * 10) / 10,
      fiber: Math.round(data.fiber * 10) / 10,
      items: data.items,
      scores: data.scores,
    });
  }

  const activeDays = days.filter(d => d.items > 0).length;
  const avgCalories = activeDays > 0 ? Math.round(days.reduce((s, d) => s + d.calories, 0) / activeDays) : 0;
  const totalScores: Record<string, number> = {};
  for (const d of days) {
    for (const [k, v] of Object.entries(d.scores)) {
      totalScores[k] = (totalScores[k] ?? 0) + (v as number);
    }
  }

  return { days, avgCalories, activeDays, totalScores };
}
