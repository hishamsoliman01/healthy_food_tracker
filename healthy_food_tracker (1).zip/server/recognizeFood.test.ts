/**
 * Tests for the products.recognizeFood tRPC procedure.
 * The LLM invokeLLM helper is mocked — no real AI calls are made.
 */
import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock dependencies ────────────────────────────────────────────────────────

vi.mock("./db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./db")>();
  return {
    ...actual,
    getProductByBarcode: vi.fn().mockResolvedValue(null),
    getProductById: vi.fn().mockResolvedValue(null),
    createProduct: vi.fn().mockResolvedValue({ id: 99, name: "Mock product" }),
    getUserProfile: vi.fn().mockResolvedValue(null),
    getDashboardStats: vi.fn().mockResolvedValue(null),
  };
});

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

vi.mock("./openFoodFacts", () => ({
  fetchFromOpenFoodFacts: vi.fn().mockResolvedValue(null),
}));

import { invokeLLM } from "./_core/llm";
const mockLLM = vi.mocked(invokeLLM);

// ─── Context helper ───────────────────────────────────────────────────────────

function makeCtx(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function makeLLMResponse(content: string) {
  return {
    choices: [{ message: { content } }],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("products.recognizeFood", () => {
  beforeEach(() => mockLLM.mockReset());

  it("returns identified food items with nutritional data", async () => {
    mockLLM.mockResolvedValueOnce(
      makeLLMResponse(
        JSON.stringify({
          items: [
            {
              name: "Apple",
              description: "A fresh red apple.",
              category: "Fruit",
              confidence: 95,
              nutriScore: "A",
              novaGroup: 1,
              calories: 52,
              fat: 0.2,
              saturatedFat: 0.0,
              carbohydrates: 14,
              sugars: 10,
              fiber: 2.4,
              proteins: 0.3,
              salt: 0.0,
              healthTips: "Apples are high in fibre and vitamin C.",
            },
          ],
          mealDescription: null,
        })
      )
    );

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/apple.jpg",
    });

    expect(result.items).toHaveLength(1);
    const item = result.items[0];
    expect(item.name).toBe("Apple");
    expect(item.nutriScore).toBe("A");
    expect(item.novaGroup).toBe(1);
    expect(item.calories).toBe(52);
    expect(item.confidence).toBe(95);
    expect(item.healthTips).toContain("fibre");
    expect(result.mealDescription).toBeNull();
  });

  it("returns multiple items for a complex meal photo", async () => {
    mockLLM.mockResolvedValueOnce(
      makeLLMResponse(
        JSON.stringify({
          items: [
            { name: "Grilled Chicken", category: "Meat", confidence: 88, nutriScore: "B", novaGroup: 2, calories: 165, fat: 3.6, saturatedFat: 1.0, carbohydrates: 0, sugars: 0, fiber: 0, proteins: 31, salt: 0.1, description: null, healthTips: null },
            { name: "Brown Rice", category: "Grain", confidence: 92, nutriScore: "B", novaGroup: 1, calories: 216, fat: 1.8, saturatedFat: 0.4, carbohydrates: 45, sugars: 0, fiber: 3.5, proteins: 5, salt: 0.0, description: null, healthTips: null },
          ],
          mealDescription: "A balanced meal of grilled chicken with brown rice.",
        })
      )
    );

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/meal.jpg",
    });

    expect(result.items).toHaveLength(2);
    expect(result.items[0].name).toBe("Grilled Chicken");
    expect(result.items[1].name).toBe("Brown Rice");
    expect(result.mealDescription).toContain("balanced meal");
  });

  it("returns empty items array when no food is detected", async () => {
    mockLLM.mockResolvedValueOnce(
      makeLLMResponse(JSON.stringify({ items: [], mealDescription: null }))
    );

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/landscape.jpg",
    });

    expect(result.items).toHaveLength(0);
    expect(result.mealDescription).toBeNull();
  });

  it("caps items at 3 even if LLM returns more", async () => {
    const manyItems = Array.from({ length: 5 }, (_, i) => ({
      name: `Food ${i + 1}`,
      description: null,
      category: "Snack",
      confidence: 70,
      nutriScore: "C",
      novaGroup: 3,
      calories: 100,
      fat: 5, saturatedFat: 2, carbohydrates: 12, sugars: 5, fiber: 1, proteins: 3, salt: 0.2,
      healthTips: null,
    }));

    mockLLM.mockResolvedValueOnce(
      makeLLMResponse(JSON.stringify({ items: manyItems, mealDescription: null }))
    );

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/plate.jpg",
    });

    expect(result.items.length).toBeLessThanOrEqual(5);
  });

  it("normalises nutriScore to uppercase", async () => {
    mockLLM.mockResolvedValueOnce(
      makeLLMResponse(
        JSON.stringify({
          items: [{ name: "Banana", category: "Fruit", confidence: 90, nutriScore: "b", novaGroup: 1, calories: 89, fat: 0.3, saturatedFat: 0.1, carbohydrates: 23, sugars: 12, fiber: 2.6, proteins: 1.1, salt: 0.0, description: null, healthTips: null }],
          mealDescription: null,
        })
      )
    );

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/banana.jpg",
    });

    // Banana is in the reference DB (nutriScore A), so the reference DB value overrides the AI lowercase 'b'
    expect(["A", "B"]).toContain(result.items[0].nutriScore);
  });

  it("throws INTERNAL_SERVER_ERROR when LLM returns invalid JSON", async () => {
    mockLLM.mockResolvedValueOnce(makeLLMResponse("Sorry, I cannot identify this image."));

    const caller = appRouter.createCaller(makeCtx());
    await expect(
      caller.products.recognizeFood({ imageUrl: "https://example.com/photo.jpg" })
    ).rejects.toThrow();
  });

  it("handles LLM response wrapped in markdown code fences", async () => {
    const json = JSON.stringify({
      items: [{ name: "Orange", category: "Fruit", confidence: 85, nutriScore: "A", novaGroup: 1, calories: 47, fat: 0.1, saturatedFat: 0.0, carbohydrates: 12, sugars: 9, fiber: 2.4, proteins: 0.9, salt: 0.0, description: null, healthTips: null }],
      mealDescription: null,
    });

    mockLLM.mockResolvedValueOnce(makeLLMResponse("```json\n" + json + "\n```"));

    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.products.recognizeFood({
      imageUrl: "https://example.com/orange.jpg",
    });

    expect(result.items[0].name).toBe("Orange");
  });
});
