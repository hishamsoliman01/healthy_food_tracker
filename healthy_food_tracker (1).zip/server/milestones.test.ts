import { describe, expect, it } from "vitest";
import { calculateBMR, calculateTDEE, calculateCalorieTarget } from "./db";

// ─── Onboarding Wizard Calculations ──────────────────────────────────────────
describe("Onboarding Wizard — calorie target preview", () => {
  it("lose_weight goal reduces TDEE by 500 kcal", () => {
    const bmr = calculateBMR("male", 80, 175, 30);
    const tdee = calculateTDEE(bmr, "moderately_active");
    const target = calculateCalorieTarget(tdee, "lose_weight");
    expect(target).toBe(Math.max(1200, tdee - 500));
  });

  it("gain_muscle goal adds 300 kcal to TDEE", () => {
    const bmr = calculateBMR("male", 75, 180, 25);
    const tdee = calculateTDEE(bmr, "very_active");
    const target = calculateCalorieTarget(tdee, "gain_muscle");
    expect(target).toBe(tdee + 300);
  });

  it("maintain goal equals TDEE", () => {
    const bmr = calculateBMR("female", 60, 165, 28);
    const tdee = calculateTDEE(bmr, "lightly_active");
    const target = calculateCalorieTarget(tdee, "maintain");
    expect(target).toBe(tdee);
  });

  it("lose_weight never goes below 1200 kcal minimum", () => {
    // Very small person: BMR ~1100, TDEE ~1320, target would be 820 → clamped to 1200
    const bmr = calculateBMR("female", 40, 145, 18);
    const tdee = calculateTDEE(bmr, "sedentary");
    const target = calculateCalorieTarget(tdee, "lose_weight");
    expect(target).toBeGreaterThanOrEqual(1200);
  });

  it("all activity levels produce valid TDEE values", () => {
    const bmr = 1700;
    const levels = ["sedentary", "lightly_active", "moderately_active", "very_active", "extra_active"];
    for (const level of levels) {
      const tdee = calculateTDEE(bmr, level);
      expect(tdee).toBeGreaterThan(bmr);
    }
  });
});

// ─── Notification Settings Validation ────────────────────────────────────────
describe("Notification Settings — input validation", () => {
  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isValidPhone = (phone: string) => phone.replace(/\s/g, "").length >= 8 && phone.startsWith("+");

  it("accepts valid email addresses", () => {
    expect(isValidEmail("user@example.com")).toBe(true);
    expect(isValidEmail("ahmed.k@nutritrack.app")).toBe(true);
  });

  it("rejects invalid email addresses", () => {
    expect(isValidEmail("not-an-email")).toBe(false);
    expect(isValidEmail("missing@tld")).toBe(false);
    expect(isValidEmail("")).toBe(false);
  });

  it("accepts valid international phone numbers", () => {
    expect(isValidPhone("+44 7911 123456")).toBe(true);
    expect(isValidPhone("+1 555 000 0000")).toBe(true);
    expect(isValidPhone("+20 100 123 4567")).toBe(true);
  });

  it("rejects phone numbers without country code", () => {
    expect(isValidPhone("07911123456")).toBe(false);
    expect(isValidPhone("555-0000")).toBe(false);
  });
});

// ─── Wearable Data — Metric Calculations ─────────────────────────────────────
describe("Wearable Connect — metric calculations", () => {
  const heartRateZone = (hr: number) => {
    if (hr < 60) return "resting";
    if (hr < 100) return "normal";
    if (hr < 140) return "fat_burn";
    return "cardio";
  };

  it("classifies resting heart rate correctly", () => {
    expect(heartRateZone(55)).toBe("resting");
    expect(heartRateZone(59)).toBe("resting");
  });

  it("classifies normal heart rate correctly", () => {
    expect(heartRateZone(60)).toBe("normal");
    expect(heartRateZone(80)).toBe("normal");
    expect(heartRateZone(99)).toBe("normal");
  });

  it("classifies fat burn zone correctly", () => {
    expect(heartRateZone(100)).toBe("fat_burn");
    expect(heartRateZone(120)).toBe("fat_burn");
    expect(heartRateZone(139)).toBe("fat_burn");
  });

  it("classifies cardio zone correctly", () => {
    expect(heartRateZone(140)).toBe("cardio");
    expect(heartRateZone(180)).toBe("cardio");
  });

  it("step goal percentage is bounded 0-100", () => {
    const pct = (steps: number, goal = 10000) => Math.min(100, Math.round((steps / goal) * 100));
    expect(pct(5000)).toBe(50);
    expect(pct(10000)).toBe(100);
    expect(pct(15000)).toBe(100); // capped
    expect(pct(0)).toBe(0);
  });

  it("sleep quality assessment is correct", () => {
    const sleepQuality = (hours: number) => hours >= 7 ? "good" : "below_recommended";
    expect(sleepQuality(7.5)).toBe("good");
    expect(sleepQuality(8)).toBe("good");
    expect(sleepQuality(6)).toBe("below_recommended");
    expect(sleepQuality(5.5)).toBe("below_recommended");
  });

  it("SpO2 normal range check is correct", () => {
    const isNormalSpO2 = (pct: number) => pct >= 95;
    expect(isNormalSpO2(98)).toBe(true);
    expect(isNormalSpO2(95)).toBe(true);
    expect(isNormalSpO2(94)).toBe(false);
  });
});
