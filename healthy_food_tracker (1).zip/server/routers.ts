import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { fetchFromOpenFoodFacts } from "./openFoodFacts";
import { findNutritionEntry } from "./nutritionReference";
import {
  addConsumptionLog,
  addFavourite,
  addWaterLog,
  addWeightLog,
  calculateBMR,
  calculateCalorieTarget,
  calculateMacroTargets,
  calculateTDEE,
  createProduct,
  createRecipe,
  deleteConsumptionLog,
  removeFavourite,
  deleteRecipe,
  deleteWaterLog,
  deleteWeightLog,
  findProductByExactName,
  getAllProducts,
  getConsumptionHistory,
  getDailyConsumptionLogs,
  getDailyWaterTotal,
  getDashboardStats,
  getFavourites,
  getOrCreateStreak,
  getProductByBarcode,
  getProductById,
  getRecipeById,
  getRecipeIngredients,
  getUserProfile,
  getUserRecipes,
  getWeeklyReport,
  getWeightLogs,
  isFavourite,
  searchProducts,
  updateConsumptionLog,
  updateStreak,
  upsertUserProfile,
  getWaterLogs,
  getDb,
} from "./db";

const MEAL_TYPE = z.enum(["breakfast", "lunch", "dinner", "snacks"]);

// ─── Profile Router ───────────────────────────────────────────────────────────

const profileRouter = router({
  /** Get the current user's body profile */
  get: protectedProcedure.query(async ({ ctx }) => {
    const profile = await getUserProfile(ctx.user.id);
    if (!profile) return null;

    const bmr = calculateBMR(profile.gender, profile.weight, profile.height, profile.age);
    const tdee = calculateTDEE(bmr, profile.activityLevel);
    const calorieTarget = calculateCalorieTarget(tdee, profile.goal);
    const macroTargets = calculateMacroTargets(calorieTarget);

    return {
      ...profile,
      bmr,
      tdee,
      calorieTarget,
      macroTargets,
    };
  }),

  /** Save (create or update) the current user's body profile */
  save: protectedProcedure
    .input(
      z.object({
        gender: z.enum(["male", "female"]),
        age: z.number().int().min(10).max(120),
        weight: z.number().min(20).max(500),   // kg
        height: z.number().min(50).max(300),   // cm
        activityLevel: z.enum([
          "sedentary",
          "lightly_active",
          "moderately_active",
          "very_active",
          "extra_active",
        ]),
        goal: z.enum(["lose_weight", "maintain", "gain_muscle"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const profile = await upsertUserProfile({ ...input, userId: ctx.user.id });
      if (!profile) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to save profile" });

      const bmr = calculateBMR(profile.gender, profile.weight, profile.height, profile.age);
      const tdee = calculateTDEE(bmr, profile.activityLevel);
      const calorieTarget = calculateCalorieTarget(tdee, profile.goal);
      const macroTargets = calculateMacroTargets(calorieTarget);

      return { ...profile, bmr, tdee, calorieTarget, macroTargets };
    }),
});

// ─── Products Router ──────────────────────────────────────────────────────────

const productsRouter = router({
  scan: protectedProcedure
    .input(z.object({ barcode: z.string().min(1) }))
    .mutation(async ({ input }) => {
      // 1. Check local database first (fast path)
      const localProduct = await getProductByBarcode(input.barcode);
      if (localProduct) {
        return { found: true as const, product: localProduct, source: "local" as const };
      }

      // 2. Fallback: query Open Food Facts
      const offData = await fetchFromOpenFoodFacts(input.barcode);
      if (!offData) {
        return { found: false as const, product: null, source: "none" as const };
      }

      // 3. Auto-save to local DB so future scans are instant
      try {
        const saved = await createProduct({
          barcode: input.barcode,
          name: offData.name,
          brand: offData.brand ?? undefined,
          category: offData.category ?? undefined,
          nutriScore: offData.nutriScore ?? undefined,
          novaGroup: offData.novaGroup ?? undefined,
          ingredients: offData.ingredients ?? undefined,
          calories: offData.calories ?? undefined,
          fat: offData.fat ?? undefined,
          saturatedFat: offData.saturatedFat ?? undefined,
          carbohydrates: offData.carbohydrates ?? undefined,
          sugars: offData.sugars ?? undefined,
          fiber: offData.fiber ?? undefined,
          proteins: offData.proteins ?? undefined,
          salt: offData.salt ?? undefined,
          sodium: offData.sodium ?? undefined,
        });
        if (saved) {
          return { found: true as const, product: saved, source: "open_food_facts" as const };
        }
      } catch (err) {
        console.warn("[scan] Failed to save OFF product to local DB:", err);
        // Return the OFF data even if save failed — better than nothing
        return {
          found: true as const,
          product: {
            id: -1,
            barcode: input.barcode,
            name: offData.name,
            brand: offData.brand,
            category: offData.category,
            imageUrl: offData.imageUrl,
            nutriScore: offData.nutriScore,
            novaGroup: offData.novaGroup,
            ingredients: offData.ingredients,
            calories: offData.calories,
            fat: offData.fat,
            saturatedFat: offData.saturatedFat,
            carbohydrates: offData.carbohydrates,
            sugars: offData.sugars,
            fiber: offData.fiber,
            proteins: offData.proteins,
            salt: offData.salt,
            sodium: offData.sodium,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          source: "open_food_facts" as const,
        };
      }

      return { found: false as const, product: null, source: "none" as const };
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const product = await getProductById(input.id);
      if (!product) throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
      return product;
    }),

  search: protectedProcedure
    .input(z.object({ query: z.string().min(1), limit: z.number().min(1).max(50).optional() }))
    .query(async ({ input }) => {
      return searchProducts(input.query, input.limit ?? 20);
    }),

  list: protectedProcedure
    .input(z.object({ limit: z.number().min(1).max(100).optional() }).optional())
    .query(async ({ input }) => {
      return getAllProducts(input?.limit ?? 50);
    }),

  /**
   * Scan a nutrition label image using AI vision and extract nutritional facts.
   * Returns structured nutritional data that the user can review and save.
   */
  scanLabel: protectedProcedure
    .input(z.object({ imageUrl: z.string().url() }))
    .mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are a nutrition label reader. Extract all nutritional information from the food label image provided.
Return ONLY a JSON object with these exact fields (use null for any field not visible):
{
  "name": string or null,
  "brand": string or null,
  "category": string or null,
  "ingredients": string or null,
  "servingSize": string or null,
  "calories": number or null,
  "fat": number or null,
  "saturatedFat": number or null,
  "carbohydrates": number or null,
  "sugars": number or null,
  "fiber": number or null,
  "proteins": number or null,
  "salt": number or null,
  "sodium": number or null
}
All numeric values should be per 100g unless the label only shows per serving — in that case, convert to per 100g if the serving size is visible.
Return ONLY the JSON, no markdown, no explanation.`,
          },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: { url: input.imageUrl, detail: "high" },
              },
              {
                type: "text",
                text: "Extract all nutritional information from this food label. Return only the JSON object.",
              },
            ],
          },
        ],
      });

      const rawContent = response?.choices?.[0]?.message?.content;
      const raw = typeof rawContent === "string" ? rawContent : "{}";
      let parsed: Record<string, unknown>;
      try {
        // Strip markdown code fences if present
        const cleaned = raw.replace(/```json?\n?/gi, "").replace(/```/g, "").trim();
        parsed = JSON.parse(cleaned);
      } catch {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "AI could not parse the nutrition label. Please try a clearer photo.",
        });
      }

      const toNum = (v: unknown) => (typeof v === "number" && !isNaN(v) ? v : null);
      const toStr = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);

      return {
        name: toStr(parsed.name),
        brand: toStr(parsed.brand),
        category: toStr(parsed.category),
        ingredients: toStr(parsed.ingredients),
        servingSize: toStr(parsed.servingSize),
        calories: toNum(parsed.calories),
        fat: toNum(parsed.fat),
        saturatedFat: toNum(parsed.saturatedFat),
        carbohydrates: toNum(parsed.carbohydrates),
        sugars: toNum(parsed.sugars),
        fiber: toNum(parsed.fiber),
        proteins: toNum(parsed.proteins),
        salt: toNum(parsed.salt),
        sodium: toNum(parsed.sodium),
      };
    }),

  /**
   * AI Food Photo Recognition — identify any food from a photo.
   * Two-pass strategy:
   *   Pass 1 (Vision): AI identifies food items, cooking method, portion context, and confidence.
   *   Pass 2 (Enrichment): Cross-reference each item against the local nutrition reference DB.
   *                        If found, replace AI estimates with verified nutritional data.
   * Returns up to 5 detected food items with nutritional data, Nutri-Score, allergens, vitamins,
   * data source indicator, and health tips.
   */
  recognizeFood: protectedProcedure
    .input(z.object({
      imageUrl: z.string().url(),
      portionGrams: z.number().min(1).max(5000).optional(), // optional portion size for scaling
    }))
    .mutation(async ({ input }) => {
      // ── Pass 1: Vision identification ─────────────────────────────────────────
      const visionResponse = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert nutritionist, food scientist, and chef with encyclopaedic knowledge of global cuisines, food composition, and dietary science.

Analyse the food photo with maximum detail. Identify EVERY distinct food item, ingredient, or dish visible.
For each item, provide:
- Precise identification (specific variety if visible, e.g. "Granny Smith Apple" not just "Apple")
- Cooking method (raw, grilled, fried, steamed, baked, etc.)
- Estimated portion visible (small/medium/large)
- Confidence level (0-100) based on visual clarity
- Complete nutritional profile per 100g based on standard food composition databases (USDA, EFSA)
- Nutri-Score (A=very healthy to E=unhealthy) based on the official French Nutri-Score algorithm
- NOVA group (1=unprocessed, 2=minimally processed, 3=processed, 4=ultra-processed)
- Any visible allergens
- Key vitamins and minerals present
- A practical health insight

Return ONLY a valid JSON object — no markdown, no explanation:
{
  "items": [
    {
      "name": string (specific food name),
      "commonName": string (simplified common name for database lookup),
      "description": string (2 sentences: what it is + cooking method/preparation),
      "category": string ("Fruit"|"Vegetable"|"Meat"|"Fish"|"Seafood"|"Grain"|"Legume"|"Dairy"|"Egg"|"Nuts"|"Seeds"|"Snack"|"Beverage"|"Meal"|"Dessert"|"Sauce"|"Condiment"),
      "cookingMethod": string or null,
      "portionSize": "small"|"medium"|"large",
      "confidence": number (0-100),
      "nutriScore": "A"|"B"|"C"|"D"|"E",
      "novaGroup": 1|2|3|4,
      "calories": number (kcal per 100g),
      "fat": number (g per 100g),
      "saturatedFat": number (g per 100g),
      "carbohydrates": number (g per 100g),
      "sugars": number (g per 100g),
      "fiber": number (g per 100g),
      "proteins": number (g per 100g),
      "salt": number (g per 100g),
      "allergens": string[] (e.g. ["Gluten", "Milk", "Eggs"]),
      "vitamins": string[] (top 3-4 vitamins/minerals, e.g. ["Vitamin C", "Potassium", "Folate"]),
      "healthTips": string (2-3 sentences of evidence-based health insight)
    }
  ],
  "mealDescription": string or null (if multiple items form a complete meal, describe it and its overall nutritional balance),
  "overallNutriScore": "A"|"B"|"C"|"D"|"E" or null (weighted average for the whole meal if applicable)
}
Return at most 5 items. If the image is not food, return { "items": [], "mealDescription": null, "overallNutriScore": null }.`,
          },
          {
            role: "user",
            content: [
              { type: "image_url", image_url: { url: input.imageUrl, detail: "high" } },
              { type: "text", text: "Analyse this food photo in detail. Identify every food item visible, provide precise nutritional data per 100g, and return only the JSON object." },
            ],
          },
        ],
      });

      const rawContent = visionResponse?.choices?.[0]?.message?.content;
      const raw = typeof rawContent === "string" ? rawContent : "{}";

      let parsed: {
        items: Record<string, unknown>[];
        mealDescription: string | null;
        overallNutriScore: string | null;
      };
      try {
        const cleaned = raw.replace(/```json?\n?/gi, "").replace(/```/g, "").trim();
        parsed = JSON.parse(cleaned);
      } catch {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "AI could not analyse the photo. Please try a clearer image with better lighting.",
        });
      }

      if (!Array.isArray(parsed.items)) {
        return { items: [], mealDescription: null, overallNutriScore: null };
      }

      const toNum = (v: unknown) => (typeof v === "number" && !isNaN(v) ? Math.max(0, v) : null);
      const toStr = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);
      const toScore = (v: unknown): "A" | "B" | "C" | "D" | "E" | null => {
        const s = typeof v === "string" ? v.toUpperCase() : null;
        return s === "A" || s === "B" || s === "C" || s === "D" || s === "E" ? s : null;
      };
      const toNova = (v: unknown): 1 | 2 | 3 | 4 | null => {
        const n = typeof v === "number" ? v : null;
        return (n === 1 || n === 2 || n === 3 || n === 4) ? n : null;
      };
      const toConf = (v: unknown) => (typeof v === "number" ? Math.round(Math.min(100, Math.max(0, v))) : 0);
      const toStrArr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);

      // ── Pass 2: Enrich with local nutrition reference database ─────────────────
      const items = (parsed.items as Record<string, unknown>[]).slice(0, 5).map((item) => {
        const aiName = toStr(item.name) ?? "Unknown food";
        const commonName = toStr(item.commonName) ?? aiName;
        const aiNutrition = {
          calories: toNum(item.calories),
          fat: toNum(item.fat),
          saturatedFat: toNum(item.saturatedFat),
          carbohydrates: toNum(item.carbohydrates),
          sugars: toNum(item.sugars),
          fiber: toNum(item.fiber),
          proteins: toNum(item.proteins),
          salt: toNum(item.salt),
        };

        // Try to find a verified entry in the local nutrition reference DB
        const refEntry = findNutritionEntry(commonName) ?? findNutritionEntry(aiName);

        // Merge: use reference data where available, fall back to AI estimates
        const dataSource: "reference_db" | "ai_estimate" = refEntry ? "reference_db" : "ai_estimate";
        const nutrition = refEntry
          ? {
              calories: refEntry.calories,
              fat: refEntry.fat,
              saturatedFat: refEntry.saturatedFat,
              carbohydrates: refEntry.carbohydrates,
              sugars: refEntry.sugars,
              fiber: refEntry.fiber,
              proteins: refEntry.proteins,
              salt: refEntry.salt,
            }
          : aiNutrition;

        // Scale to portion size if provided
        const portionFactor = input.portionGrams ? input.portionGrams / 100 : null;
        const portionNutrition = portionFactor
          ? {
              calories: nutrition.calories !== null ? Math.round(nutrition.calories * portionFactor) : null,
              fat: nutrition.fat !== null ? Math.round(nutrition.fat * portionFactor * 10) / 10 : null,
              proteins: nutrition.proteins !== null ? Math.round(nutrition.proteins * portionFactor * 10) / 10 : null,
              carbohydrates: nutrition.carbohydrates !== null ? Math.round(nutrition.carbohydrates * portionFactor * 10) / 10 : null,
            }
          : null;

        return {
          name: aiName,
          commonName,
          description: toStr(item.description),
          category: refEntry ? refEntry.category : (toStr(item.category) ?? "Food"),
          cookingMethod: toStr(item.cookingMethod),
          portionSize: (item.portionSize === "small" || item.portionSize === "medium" || item.portionSize === "large") ? item.portionSize as "small" | "medium" | "large" : "medium",
          confidence: toConf(item.confidence),
          nutriScore: refEntry ? refEntry.nutriScore : (toScore(item.nutriScore) ?? "C"),
          novaGroup: refEntry ? refEntry.novaGroup : (toNova(item.novaGroup) ?? 2),
          allergens: refEntry ? refEntry.allergens : toStrArr(item.allergens),
          vitamins: refEntry ? refEntry.vitamins : toStrArr(item.vitamins),
          healthTips: refEntry ? refEntry.healthTips : (toStr(item.healthTips) ?? ""),
          dataSource,
          // Per 100g nutrition
          ...nutrition,
          // Scaled portion nutrition (if portionGrams provided)
          portionNutrition,
        };
      });

      return {
        items,
        mealDescription: toStr(parsed.mealDescription),
        overallNutriScore: toScore(parsed.overallNutriScore),
      };
    }),

  create: protectedProcedure
    .input(
      z.object({
        barcode: z.string().optional(),
        name: z.string().min(1).max(255),
        brand: z.string().max(128).optional(),
        category: z.string().max(128).optional(),
        nutriScore: z.enum(["A", "B", "C", "D", "E"]).optional(),
        novaGroup: z.number().int().min(1).max(4).optional(),
        ingredients: z.string().optional(),
        calories: z.number().min(0).optional(),
        fat: z.number().min(0).optional(),
        saturatedFat: z.number().min(0).optional(),
        carbohydrates: z.number().min(0).optional(),
        sugars: z.number().min(0).optional(),
        fiber: z.number().min(0).optional(),
        proteins: z.number().min(0).optional(),
        salt: z.number().min(0).optional(),
        sodium: z.number().min(0).optional(),
      })
    )
    .mutation(async ({ input }) => {
      if (input.barcode) {
        const existing = await getProductByBarcode(input.barcode);
        if (existing) throw new TRPCError({ code: "CONFLICT", message: "A product with this barcode already exists" });
      }
      const product = await createProduct(input);
      if (!product) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create product" });
      return product;
    }),

  /** Find an existing product by exact name, or create it — used by AI Food Scanner */
  findOrCreate: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        category: z.string().max(128).optional(),
        nutriScore: z.enum(["A", "B", "C", "D", "E"]).optional(),
        novaGroup: z.number().int().min(1).max(4).optional(),
        calories: z.number().min(0).optional(),
        fat: z.number().min(0).optional(),
        saturatedFat: z.number().min(0).optional(),
        carbohydrates: z.number().min(0).optional(),
        sugars: z.number().min(0).optional(),
        fiber: z.number().min(0).optional(),
        proteins: z.number().min(0).optional(),
        salt: z.number().min(0).optional(),
      })
    )
    .mutation(async ({ input }) => {
      // Try to find an existing product with the same name first
      const existing = await findProductByExactName(input.name);
      if (existing) return existing;
      // Otherwise create a new one
      const product = await createProduct(input);
      if (!product) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create product" });
      return product;
    }),
});

// ─── Consumption Router ───────────────────────────────────────────────────────

const consumptionRouter = router({
  /** Add a product to the daily consumption log with meal type */
  add: protectedProcedure
    .input(
      z.object({
        productId: z.number().int().positive(),
        quantity: z.number().int().min(1).max(99).default(1),
        mealType: MEAL_TYPE.default("snacks"),
        notes: z.string().max(500).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const product = await getProductById(input.productId);
      if (!product) throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
      const log = await addConsumptionLog(ctx.user.id, input.productId, input.quantity, input.mealType, input.notes);
      return { log, product };
    }),

  getToday: protectedProcedure.query(async ({ ctx }) => {
    return getDailyConsumptionLogs(ctx.user.id, new Date());
  }),

  getHistory: protectedProcedure
    .input(z.object({ days: z.number().int().min(1).max(90).default(7) }))
    .query(async ({ input, ctx }) => {
      return getConsumptionHistory(ctx.user.id, input.days);
    }),

  update: protectedProcedure
    .input(
      z.object({
        logId: z.number().int().positive(),
        quantity: z.number().int().min(1).max(99),
        mealType: MEAL_TYPE.optional(),
        notes: z.string().max(500).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const updated = await updateConsumptionLog(input.logId, ctx.user.id, input.quantity, input.mealType, input.notes);
      if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "Log entry not found" });
      return updated;
    }),

  delete: protectedProcedure
    .input(z.object({ logId: z.number().int().positive() }))
    .mutation(async ({ input, ctx }) => {
      return deleteConsumptionLog(input.logId, ctx.user.id);
    }),
});

// ─── Dashboard Router ─────────────────────────────────────────────────────────

const dashboardRouter = router({
  stats: protectedProcedure.query(async ({ ctx }) => {
    const [stats, profile] = await Promise.all([
      getDashboardStats(ctx.user.id),
      getUserProfile(ctx.user.id),
    ]);
    if (!stats) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to load dashboard stats" });

    let calorieTarget: number | null = null;
    let macroTargets: { proteins: number; carbohydrates: number; fat: number } | null = null;

    if (profile) {
      const bmr = calculateBMR(profile.gender, profile.weight, profile.height, profile.age);
      const tdee = calculateTDEE(bmr, profile.activityLevel);
      calorieTarget = calculateCalorieTarget(tdee, profile.goal);
      macroTargets = calculateMacroTargets(calorieTarget);
    }

    return { ...stats, calorieTarget, macroTargets };
  }),
});

// ─── Water Router ────────────────────────────────────────────────────────────

const waterRouter = router({
  getToday: protectedProcedure.query(async ({ ctx }) => {
    const total = await getDailyWaterTotal(ctx.user.id, new Date());
    const logs = await getWaterLogs(ctx.user.id, new Date());
    const profile = await getUserProfile(ctx.user.id);
    return { totalMl: total, goalMl: profile?.waterGoalMl ?? 2000, logs };
  }),
  add: protectedProcedure
    .input(z.object({ amountMl: z.number().int().min(50).max(2000) }))
    .mutation(async ({ input, ctx }) => {
      const total = await addWaterLog(ctx.user.id, input.amountMl);
      return { totalMl: total };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input, ctx }) => deleteWaterLog(input.id, ctx.user.id)),
  updateGoal: protectedProcedure
    .input(z.object({ goalMl: z.number().int().min(500).max(5000) }))
    .mutation(async ({ input, ctx }) => {
      const profile = await getUserProfile(ctx.user.id);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profile not found" });
      const db = await import("./db").then(m => m.getDb());
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const { userProfiles } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      await db.update(userProfiles).set({ waterGoalMl: input.goalMl }).where(eq(userProfiles.userId, ctx.user.id));
      return { goalMl: input.goalMl };
    }),
});

// ─── Weight Router ────────────────────────────────────────────────────────────

const weightRouter = router({
  list: protectedProcedure
    .input(z.object({ days: z.number().int().min(7).max(365).default(90) }))
    .query(async ({ input, ctx }) => getWeightLogs(ctx.user.id, input.days)),
  add: protectedProcedure
    .input(z.object({ weightKg: z.number().min(20).max(500), notes: z.string().optional() }))
    .mutation(async ({ input, ctx }) => addWeightLog(ctx.user.id, input.weightKg, input.notes)),
  delete: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input, ctx }) => deleteWeightLog(input.id, ctx.user.id)),
});

// ─── Streak Router ────────────────────────────────────────────────────────────

const streakRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => getOrCreateStreak(ctx.user.id)),
});

// ─── Favourites Router ────────────────────────────────────────────────────────

const favouritesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getFavourites(ctx.user.id)),
  add: protectedProcedure
    .input(z.object({ productId: z.number().int() }))
    .mutation(async ({ input, ctx }) => addFavourite(ctx.user.id, input.productId)),
  remove: protectedProcedure
    .input(z.object({ productId: z.number().int() }))
    .mutation(async ({ input, ctx }) => removeFavourite(ctx.user.id, input.productId)),
  check: protectedProcedure
    .input(z.object({ productId: z.number().int() }))
    .query(async ({ input, ctx }) => ({ isFavourite: await isFavourite(ctx.user.id, input.productId) })),
  quickLog: protectedProcedure
    .input(z.object({ productId: z.number().int(), mealType: MEAL_TYPE }))
    .mutation(async ({ input, ctx }) => {
      const log = await addConsumptionLog(ctx.user.id, input.productId, 1, input.mealType);
      await updateStreak(ctx.user.id);
      return log;
    }),
});

// ─── Recipes Router ───────────────────────────────────────────────────────────

const recipesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => getUserRecipes(ctx.user.id)),
  get: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .query(async ({ input, ctx }) => {
      const recipe = await getRecipeById(input.id);
      if (!recipe || recipe.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      const ingredients = await getRecipeIngredients(input.id);
      return { ...recipe, ingredients };
    }),
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(255),
      description: z.string().optional(),
      servings: z.number().int().min(1).max(50).default(1),
      ingredients: z.array(z.object({
        productId: z.number().int(),
        amountGrams: z.number().min(1).max(5000),
      })).min(1),
    }))
    .mutation(async ({ input, ctx }) => {
      // Calculate nutrition totals from ingredients
      let totalCalories = 0, totalProtein = 0, totalCarbs = 0, totalFat = 0, totalFiber = 0;
      const scoreMap: Record<string, number> = {};
      for (const ing of input.ingredients) {
        const p = await getProductById(ing.productId);
        if (!p) continue;
        const factor = ing.amountGrams / 100;
        totalCalories += (p.calories ?? 0) * factor;
        totalProtein += (p.proteins ?? 0) * factor;
        totalCarbs += (p.carbohydrates ?? 0) * factor;
        totalFat += (p.fat ?? 0) * factor;
        totalFiber += (p.fiber ?? 0) * factor;
        if (p.nutriScore) scoreMap[p.nutriScore] = (scoreMap[p.nutriScore] ?? 0) + 1;
      }
      // Determine overall nutriScore (most common)
      const nutriScore = (Object.entries(scoreMap).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "C") as "A" | "B" | "C" | "D" | "E";
      const perServing = input.servings;
      return createRecipe(
        {
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          servings: input.servings,
          totalCalories: Math.round(totalCalories / perServing),
          totalProtein: Math.round(totalProtein * 10 / perServing) / 10,
          totalCarbs: Math.round(totalCarbs * 10 / perServing) / 10,
          totalFat: Math.round(totalFat * 10 / perServing) / 10,
          totalFiber: Math.round(totalFiber * 10 / perServing) / 10,
          nutriScore,
        },
        input.ingredients
      );
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input, ctx }) => deleteRecipe(input.id, ctx.user.id)),

  analyzePhoto: protectedProcedure
    .input(z.object({ imageUrl: z.string().url() }))
    .mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert nutritionist and chef. Analyze the food photo and identify ALL visible ingredients or food items.
For each item, estimate the portion size and calculate accurate nutritional values per the estimated weight.
Return ONLY a valid JSON object with this exact structure:
{
  "recipeName": string,
  "description": string,
  "estimatedServings": number,
  "ingredients": [
    {
      "name": string,
      "estimatedGrams": number,
      "calories": number,
      "protein": number,
      "carbs": number,
      "fat": number,
      "fiber": number,
      "nutriScore": "A" | "B" | "C" | "D" | "E"
    }
  ],
  "totalCalories": number,
  "totalProtein": number,
  "totalCarbs": number,
  "totalFat": number,
  "totalFiber": number,
  "nutriScore": "A" | "B" | "C" | "D" | "E",
  "confidence": number
}
Rules:
- estimatedGrams should be realistic portion sizes (e.g. 150g chicken breast, 80g pasta)
- All macro values are for the estimated gram weight of that ingredient (not per 100g)
- nutriScore: A=very healthy, B=healthy, C=average, D=poor, E=very poor
- confidence: 0-1 float indicating how confident you are in the identification
- If you cannot identify food in the image, return an empty ingredients array`,
          },
          {
            role: "user" as const,
            content: [
              { type: "text" as const, text: "Analyze this meal photo and identify all ingredients with their nutritional values:" },
              { type: "image_url" as const, image_url: { url: input.imageUrl, detail: "high" as const } },
            ],
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "recipe_analysis",
            strict: true,
            schema: {
              type: "object",
              properties: {
                recipeName: { type: "string" },
                description: { type: "string" },
                estimatedServings: { type: "number" },
                ingredients: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      estimatedGrams: { type: "number" },
                      calories: { type: "number" },
                      protein: { type: "number" },
                      carbs: { type: "number" },
                      fat: { type: "number" },
                      fiber: { type: "number" },
                      nutriScore: { type: "string" },
                    },
                    required: ["name", "estimatedGrams", "calories", "protein", "carbs", "fat", "fiber", "nutriScore"],
                    additionalProperties: false,
                  },
                },
                totalCalories: { type: "number" },
                totalProtein: { type: "number" },
                totalCarbs: { type: "number" },
                totalFat: { type: "number" },
                totalFiber: { type: "number" },
                nutriScore: { type: "string" },
                confidence: { type: "number" },
              },
              required: ["recipeName", "description", "estimatedServings", "ingredients", "totalCalories", "totalProtein", "totalCarbs", "totalFat", "totalFiber", "nutriScore", "confidence"],
              additionalProperties: false,
            },
          },
        },
      });
      const rawContent = response.choices?.[0]?.message?.content;
      const raw = typeof rawContent === "string" ? rawContent : null;
      if (!raw) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "AI analysis returned no result" });
      try {
        return JSON.parse(raw) as {
          recipeName: string;
          description: string;
          estimatedServings: number;
          ingredients: Array<{
            name: string;
            estimatedGrams: number;
            calories: number;
            protein: number;
            carbs: number;
            fat: number;
            fiber: number;
            nutriScore: string;
          }>;
          totalCalories: number;
          totalProtein: number;
          totalCarbs: number;
          totalFat: number;
          totalFiber: number;
          nutriScore: string;
          confidence: number;
        };
      } catch {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to parse AI analysis" });
      }
    }),

  saveFromPhoto: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(255),
      description: z.string().optional(),
      servings: z.number().int().min(1).max(50).default(1),
      totalCalories: z.number(),
      totalProtein: z.number(),
      totalCarbs: z.number(),
      totalFat: z.number(),
      totalFiber: z.number(),
      nutriScore: z.enum(["A", "B", "C", "D", "E"]).default("C"),
      ingredients: z.array(z.object({
        name: z.string(),
        estimatedGrams: z.number(),
        calories: z.number(),
        protein: z.number(),
        carbs: z.number(),
        fat: z.number(),
        fiber: z.number(),
        nutriScore: z.string().optional(),
      })),
    }))
    .mutation(async ({ input, ctx }) => {
      // For each AI ingredient, find or create a product in the DB
      const dbIngredients: Array<{ productId: number; amountGrams: number }> = [];
      for (const ing of input.ingredients) {
        let product = await findProductByExactName(ing.name);
        if (!product) {
          const perHundred = ing.estimatedGrams > 0 ? 100 / ing.estimatedGrams : 1;
          product = await createProduct({
            name: ing.name,
            category: "AI Identified",
            nutriScore: (["A","B","C","D","E"].includes(ing.nutriScore ?? "") ? ing.nutriScore : "C") as "A"|"B"|"C"|"D"|"E",
            calories: Math.round(ing.calories * perHundred),
            proteins: Math.round(ing.protein * perHundred * 10) / 10,
            carbohydrates: Math.round(ing.carbs * perHundred * 10) / 10,
            fat: Math.round(ing.fat * perHundred * 10) / 10,
            fiber: Math.round(ing.fiber * perHundred * 10) / 10,
          });
        }
        if (product) {
          dbIngredients.push({ productId: product.id, amountGrams: Math.round(ing.estimatedGrams) });
        }
      }
      const nutriScore = (["A","B","C","D","E"].includes(input.nutriScore) ? input.nutriScore : "C") as "A"|"B"|"C"|"D"|"E";
      return createRecipe(
        {
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          servings: input.servings,
          totalCalories: Math.round(input.totalCalories / input.servings),
          totalProtein: Math.round(input.totalProtein * 10 / input.servings) / 10,
          totalCarbs: Math.round(input.totalCarbs * 10 / input.servings) / 10,
          totalFat: Math.round(input.totalFat * 10 / input.servings) / 10,
          totalFiber: Math.round(input.totalFiber * 10 / input.servings) / 10,
          nutriScore,
        },
        dbIngredients
      );
    }),
  log: protectedProcedure
    .input(z.object({ recipeId: z.number().int(), mealType: MEAL_TYPE }))
    .mutation(async ({ input, ctx }) => {
      const recipe = await getRecipeById(input.recipeId);
      if (!recipe || recipe.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      // Create a virtual product for the recipe if it doesn't exist
      let product = await findProductByExactName(recipe.name);
      if (!product) {
        product = await createProduct({
          name: recipe.name,
          category: "Recipe",
          nutriScore: recipe.nutriScore ?? "C",
          calories: recipe.totalCalories ?? 0,
          proteins: recipe.totalProtein ?? 0,
          carbohydrates: recipe.totalCarbs ?? 0,
          fat: recipe.totalFat ?? 0,
          fiber: recipe.totalFiber ?? 0,
        });
      }
      if (!product) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const log = await addConsumptionLog(ctx.user.id, product.id, 1, input.mealType);
      await updateStreak(ctx.user.id);
      return log;
    }),
});

// ─── Weekly Report Router ─────────────────────────────────────────────────────

const reportRouter = router({
  weekly: protectedProcedure.query(async ({ ctx }) => {
    const report = await getWeeklyReport(ctx.user.id);
    const profile = await getUserProfile(ctx.user.id);
    let calorieTarget = 2000;
    if (profile) {
      const bmr = calculateBMR(profile.gender, profile.weight, profile.height, profile.age);
      const tdee = calculateTDEE(bmr, profile.activityLevel);
      calorieTarget = calculateCalorieTarget(tdee, profile.goal);
    }
    return { ...report, calorieTarget };
  }),
});
// ─── Meal Plan Router (defined earlier in file) ───────────────────────────────
const mealPlanRouter = router({
  listWeek: protectedProcedure
    .input(z.object({ weekStart: z.string() })) // YYYY-MM-DD of Monday
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      const { mealPlans, products } = await import("../drizzle/schema");
      const { eq, and, gte, lte } = await import("drizzle-orm");
      // Build 7 dates from weekStart
      const start = new Date(input.weekStart);
      const end = new Date(start);
      end.setDate(end.getDate() + 6);
      const endStr = end.toISOString().slice(0, 10);
      const rows = await db
        .select()
        .from(mealPlans)
        .leftJoin(products, eq(mealPlans.productId, products.id))
        .where(
          and(
            eq(mealPlans.userId, ctx.user.id.toString()),
            gte(mealPlans.date, input.weekStart),
            lte(mealPlans.date, endStr)
          )
        )
        .orderBy(mealPlans.date);
      return rows.map((r) => ({ ...r.meal_plans, product: r.products }));
    }),

  add: protectedProcedure
    .input(
      z.object({
        date: z.string(),
        mealType: MEAL_TYPE,
        productId: z.number(),
        amountGrams: z.number().min(1).max(2000),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { mealPlans } = await import("../drizzle/schema");
      await db.insert(mealPlans).values({
        userId: ctx.user.id.toString(),
        date: input.date,
        mealType: input.mealType,
        productId: input.productId,
        amountGrams: input.amountGrams,
        notes: input.notes,
        createdAt: Date.now(),
      });
      return { success: true };
    }),

  remove: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { mealPlans } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      await db
        .delete(mealPlans)
        .where(and(eq(mealPlans.id, input.id), eq(mealPlans.userId, ctx.user.id.toString())));
      return { success: true };
    }),

  logToday: protectedProcedure
    .input(z.object({ mealPlanId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { mealPlans, consumptionLogs } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const [plan] = await db.select().from(mealPlans).where(eq(mealPlans.id, input.mealPlanId));
      if (!plan || plan.userId !== ctx.user.id.toString()) throw new Error("Not found");
      const today = new Date().toISOString().slice(0, 10);
      await db.insert(consumptionLogs).values({
        userId: ctx.user.id,
        productId: plan.productId,
        quantity: Math.round(plan.amountGrams),
        mealType: plan.mealType,
      });
      return { success: true };
    }),
});

// ─── Friends Router ───────────────────────────────────────────────────────────
const friendsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { friendships, users } = await import("../drizzle/schema");
    const { eq, or, and } = await import("drizzle-orm");
    const myId = ctx.user.id.toString();
    const rows = await db.select().from(friendships).where(
      or(eq(friendships.userId, myId), eq(friendships.friendId, myId))
    );
    return rows;
  }),

  sendRequest: protectedProcedure
    .input(z.object({ friendOpenId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { friendships, users } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      // Find target user by openId
      const [target] = await db.select().from(users).where(eq(users.openId, input.friendOpenId));
      if (!target) throw new Error("User not found");
      const myId = ctx.user.id.toString();
      const friendId = target.id.toString();
      if (myId === friendId) throw new Error("Cannot add yourself");
      await db.insert(friendships).values({
        userId: myId,
        friendId,
        status: "pending",
        createdAt: Date.now(),
      });
      return { success: true, friendName: target.name };
    }),

  respond: protectedProcedure
    .input(z.object({ id: z.number(), accept: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { friendships } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      await db
        .update(friendships)
        .set({ status: input.accept ? "accepted" : "declined" })
        .where(
          and(eq(friendships.id, input.id), eq(friendships.friendId, ctx.user.id.toString()))
        );
      return { success: true };
    }),

  remove: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { friendships } = await import("../drizzle/schema");
      const { eq, and, or } = await import("drizzle-orm");
      const myId = ctx.user.id.toString();
      await db
        .delete(friendships)
        .where(
          and(
            eq(friendships.id, input.id),
            or(eq(friendships.userId, myId), eq(friendships.friendId, myId))
          )
        );
      return { success: true };
    }),
});

// ─── Challenges Router ────────────────────────────────────────────────────────
const challengesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { challenges, challengeParticipants } = await import("../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const myId = ctx.user.id.toString();
    const participating = await db
      .select()
      .from(challengeParticipants)
      .where(eq(challengeParticipants.userId, myId));
    const ids = participating.map((p) => p.challengeId);
    if (ids.length === 0) return [];
    const { inArray } = await import("drizzle-orm");
    const rows = await db.select().from(challenges).where(inArray(challenges.id, ids));
    return rows;
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(3).max(200),
        description: z.string().max(500).optional(),
        type: z.enum(["streak", "calories", "water", "steps"]),
        targetValue: z.number().min(1),
        startDate: z.string(),
        endDate: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { challenges, challengeParticipants } = await import("../drizzle/schema");
      const [result] = await db.insert(challenges).values({
        creatorId: ctx.user.id.toString(),
        title: input.title,
        description: input.description,
        type: input.type,
        targetValue: input.targetValue,
        startDate: input.startDate,
        endDate: input.endDate,
        status: "active",
        createdAt: Date.now(),
      });
      const challengeId = (result as any).insertId as number;
      // Auto-join creator
      await db.insert(challengeParticipants).values({
        challengeId,
        userId: ctx.user.id.toString(),
        userName: ctx.user.name ?? "Anonymous",
        currentScore: 0,
        joinedAt: Date.now(),
      });
      return { success: true, id: challengeId };
    }),

  join: protectedProcedure
    .input(z.object({ challengeId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { challengeParticipants } = await import("../drizzle/schema");
      await db.insert(challengeParticipants).values({
        challengeId: input.challengeId,
        userId: ctx.user.id.toString(),
        userName: ctx.user.name ?? "Anonymous",
        currentScore: 0,
        joinedAt: Date.now(),
      });
      return { success: true };
    }),

  leaderboard: protectedProcedure
    .input(z.object({ challengeId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      const { challengeParticipants } = await import("../drizzle/schema");
      const { eq, desc } = await import("drizzle-orm");
      return db
        .select()
        .from(challengeParticipants)
        .where(eq(challengeParticipants.challengeId, input.challengeId))
        .orderBy(desc(challengeParticipants.currentScore));
    }),

  updateScore: protectedProcedure
    .input(z.object({ challengeId: z.number(), score: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { challengeParticipants } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      await db
        .update(challengeParticipants)
        .set({ currentScore: input.score })
        .where(
          and(
            eq(challengeParticipants.challengeId, input.challengeId),
            eq(challengeParticipants.userId, ctx.user.id.toString())
          )
        );
      return { success: true };
    }),

  nudge: protectedProcedure
    .input(z.object({ challengeId: z.number(), targetUserId: z.string(), message: z.string().max(200) }))
    .mutation(async ({ ctx, input }) => {
      // In a real app this would send a push notification; here we use the built-in notify
      const { notifyOwner } = await import("./_core/notification");
      await notifyOwner({
        title: `💪 Nudge from ${ctx.user.name ?? "a friend"}!`,
        content: input.message,
      });
      return { success: true };
    }),
});

/// ─── Notifications Router ──────────────────────────────────────────────────────
const notificationsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { notifications } = await import("../drizzle/schema");
    const { eq, desc } = await import("drizzle-orm");
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, ctx.user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(50);
  }),
  unreadCount: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return 0;
    const { notifications } = await import("../drizzle/schema");
    const { eq, and } = await import("drizzle-orm");
    const rows = await db
      .select()
      .from(notifications)
      .where(and(eq(notifications.userId, ctx.user.id), eq(notifications.isRead, false)));
    return rows.length;
  }),
  markRead: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { notifications } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(and(eq(notifications.id, input.id), eq(notifications.userId, ctx.user.id)));
      return { success: true };
    }),
  markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");
    const { notifications } = await import("../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, ctx.user.id));
    return { success: true };
  }),
  sendTest: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("DB unavailable");
    const { notifications } = await import("../drizzle/schema");
    await db.insert(notifications).values({
      userId: ctx.user.id,
      type: "general",
      title: "🔔 Test Notification",
      message: "Your NutriTrack notifications are working correctly!",
      isRead: false,
    });
    return { success: true };
  }),
});

// ─── Activity Router ──────────────────────────────────────────────────────────
const activityRouter = router({
  friendsFeed: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { friendships, friendActivity, users } = await import("../drizzle/schema");
    const { eq, or, and, desc, inArray } = await import("drizzle-orm");
    const myId = ctx.user.id.toString();
    // Get accepted friend IDs
    const friendRows = await db
      .select()
      .from(friendships)
      .where(
        and(
          or(eq(friendships.userId, myId), eq(friendships.friendId, myId)),
          eq(friendships.status, "accepted")
        )
      );
    const friendIds = friendRows.map((f) =>
      f.userId === myId ? parseInt(f.friendId) : parseInt(f.userId)
    );
    if (friendIds.length === 0) return [];
    const activities = await db
      .select()
      .from(friendActivity)
      .where(inArray(friendActivity.userId, friendIds))
      .orderBy(desc(friendActivity.createdAt))
      .limit(30);
    // Enrich with user names
    const userRows = await db
      .select({ id: users.id, name: users.name })
      .from(users)
      .where(inArray(users.id, friendIds));
    const userMap = Object.fromEntries(userRows.map((u) => [u.id, u.name]));
    return activities.map((a) => ({ ...a, friendName: userMap[a.userId] ?? "Friend" }));
  }),
  logActivity: protectedProcedure
    .input(
      z.object({
        activityType: z.enum(["logged_meal", "hit_streak", "completed_challenge", "hit_water_goal"]),
        calories: z.number().optional(),
        streakCount: z.number().optional(),
        challengeTitle: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { friendActivity } = await import("../drizzle/schema");
      await db.insert(friendActivity).values({
        userId: ctx.user.id,
        activityType: input.activityType,
        calories: input.calories,
        streakCount: input.streakCount,
        challengeTitle: input.challengeTitle,
      });
      return { success: true };
    }),
});

// ─── Challenge Templates Router ───────────────────────────────────────────────
const challengeTemplatesRouter = router({
  list: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const { challengeTemplates } = await import("../drizzle/schema");
    return db.select().from(challengeTemplates);
  }),
  startFromTemplate: protectedProcedure
    .input(z.object({ templateId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { challengeTemplates, userChallenges } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const [template] = await db
        .select()
        .from(challengeTemplates)
        .where(eq(challengeTemplates.id, input.templateId));
      if (!template) throw new TRPCError({ code: "NOT_FOUND" });
      const [result] = await db.insert(userChallenges).values({
        userId: ctx.user.id,
        templateId: input.templateId,
        currentProgress: 0,
        status: "active",
      });
      return { success: true, id: (result as any).insertId as number, template };
    }),
  myActive: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { userChallenges, challengeTemplates } = await import("../drizzle/schema");
    const { eq, and } = await import("drizzle-orm");
    const rows = await db
      .select()
      .from(userChallenges)
      .leftJoin(challengeTemplates, eq(userChallenges.templateId, challengeTemplates.id))
      .where(
        and(
          eq(userChallenges.userId, ctx.user.id),
          eq(userChallenges.status, "active")
        )
      );
    return rows.map((r) => ({ ...r.user_challenges, template: r.challenge_templates }));
  }),
  updateProgress: protectedProcedure
    .input(z.object({ id: z.number(), progress: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      const { userChallenges, challengeTemplates, notifications } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      const [uc] = await db
        .select()
        .from(userChallenges)
        .leftJoin(challengeTemplates, eq(userChallenges.templateId, challengeTemplates.id))
        .where(and(eq(userChallenges.id, input.id), eq(userChallenges.userId, ctx.user.id)));
      if (!uc) throw new TRPCError({ code: "NOT_FOUND" });
      const isComplete = input.progress >= (uc.challenge_templates?.targetValue ?? Infinity);
      await db
        .update(userChallenges)
        .set({
          currentProgress: input.progress,
          status: isComplete ? "completed" : "active",
        })
        .where(and(eq(userChallenges.id, input.id), eq(userChallenges.userId, ctx.user.id)));
      if (isComplete) {
        await db.insert(notifications).values({
          userId: ctx.user.id,
          type: "challenge_completed",
          title: `🏆 Challenge Complete!`,
          message: `You completed "${uc.challenge_templates?.title ?? "the challenge"}"! Great work!`,
          isRead: false,
        });
      }
      return { success: true, completed: isComplete };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  profile: profileRouter,
  products: productsRouter,
  consumption: consumptionRouter,
  dashboard: dashboardRouter,
  water: waterRouter,
  weight: weightRouter,
  streak: streakRouter,
  favourites: favouritesRouter,
   recipes: recipesRouter,
  report: reportRouter,
  mealPlan: mealPlanRouter,
  friends: friendsRouter,
  challenges: challengesRouter,
  notifications: notificationsRouter,
  activity: activityRouter,
  challengeTemplates: challengeTemplatesRouter,
});
export type AppRouter = typeof appRouter;
