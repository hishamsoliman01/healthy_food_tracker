/**
 * Tests for the Open Food Facts fallback integration.
 * All fetch calls are mocked — no real HTTP requests are made.
 */
import { describe, expect, it, vi, beforeEach } from "vitest";
import { fetchFromOpenFoodFacts } from "./openFoodFacts";

// ─── Mock global fetch ────────────────────────────────────────────────────────

const mockFetch = vi.fn();
vi.stubGlobal("fetch", mockFetch);

function makeOFFResponse(overrides: Record<string, unknown> = {}) {
  return {
    status: 1,
    product: {
      product_name: "Test Cereal",
      brands: "TestBrand, OtherBrand",
      categories: "Cereals, Breakfast cereals",
      nutriscore_grade: "b",
      nova_group: 3,
      ingredients_text: "Whole grain oats, sugar, salt",
      nutriments: {
        "energy-kcal_100g": 380,
        fat_100g: 7.5,
        "saturated-fat_100g": 1.2,
        carbohydrates_100g: 68,
        sugars_100g: 12,
        fiber_100g: 8.5,
        proteins_100g: 11,
        salt_100g: 0.6,
        sodium_100g: 0.24,
      },
      image_front_url: "https://images.openfoodfacts.org/test.jpg",
      ...overrides,
    },
  };
}

beforeEach(() => {
  mockFetch.mockReset();
});

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("fetchFromOpenFoodFacts", () => {
  it("returns mapped product data for a known barcode", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse(),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");

    expect(result).not.toBeNull();
    expect(result!.name).toBe("Test Cereal");
    expect(result!.brand).toBe("TestBrand"); // only first brand
    expect(result!.nutriScore).toBe("B");    // uppercased
    expect(result!.novaGroup).toBe(3);
    expect(result!.calories).toBe(380);
    expect(result!.fat).toBe(7.5);
    expect(result!.saturatedFat).toBe(1.2);
    expect(result!.carbohydrates).toBe(68);
    expect(result!.sugars).toBe(12);
    expect(result!.fiber).toBe(8.5);
    expect(result!.proteins).toBe(11);
    expect(result!.salt).toBe(0.6);
    expect(result!.sodium).toBe(0.24);
    expect(result!.imageUrl).toBe("https://images.openfoodfacts.org/test.jpg");
    expect(result!.source).toBe("open_food_facts");
  });

  it("returns null when OFF status is 0 (product not found)", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ status: 0, status_verbose: "no code or invalid code" }),
    });

    const result = await fetchFromOpenFoodFacts("0000000000000");
    expect(result).toBeNull();
  });

  it("returns null when product has no name", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ product_name: "" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result).toBeNull();
  });

  it("returns null on HTTP error", async () => {
    mockFetch.mockResolvedValueOnce({ ok: false, status: 500 });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result).toBeNull();
  });

  it("returns null on network failure", async () => {
    mockFetch.mockRejectedValueOnce(new Error("Network error"));

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result).toBeNull();
  });

  it("handles missing nutriments gracefully", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        status: 1,
        product: { product_name: "Plain Product", nutriments: {} },
      }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result).not.toBeNull();
    expect(result!.calories).toBeNull();
    expect(result!.fat).toBeNull();
    expect(result!.nutriScore).toBeNull();
    expect(result!.novaGroup).toBeNull();
  });

  it("normalises nutriscore grade to uppercase", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ nutriscore_grade: "c" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result!.nutriScore).toBe("C");
  });

  it("returns null for an unrecognised nutriscore grade", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ nutriscore_grade: "unknown" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result!.nutriScore).toBeNull();
  });

  it("extracts the most specific category from a comma-separated list", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ categories: "Snacks, Sweet snacks, Chocolate bars" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result!.category).toBe("Chocolate bars");
  });

  it("strips language prefix from category tags", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ categories: "en:cereals-and-potatoes" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    // Language prefix stripped, hyphens replaced with spaces
    expect(result!.category).toBe("cereals and potatoes");
  });

  it("uses only the first brand from a comma-separated brands string", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => makeOFFResponse({ brands: "Nestlé, Maggi, Nescafé" }),
    });

    const result = await fetchFromOpenFoodFacts("1234567890123");
    expect(result!.brand).toBe("Nestlé");
  });
});
