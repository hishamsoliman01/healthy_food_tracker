import { describe, expect, it } from "vitest";
import { calculateBMR, calculateTDEE, calculateCalorieTarget, calculateMacroTargets } from "./db";

describe("BMR calculation (Mifflin-St Jeor)", () => {
  it("calculates male BMR correctly", () => {
    // 10×75 + 6.25×180 − 5×30 + 5 = 750 + 1125 − 150 + 5 = 1730
    const bmr = calculateBMR("male", 75, 180, 30);
    expect(bmr).toBe(1730);
  });

  it("calculates female BMR correctly", () => {
    // 10×60 + 6.25×165 − 5×25 − 161 = 600 + 1031.25 − 125 − 161 = 1345
    const bmr = calculateBMR("female", 60, 165, 25);
    expect(bmr).toBe(1345);
  });

  it("handles edge case: very young male", () => {
    const bmr = calculateBMR("male", 50, 150, 10);
    expect(bmr).toBeGreaterThan(0);
  });
});

describe("TDEE calculation", () => {
  it("applies sedentary multiplier", () => {
    const tdee = calculateTDEE(1730, "sedentary");
    expect(tdee).toBe(Math.round(1730 * 1.2));
  });

  it("applies moderately_active multiplier", () => {
    const tdee = calculateTDEE(1730, "moderately_active");
    expect(tdee).toBe(Math.round(1730 * 1.55));
  });

  it("applies extra_active multiplier", () => {
    const tdee = calculateTDEE(1730, "extra_active");
    expect(tdee).toBe(Math.round(1730 * 1.9));
  });

  it("falls back to sedentary for unknown activity level", () => {
    const tdee = calculateTDEE(1730, "unknown_level");
    expect(tdee).toBe(Math.round(1730 * 1.2));
  });
});

describe("Calorie target calculation", () => {
  it("subtracts 500 kcal for lose_weight goal", () => {
    const target = calculateCalorieTarget(2500, "lose_weight");
    expect(target).toBe(2000);
  });

  it("adds 300 kcal for gain_muscle goal", () => {
    const target = calculateCalorieTarget(2500, "gain_muscle");
    expect(target).toBe(2800);
  });

  it("returns TDEE unchanged for maintain goal", () => {
    const target = calculateCalorieTarget(2500, "maintain");
    expect(target).toBe(2500);
  });

  it("enforces minimum of 1200 kcal for lose_weight", () => {
    const target = calculateCalorieTarget(1500, "lose_weight");
    expect(target).toBe(1200);
  });
});

describe("Macro targets calculation", () => {
  it("calculates balanced macro split from calorie target", () => {
    const macros = calculateMacroTargets(2000);
    // Protein: 25% of 2000 = 500 kcal / 4 = 125g
    expect(macros.proteins).toBe(125);
    // Carbs: 50% of 2000 = 1000 kcal / 4 = 250g
    expect(macros.carbohydrates).toBe(250);
    // Fat: 25% of 2000 = 500 kcal / 9 ≈ 56g
    expect(macros.fat).toBe(Math.round(500 / 9));
  });

  it("all macro values are positive", () => {
    const macros = calculateMacroTargets(1500);
    expect(macros.proteins).toBeGreaterThan(0);
    expect(macros.carbohydrates).toBeGreaterThan(0);
    expect(macros.fat).toBeGreaterThan(0);
  });
});
