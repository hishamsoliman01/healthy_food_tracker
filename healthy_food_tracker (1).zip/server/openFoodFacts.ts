/**
 * Open Food Facts API client
 * Docs: https://openfoodfacts.github.io/openfoodfacts-server/api/
 *
 * Used as a fallback when a barcode is not found in the local database.
 * Products fetched from OFF are automatically saved to the local DB so
 * subsequent scans of the same barcode are served from the local cache.
 */

const OFF_BASE_URL = "https://world.openfoodfacts.org/api/v2/product";

/** Fields we request from OFF to keep the payload small */
const FIELDS = [
  "product_name",
  "brands",
  "categories",
  "nutriscore_grade",
  "nova_group",
  "ingredients_text",
  "nutriments",
  "serving_size",
  "image_front_url",
].join(",");

/** Raw shape of the OFF API response we care about */
type OFFNutriments = {
  "energy-kcal_100g"?: number;
  fat_100g?: number;
  "saturated-fat_100g"?: number;
  carbohydrates_100g?: number;
  sugars_100g?: number;
  fiber_100g?: number;
  proteins_100g?: number;
  salt_100g?: number;
  sodium_100g?: number;
};

type OFFProduct = {
  product_name?: string;
  brands?: string;
  categories?: string;
  nutriscore_grade?: string;
  nova_group?: number | string;
  ingredients_text?: string;
  nutriments?: OFFNutriments;
  serving_size?: string;
  image_front_url?: string;
};

type OFFResponse = {
  status: number; // 1 = found, 0 = not found
  product?: OFFProduct;
};

/** Mapped product data ready to insert into our local schema */
export type OFFMappedProduct = {
  name: string;
  brand: string | null;
  category: string | null;
  nutriScore: "A" | "B" | "C" | "D" | "E" | null;
  novaGroup: number | null;
  ingredients: string | null;
  calories: number | null;
  fat: number | null;
  saturatedFat: number | null;
  carbohydrates: number | null;
  sugars: number | null;
  fiber: number | null;
  proteins: number | null;
  salt: number | null;
  sodium: number | null;
  imageUrl: string | null;
  source: "open_food_facts";
};

/** Normalise an OFF nutriscore grade string to our enum or null */
function mapNutriScore(grade?: string): "A" | "B" | "C" | "D" | "E" | null {
  if (!grade) return null;
  const upper = grade.toUpperCase();
  if (upper === "A" || upper === "B" || upper === "C" || upper === "D" || upper === "E") {
    return upper as "A" | "B" | "C" | "D" | "E";
  }
  return null;
}

/** Safely parse a number from an OFF nutriments field */
function toNum(v: number | string | undefined | null): number | null {
  if (v == null) return null;
  const n = typeof v === "string" ? parseFloat(v) : v;
  return isNaN(n) ? null : n;
}

/** Extract the most readable category label from an OFF categories string */
function mapCategory(categories?: string): string | null {
  if (!categories) return null;
  // OFF returns a comma-separated list; take the last (most specific) entry
  const parts = categories.split(",").map(s => s.trim()).filter(Boolean);
  const last = parts[parts.length - 1];
  if (!last) return null;
  // Remove language prefix like "en:" or "fr:"
  return last.replace(/^[a-z]{2}:/, "").replace(/-/g, " ");
}

/**
 * Fetch a product from Open Food Facts by barcode.
 * Returns `null` if the product is not found or the request fails.
 */
export async function fetchFromOpenFoodFacts(barcode: string): Promise<OFFMappedProduct | null> {
  try {
    const url = `${OFF_BASE_URL}/${encodeURIComponent(barcode)}.json?fields=${FIELDS}`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "NutriTrack/1.0 (healthy-food-tracker; contact@nutritrack.app)",
      },
      signal: AbortSignal.timeout(8000), // 8 second timeout
    });

    if (!response.ok) {
      console.warn(`[OFF] HTTP ${response.status} for barcode ${barcode}`);
      return null;
    }

    const data = (await response.json()) as OFFResponse;

    // status 0 = product not found in OFF
    if (data.status !== 1 || !data.product) {
      return null;
    }

    const p = data.product;
    const n = p.nutriments ?? {};

    // OFF sometimes returns products with no name — skip those
    const name = p.product_name?.trim();
    if (!name) return null;

    return {
      name,
      brand: p.brands?.split(",")[0]?.trim() || null,
      category: mapCategory(p.categories),
      nutriScore: mapNutriScore(p.nutriscore_grade),
      novaGroup: toNum(p.nova_group),
      ingredients: p.ingredients_text?.trim() || null,
      calories: toNum(n["energy-kcal_100g"]),
      fat: toNum(n.fat_100g),
      saturatedFat: toNum(n["saturated-fat_100g"]),
      carbohydrates: toNum(n.carbohydrates_100g),
      sugars: toNum(n.sugars_100g),
      fiber: toNum(n.fiber_100g),
      proteins: toNum(n.proteins_100g),
      salt: toNum(n.salt_100g),
      sodium: toNum(n.sodium_100g),
      imageUrl: p.image_front_url || null,
      source: "open_food_facts",
    };
  } catch (err) {
    // Network error or timeout — fail gracefully
    console.warn(`[OFF] Failed to fetch barcode ${barcode}:`, err instanceof Error ? err.message : err);
    return null;
  }
}
