import { cn } from "@/lib/utils";
import type { Product } from "../../../drizzle/schema";

interface NutritionalInfoProps {
  product: Product;
  className?: string;
}

interface NutrientRowProps {
  label: string;
  value: number | null | undefined;
  unit: string;
  highlight?: boolean;
  indent?: boolean;
}

function NutrientRow({ label, value, unit, highlight, indent }: NutrientRowProps) {
  return (
    <div className={cn("flex justify-between items-center py-1.5 border-b border-border/50 last:border-0", highlight && "font-semibold")}>
      <span className={cn("text-sm text-foreground", indent && "pl-4 text-muted-foreground")}>{label}</span>
      <span className={cn("text-sm tabular-nums", highlight ? "text-foreground font-semibold" : "text-muted-foreground")}>
        {value != null ? `${value.toFixed(1)} ${unit}` : "—"}
      </span>
    </div>
  );
}

export function NutritionalInfo({ product, className }: NutritionalInfoProps) {
  return (
    <div className={cn("rounded-xl border border-border bg-card p-4", className)}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground">Nutritional Values</h3>
        <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">per 100g</span>
      </div>
      <div>
        <NutrientRow label="Energy" value={product.calories} unit="kcal" highlight />
        <NutrientRow label="Fat" value={product.fat} unit="g" highlight />
        <NutrientRow label="of which saturates" value={product.saturatedFat} unit="g" indent />
        <NutrientRow label="Carbohydrates" value={product.carbohydrates} unit="g" highlight />
        <NutrientRow label="of which sugars" value={product.sugars} unit="g" indent />
        <NutrientRow label="Fibre" value={product.fiber} unit="g" />
        <NutrientRow label="Protein" value={product.proteins} unit="g" highlight />
        <NutrientRow label="Salt" value={product.salt} unit="g" />
      </div>
    </div>
  );
}

/** Compact macro summary for log entries */
export function MacroSummary({ product, quantity = 1 }: { product: Product; quantity?: number }) {
  const macros = [
    { label: "Cal", value: product.calories, unit: "kcal", color: "text-orange-500" },
    { label: "Protein", value: product.proteins, unit: "g", color: "text-blue-500" },
    { label: "Carbs", value: product.carbohydrates, unit: "g", color: "text-yellow-600" },
    { label: "Fat", value: product.fat, unit: "g", color: "text-red-500" },
  ];

  return (
    <div className="flex gap-3 flex-wrap">
      {macros.map((m) => (
        <div key={m.label} className="text-center">
          <div className={cn("text-xs font-semibold tabular-nums", m.color)}>
            {m.value != null ? Math.round(m.value * quantity) : "—"}
            <span className="text-muted-foreground font-normal ml-0.5">{m.unit}</span>
          </div>
          <div className="text-[10px] text-muted-foreground">{m.label}</div>
        </div>
      ))}
    </div>
  );
}
