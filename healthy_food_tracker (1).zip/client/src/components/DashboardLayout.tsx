import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  useSidebar,
} from "@/components/ui/sidebar";
import { getLoginUrl } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import {
  BarChart2,
  BarChart3,
  Bell,
  Bluetooth,
  CalendarDays,
  Camera,
  Clock,
  Droplets,
  Flame,
  Heart,
  Leaf,
  LogOut,
  Plus,
  ScanSearch,
  Scale,
  Search,
  Settings,
  Sparkles,
  Swords,
  Trophy,
  User,
  Users,
  UtensilsCrossed,
  X,
  Zap,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { Button } from "./ui/button";

const menuGroups = [
  {
    label: "Main",
    items: [
      { icon: BarChart3, label: "Dashboard", path: "/dashboard" },
      { icon: BarChart2, label: "Weekly Report", path: "/report" },
    ],
  },
  {
    label: "Log Food",
    items: [
      { icon: Camera, label: "Scan Barcode", path: "/scan" },
      { icon: Sparkles, label: "AI Label Scanner", path: "/scan/label" },
      { icon: ScanSearch, label: "AI Food Scanner", path: "/scan/photo" },
      { icon: Search, label: "Search Foods", path: "/search" },
      { icon: Heart, label: "Favourites", path: "/favourites" },
      { icon: UtensilsCrossed, label: "Recipes", path: "/recipes" },
      { icon: Plus, label: "Add Product", path: "/products/new" },
    ],
  },
  {
    label: "Health",
    items: [
      { icon: Droplets, label: "Water Tracker", path: "/water" },
      { icon: Scale, label: "Weight Log", path: "/weight" },
      { icon: Flame, label: "Streaks", path: "/streaks" },
      { icon: Bluetooth, label: "Wearable", path: "/wearable" },
    ],
  },
  {
    label: "Social",
    items: [
      { icon: CalendarDays, label: "Meal Planner", path: "/meal-plan" },
      { icon: Users, label: "Friends", path: "/friends" },
      { icon: Trophy, label: "Challenges", path: "/challenges" },
    ],
  },
  {
    label: "History",
    items: [
      { icon: Clock, label: "History", path: "/history" },
    ],
  },
  {
    label: "Settings",
    items: [
      { icon: User, label: "My Profile", path: "/profile" },
      { icon: Bell, label: "Notifications", path: "/notifications" },
    ],
  },
];

// FAB log-food options
const fabOptions = [
  { icon: Camera, label: "Scan Barcode", path: "/scan", color: "bg-emerald-500" },
  { icon: Sparkles, label: "AI Label Scanner", path: "/scan/label", color: "bg-teal-500" },
  { icon: ScanSearch, label: "AI Food Scanner", path: "/scan/photo", color: "bg-cyan-500" },
  { icon: Search, label: "Search Foods", path: "/search", color: "bg-sky-500" },
  { icon: UtensilsCrossed, label: "Log Recipe", path: "/recipes", color: "bg-indigo-500" },
];

// Mobile bottom dock items (Home/Report/FAB placeholder/History/Profile)
const mobileDocItems = [
  { icon: BarChart3, label: "Home", path: "/dashboard" },
  { icon: BarChart2, label: "Report", path: "/report" },
  { icon: Clock, label: "History", path: "/history" },
  { icon: User, label: "Profile", path: "/profile" },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 220;
const MIN_WIDTH = 200;
const MAX_WIDTH = 380;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-8 p-8 max-w-sm w-full text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Leaf className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-2">Welcome to NutriTrack</h1>
            <p className="text-sm text-muted-foreground">
              Sign in to access your personal nutrition dashboard, track meals, and monitor your health goals.
            </p>
          </div>
          <Button
            onClick={() => { window.location.href = getLoginUrl(window.location.pathname); }}
            size="lg"
            className="w-full shadow-lg"
          >
            Sign in to Continue
          </Button>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
}) {
  const { user, logout } = useAuth();
  const { data: unreadCount = 0 } = trpc.notifications.unreadCount.useQuery(undefined, {
    refetchInterval: 30000,
  });
  const [location, setLocation] = useLocation();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  // Flatten for active detection
  const allItems = menuGroups.flatMap(g => g.items);
  const activeMenuItem = allItems.find(item => location === item.path || location.startsWith(item.path + "/"));

  // Today's date string
  const todayStr = new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  // Close FAB sheet when navigating
  useEffect(() => {
    setFabOpen(false);
  }, [location]);

  return (
    <>
      {/* ─── Desktop sidebar ─── */}
      {!isMobile && (
        <div className="relative" ref={sidebarRef}>
          <Sidebar collapsible="icon" className="border-r border-border/50" disableTransition={isResizing}>
            {/* Logo header */}
            <SidebarHeader className="h-14 justify-center border-b border-border/40">
              <div className="flex items-center gap-3 px-3 w-full">
                <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center shrink-0">
                  <Leaf className="h-4 w-4 text-primary-foreground" />
                </div>
                {!isCollapsed && (
                  <span className="font-bold tracking-tight truncate text-sidebar-foreground text-sm">
                    NutriTrack
                  </span>
                )}
              </div>
            </SidebarHeader>

            {/* Nav groups */}
            <SidebarContent className="gap-0 py-2 overflow-y-auto flex-1 min-h-0">
              {menuGroups.map((group) => (
                <SidebarGroup key={group.label} className="py-0">
                  {!isCollapsed && (
                    <SidebarGroupLabel className="px-4 py-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/50">
                      {group.label}
                    </SidebarGroupLabel>
                  )}
                  <SidebarMenu className="px-2">
                    {group.items.map(item => {
                      const isActive = location === item.path || location.startsWith(item.path + "/");
                      return (
                        <SidebarMenuItem key={item.path}>
                          <SidebarMenuButton
                            isActive={isActive}
                            onClick={() => setLocation(item.path)}
                            tooltip={item.label}
                            className={`h-8 transition-all font-normal text-sm relative ${
                              isActive
                                ? "bg-primary/10 text-primary before:absolute before:left-0 before:top-1 before:bottom-1 before:w-0.5 before:rounded-full before:bg-primary"
                                : "hover:bg-accent/60"
                            }`}
                          >
                            <item.icon className={`h-4 w-4 shrink-0 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                            <span className={isActive ? "font-semibold" : ""}>{item.label}</span>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      );
                    })}
                  </SidebarMenu>
                </SidebarGroup>
              ))}
            </SidebarContent>

            {/* Upgrade to Pro CTA */}
            {!isCollapsed && (
              <div className="px-3 pb-2">
                <div className="rounded-xl bg-primary/10 border border-primary/20 p-3">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Zap className="w-4 h-4 text-primary shrink-0" />
                    <p className="text-xs font-semibold text-foreground">Upgrade to Pro</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-relaxed mb-2.5">
                    Unlock unlimited AI scanning, full history &amp; weekly reports.
                  </p>
                  <button
                    onClick={() => setLocation("/pricing")}
                    className="w-full text-xs font-semibold bg-primary text-primary-foreground rounded-lg py-1.5 hover:bg-primary/90 transition-colors"
                  >
                    See Plans →
                  </button>
                </div>
              </div>
            )}

            {/* User footer */}
            <SidebarFooter className="p-3 border-t border-border/40">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-accent/50 transition-colors w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                    <Avatar className="h-8 w-8 border shrink-0">
                      <AvatarFallback className="text-xs font-semibold bg-primary/10 text-primary">
                        {user?.name?.charAt(0).toUpperCase() ?? "U"}
                      </AvatarFallback>
                    </Avatar>
                    {!isCollapsed && (
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold truncate leading-none text-foreground">{user?.name || "User"}</p>
                        <p className="text-[10px] text-muted-foreground truncate mt-1">Free Plan</p>
                      </div>
                    )}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52">
                  <DropdownMenuItem onClick={() => setLocation("/profile")} className="cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings &amp; Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/notifications")} className="cursor-pointer">
                    <Bell className="mr-2 h-4 w-4" />
                    <span>Notifications</span>
                    {unreadCount > 0 && (
                      <span className="ml-auto text-[10px] font-bold bg-red-500 text-white rounded-full px-1.5 py-0.5">
                        {unreadCount > 9 ? "9+" : unreadCount}
                      </span>
                    )}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarFooter>
          </Sidebar>

          {/* Resize handle */}
          {!isCollapsed && (
            <div
              className="absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors"
              onMouseDown={() => setIsResizing(true)}
              style={{ zIndex: 50 }}
            />
          )}
        </div>
      )}

      {/* ─── Main content area ─── */}
      <SidebarInset className={isMobile ? "!ml-0" : ""}>
        {/* Desktop topbar */}
        {!isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-3">
              <div>
                <p className="text-sm font-semibold text-foreground leading-none">
                  {activeMenuItem?.label ?? "Dashboard"}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">{todayStr}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Search bar */}
              <div className="relative hidden md:flex items-center">
                <Search className="absolute left-2.5 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
                <input
                  type="text"
                  placeholder="Search foods..."
                  onKeyDown={(e) => { if (e.key === "Enter") setLocation(`/search?q=${encodeURIComponent((e.target as HTMLInputElement).value)}`); }}
                  className="h-8 w-48 rounded-lg border border-input bg-background pl-8 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-ring transition-all focus:w-64"
                />
              </div>
              {/* Notification bell */}
              <button
                onClick={() => setLocation("/notifications")}
                className="relative h-8 w-8 rounded-lg hover:bg-accent flex items-center justify-center transition-colors"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4 text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </button>
              {/* Log Meal button */}
              <button
                onClick={() => setLocation("/scan")}
                className="flex items-center gap-1.5 h-8 px-3 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors"
              >
                <Plus className="h-3.5 w-3.5" />
                Log Meal
              </button>
            </div>
          </div>
        )}

        {/* Mobile topbar */}
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-3 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                <Leaf className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-semibold text-sm text-foreground">
                {activeMenuItem?.label ?? "NutriTrack"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLocation("/notifications")}
                className="relative h-9 w-9 rounded-lg hover:bg-accent flex items-center justify-center transition-colors"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4 text-muted-foreground" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Page content */}
        <main className={`flex-1 ${isMobile ? "pb-20" : ""}`}>{children}</main>

        {/* ─── Mobile bottom dock ─── */}
        {isMobile && (
          <>
            <div className="fixed bottom-0 left-0 right-0 z-50 bg-background/98 backdrop-blur-md border-t border-border/50 flex items-center justify-around px-1 h-16">
              {/* Left 2 items */}
              {mobileDocItems.slice(0, 2).map((item) => {
                const isActive = location === item.path || location.startsWith(item.path + "/");
                return (
                  <button
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className={`flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all ${
                      isActive ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <item.icon className={`h-5 w-5 ${isActive ? "text-primary" : ""}`} />
                    <span className={`text-[10px] font-medium ${isActive ? "text-primary" : ""}`}>
                      {item.label}
                    </span>
                  </button>
                );
              })}

              {/* FAB center button */}
              <button
                onClick={() => setFabOpen(true)}
                className="flex flex-col items-center justify-center w-14 h-14 rounded-full bg-primary shadow-lg shadow-primary/30 transition-all active:scale-95 -mt-5"
                aria-label="Log food"
              >
                <Plus className="h-6 w-6 text-white" />
              </button>

              {/* Right 2 items */}
              {mobileDocItems.slice(2).map((item) => {
                const isActive = location === item.path || location.startsWith(item.path + "/");
                return (
                  <button
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className={`flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all ${
                      isActive ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <item.icon className={`h-5 w-5 ${isActive ? "text-primary" : ""}`} />
                    <span className={`text-[10px] font-medium ${isActive ? "text-primary" : ""}`}>
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* ─── FAB Log Food Bottom Sheet ─── */}
            {fabOpen && (
              <>
                {/* Backdrop */}
                <div
                  className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm"
                  onClick={() => setFabOpen(false)}
                />
                {/* Sheet */}
                <div
                  className="fixed bottom-0 left-0 right-0 z-[70] bg-background rounded-t-2xl shadow-2xl"
                  style={{ animation: "slideUp 250ms ease" }}
                >
                  <div className="flex items-center justify-between px-5 pt-5 pb-3">
                    <div>
                      <h3 className="text-base font-bold text-foreground">Log Food</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">Choose how to add a meal</p>
                    </div>
                    <button
                      onClick={() => setFabOpen(false)}
                      className="h-8 w-8 rounded-full bg-muted flex items-center justify-center hover:bg-accent transition-colors"
                    >
                      <X className="h-4 w-4 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="px-4 pb-8 grid grid-cols-1 gap-2">
                    {fabOptions.map((opt) => (
                      <button
                        key={opt.path}
                        onClick={() => { setFabOpen(false); setLocation(opt.path); }}
                        className="flex items-center gap-4 p-3.5 rounded-xl bg-muted/50 hover:bg-accent/60 active:scale-[0.98] transition-all text-left"
                      >
                        <div className={`w-10 h-10 rounded-xl ${opt.color} flex items-center justify-center shrink-0`}>
                          <opt.icon className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-sm font-medium text-foreground">{opt.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </SidebarInset>

      {/* Slide-up animation */}
      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </>
  );
}
