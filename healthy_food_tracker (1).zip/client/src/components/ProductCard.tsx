import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Plus, Tag } from "lucide-react";
import { useLocation } from "wouter";
import type { Product } from "../../../drizzle/schema";
import { NutriScoreBadge } from "./NutriScoreBadge";

interface ProductCardProps {
  product: Product;
  onAddToLog?: (product: Product) => void;
  compact?: boolean;
  className?: string;
}

export function ProductCard({ product, onAddToLog, compact = false, className }: ProductCardProps) {
  const [, navigate] = useLocation();

  return (
    <Card
      className={cn(
        "group hover:shadow-md transition-all duration-200 cursor-pointer border-border/60",
        className
      )}
      onClick={() => navigate(`/products/${product.id}`)}
    >
      <CardContent className={cn("p-4", compact && "p-3")}>
        <div className="flex items-start gap-3">
          {/* Nutri-score */}
          <NutriScoreBadge score={product.nutriScore} size={compact ? "sm" : "md"} />

          {/* Product info */}
          <div className="flex-1 min-w-0">
            <p className={cn("font-semibold text-foreground truncate", compact ? "text-sm" : "text-base")}>
              {product.name}
            </p>
            {product.brand && (
              <p className="text-xs text-muted-foreground truncate">{product.brand}</p>
            )}
            {!compact && product.category && (
              <div className="flex items-center gap-1 mt-1">
                <Tag className="w-3 h-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{product.category}</span>
              </div>
            )}
            {!compact && (
              <div className="flex gap-3 mt-2 text-xs text-muted-foreground">
                {product.calories != null && (
                  <span className="font-medium text-orange-600">{Math.round(product.calories)} kcal</span>
                )}
                {product.proteins != null && (
                  <span>P: {product.proteins}g</span>
                )}
                {product.carbohydrates != null && (
                  <span>C: {product.carbohydrates}g</span>
                )}
                {product.fat != null && (
                  <span>F: {product.fat}g</span>
                )}
              </div>
            )}
          </div>

          {/* Add button */}
          {onAddToLog && (
            <Button
              size="icon"
              variant="ghost"
              className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-primary hover:bg-primary/10"
              onClick={(e) => {
                e.stopPropagation();
                onAddToLog(product);
              }}
              title="Add to today's log"
            >
              <Plus className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
