import { cn } from "@/lib/utils";

type NutriScore = "A" | "B" | "C" | "D" | "E";

interface NutriScoreBadgeProps {
  score: NutriScore | null | undefined;
  size?: "sm" | "md" | "lg" | "xl";
  showLabel?: boolean;
  className?: string;
}

const scoreLabels: Record<NutriScore, string> = {
  A: "Excellent",
  B: "Good",
  C: "Average",
  D: "Poor",
  E: "Bad",
};

const scoreClasses: Record<NutriScore, string> = {
  A: "nutri-a",
  B: "nutri-b",
  C: "nutri-c",
  D: "nutri-d",
  E: "nutri-e",
};

const sizeClasses = {
  sm: "w-6 h-6 text-xs font-bold",
  md: "w-8 h-8 text-sm font-bold",
  lg: "w-12 h-12 text-lg font-bold",
  xl: "w-16 h-16 text-2xl font-extrabold",
};

export function NutriScoreBadge({ score, size = "md", showLabel = false, className }: NutriScoreBadgeProps) {
  if (!score) {
    return (
      <div className={cn("rounded-full flex items-center justify-center bg-muted text-muted-foreground", sizeClasses[size], className)}>
        ?
      </div>
    );
  }

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className={cn(
          "rounded-full flex items-center justify-center shadow-sm",
          sizeClasses[size],
          scoreClasses[score]
        )}
        title={`Nutri-Score ${score}: ${scoreLabels[score]}`}
      >
        {score}
      </div>
      {showLabel && (
        <span className="text-sm text-muted-foreground font-medium">{scoreLabels[score]}</span>
      )}
    </div>
  );
}

/** Full Nutri-Score scale bar showing all 5 grades */
export function NutriScoreScale({ activeScore }: { activeScore?: NutriScore | null }) {
  const scores: NutriScore[] = ["A", "B", "C", "D", "E"];
  return (
    <div className="flex items-center gap-1">
      {scores.map((s) => (
        <div
          key={s}
          className={cn(
            "flex items-center justify-center rounded font-bold transition-all",
            scoreClasses[s],
            activeScore === s
              ? "w-10 h-10 text-base shadow-md ring-2 ring-white ring-offset-1"
              : "w-7 h-7 text-xs opacity-50"
          )}
        >
          {s}
        </div>
      ))}
    </div>
  );
}
