import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { PWAInstallBanner } from "./components/PWAInstallBanner";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Favourites from "./pages/Favourites";
import FoodPhotoScanner from "./pages/FoodPhotoScanner";
import History from "./pages/History";
import Home from "./pages/Home";
import LabelScanner from "./pages/LabelScanner";
import NewProduct from "./pages/NewProduct";
import ProductDetail from "./pages/ProductDetail";
import Profile from "./pages/Profile";
import Scanner from "./pages/Scanner";
import Search from "./pages/Search";
import Streaks from "./pages/Streaks";
import WaterTracker from "./pages/WaterTracker";
import WeeklyReport from "./pages/WeeklyReport";
import WeightLog from "./pages/WeightLog";
import Recipes from "./pages/Recipes";
import Onboarding from "./pages/Onboarding";
import Notifications from "./pages/Notifications";
import Wearable from "./pages/Wearable";
import MealPlan from "./pages/MealPlan";
import Friends from "./pages/Friends";
import Challenges from "./pages/Challenges";
import Pricing from "./pages/Pricing";
import Teams from "./pages/Teams";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/scan" component={Scanner} />
      <Route path="/search" component={Search} />
      <Route path="/history" component={History} />
      <Route path="/scan/label" component={LabelScanner} />
      <Route path="/scan/photo" component={FoodPhotoScanner} />
      <Route path="/profile" component={Profile} />
      <Route path="/products/new" component={NewProduct} />
      <Route path="/products/:id" component={ProductDetail} />
      <Route path="/favourites" component={Favourites} />
      <Route path="/water" component={WaterTracker} />
      <Route path="/weight" component={WeightLog} />
      <Route path="/streaks" component={Streaks} />
      <Route path="/report" component={WeeklyReport} />
      <Route path="/recipes" component={Recipes} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/wearable" component={Wearable} />
      <Route path="/meal-plan" component={MealPlan} />
      <Route path="/friends" component={Friends} />
      <Route path="/challenges" component={Challenges} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/teams" component={Teams} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
          <PWAInstallBanner />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
