import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  ChevronLeft,
  Flame,
  Loader2,
  Ruler,
  Scale,
  Scan,
  Target,
  User,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
// Inline nutrition calculations (mirrors server-side Mifflin-St Jeor)
function calculateBMRClient(gender: string, weight: number, height: number, age: number): number {
  const base = 10 * weight + 6.25 * height - 5 * age;
  return Math.round(gender === "male" ? base + 5 : base - 161);
}
const ACTIVITY_MULTIPLIERS: Record<string, number> = {
  sedentary: 1.2, lightly_active: 1.375, moderately_active: 1.55, very_active: 1.725, extra_active: 1.9,
};
function calculateTDEEClient(bmr: number, activityLevel: string): number {
  return Math.round(bmr * (ACTIVITY_MULTIPLIERS[activityLevel] ?? 1.2));
}
function calculateCalorieTargetClient(tdee: number, goal: string): number {
  if (goal === "lose_weight") return Math.max(1200, tdee - 500);
  if (goal === "gain_muscle") return tdee + 300;
  return tdee;
}

const GOALS = [
  { value: "lose_weight", label: "Lose Weight", icon: "🔥", desc: "Reduce body fat with a calorie deficit" },
  { value: "maintain", label: "Stay Healthy", icon: "⚖️", desc: "Maintain current weight and improve nutrition" },
  { value: "gain_muscle", label: "Build Muscle", icon: "💪", desc: "Increase muscle mass with a calorie surplus" },
];

const ACTIVITY_LEVELS = [
  { value: "sedentary", label: "Sedentary", icon: "🪑", desc: "Little or no exercise" },
  { value: "lightly_active", label: "Lightly Active", icon: "🚶", desc: "Light exercise 1–3 days/week" },
  { value: "moderately_active", label: "Moderately Active", icon: "🏃", desc: "Moderate exercise 3–5 days/week" },
  { value: "very_active", label: "Very Active", icon: "🏋️", desc: "Hard exercise 6–7 days/week" },
  { value: "extra_active", label: "Extra Active", icon: "⚡", desc: "Very hard exercise + physical job" },
];

const STEPS = ["Goal", "Body Data", "Activity", "Ready"];

export default function Onboarding() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(0);
  const [goal, setGoal] = useState<"lose_weight" | "maintain" | "gain_muscle">("maintain");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [activityLevel, setActivityLevel] = useState<"sedentary" | "lightly_active" | "moderately_active" | "very_active" | "extra_active">("moderately_active");

  const saveProfile = trpc.profile.save.useMutation({
    onSuccess: () => navigate("/dashboard"),
    onError: (e) => toast.error(e.message),
  });

  const ageNum = parseInt(age) || 0;
  const weightNum = parseFloat(weight) || 0;
  const heightNum = parseFloat(height) || 0;

  const bmr = ageNum && weightNum && heightNum
    ? calculateBMRClient(gender, weightNum, heightNum, ageNum)
    : 0;
  const tdee = bmr ? calculateTDEEClient(bmr, activityLevel) : 0;
  const calorieTarget = tdee ? calculateCalorieTargetClient(tdee, goal) : 0;

  const canProceedStep1 = !!goal;
  const canProceedStep2 = ageNum >= 10 && ageNum <= 120 && weightNum >= 20 && weightNum <= 400 && heightNum >= 100 && heightNum <= 250;
  const canProceedStep3 = !!activityLevel;

  const handleFinish = () => {
    if (!canProceedStep2) { toast.error("Please fill in all body data correctly"); return; }
    saveProfile.mutate({
      gender,
      age: ageNum,
      weight: weightNum,
      height: heightNum,
      activityLevel,
      goal,
    });
  };

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-emerald-50/30 flex flex-col">
      {/* Header */}
      <div className="px-4 pt-8 pb-4 max-w-lg mx-auto w-full">
        <div className="flex items-center justify-between mb-6">
          {step > 0 ? (
            <button onClick={() => setStep(s => s - 1)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ChevronLeft className="w-4 h-4" />
              Back
            </button>
          ) : <div />}
          <span className="text-xs text-muted-foreground font-medium">Step {step + 1} of {STEPS.length}</span>
        </div>
        <Progress value={progress} className="h-2 mb-2" />
        <div className="flex justify-between mt-2">
          {STEPS.map((s, i) => (
            <span key={s} className={`text-[10px] font-medium ${i <= step ? "text-primary" : "text-muted-foreground"}`}>{s}</span>
          ))}
        </div>
      </div>

      <div className="flex-1 px-4 pb-8 max-w-lg mx-auto w-full">
        {/* Step 0: Goal */}
        {step === 0 && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">What's your goal?</h1>
              <p className="text-muted-foreground mt-1">We'll personalise your calorie target and recommendations.</p>
            </div>
            <div className="space-y-3">
              {GOALS.map(g => (
                <button
                  key={g.value}
                  onClick={() => setGoal(g.value as typeof goal)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
                    goal === g.value
                      ? "border-primary bg-primary/5 shadow-sm"
                      : "border-border bg-card hover:border-primary/40"
                  }`}
                >
                  <span className="text-3xl">{g.icon}</span>
                  <div>
                    <p className="font-semibold text-foreground">{g.label}</p>
                    <p className="text-sm text-muted-foreground">{g.desc}</p>
                  </div>
                  {goal === g.value && <CheckCircle2 className="w-5 h-5 text-primary ml-auto shrink-0" />}
                </button>
              ))}
            </div>
            <Button
              onClick={() => setStep(1)}
              disabled={!canProceedStep1}
              className="w-full h-12 text-base gap-2"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 1: Body Data */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Your body data</h1>
              <p className="text-muted-foreground mt-1">Used to calculate your personalised daily calorie target.</p>
            </div>

            {/* Gender */}
            <div className="space-y-2">
              <Label>Biological Sex</Label>
              <div className="grid grid-cols-2 gap-3">
                {[{ value: "male", label: "Male", icon: "♂️" }, { value: "female", label: "Female", icon: "♀️" }].map(g => (
                  <button
                    key={g.value}
                    onClick={() => setGender(g.value as "male" | "female")}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border-2 font-medium transition-all ${
                      gender === g.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
                    }`}
                  >
                    <span>{g.icon}</span> {g.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" /> Age</Label>
                <Input
                  type="number"
                  placeholder="25"
                  value={age}
                  onChange={e => setAge(e.target.value)}
                  min={10}
                  max={120}
                  className="text-center"
                />
                <p className="text-[10px] text-muted-foreground text-center">years</p>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5"><Scale className="w-3.5 h-3.5" /> Weight</Label>
                <Input
                  type="number"
                  placeholder="70"
                  value={weight}
                  onChange={e => setWeight(e.target.value)}
                  min={20}
                  max={400}
                  className="text-center"
                />
                <p className="text-[10px] text-muted-foreground text-center">kg</p>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5"><Ruler className="w-3.5 h-3.5" /> Height</Label>
                <Input
                  type="number"
                  placeholder="175"
                  value={height}
                  onChange={e => setHeight(e.target.value)}
                  min={100}
                  max={250}
                  className="text-center"
                />
                <p className="text-[10px] text-muted-foreground text-center">cm</p>
              </div>
            </div>

            {bmr > 0 && (
              <div className="bg-muted/50 rounded-xl p-4 space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Your Estimates</p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Basal Metabolic Rate</span>
                  <span className="font-semibold text-foreground">{bmr} kcal</span>
                </div>
              </div>
            )}

            <Button
              onClick={() => setStep(2)}
              disabled={!canProceedStep2}
              className="w-full h-12 text-base gap-2"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 2: Activity Level */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">How active are you?</h1>
              <p className="text-muted-foreground mt-1">Choose your typical weekly activity level.</p>
            </div>
            <div className="space-y-2">
              {ACTIVITY_LEVELS.map(a => (
                <button
                  key={a.value}
                  onClick={() => setActivityLevel(a.value as typeof activityLevel)}
                  className={`w-full flex items-center gap-4 p-3.5 rounded-xl border-2 text-left transition-all ${
                    activityLevel === a.value
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card hover:border-primary/40"
                  }`}
                >
                  <span className="text-2xl">{a.icon}</span>
                  <div className="flex-1">
                    <p className="font-medium text-foreground text-sm">{a.label}</p>
                    <p className="text-xs text-muted-foreground">{a.desc}</p>
                  </div>
                  {activityLevel === a.value && <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />}
                </button>
              ))}
            </div>

            {tdee > 0 && (
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-3">Your Calorie Plan</p>
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <p className="text-xl font-bold text-foreground">{tdee}</p>
                    <p className="text-xs text-muted-foreground">TDEE (kcal)</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{calorieTarget}</p>
                    <p className="text-xs text-muted-foreground">Daily Target</p>
                  </div>
                </div>
              </div>
            )}

            <Button
              onClick={() => setStep(3)}
              disabled={!canProceedStep3}
              className="w-full h-12 text-base gap-2"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step 3: Ready */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center py-4">
              <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-2xl font-bold text-foreground">You're all set!</h1>
              <p className="text-muted-foreground mt-2">Here's your personalised nutrition plan:</p>
            </div>

            {calorieTarget > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: Flame, label: "Daily Calories", value: `${calorieTarget} kcal`, color: "text-orange-500", bg: "bg-orange-50" },
                  { icon: Target, label: "Your Goal", value: GOALS.find(g => g.value === goal)?.label ?? "", color: "text-primary", bg: "bg-primary/5" },
                  { icon: Activity, label: "Activity Level", value: ACTIVITY_LEVELS.find(a => a.value === activityLevel)?.label ?? "", color: "text-blue-500", bg: "bg-blue-50" },
                  { icon: Zap, label: "Protein Target", value: `${Math.round(calorieTarget * 0.25 / 4)}g`, color: "text-purple-500", bg: "bg-purple-50" },
                ].map(item => (
                  <div key={item.label} className={`${item.bg} rounded-2xl p-4`}>
                    <item.icon className={`w-5 h-5 ${item.color} mb-2`} />
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className={`font-bold text-sm ${item.color}`}>{item.value}</p>
                  </div>
                ))}
              </div>
            )}

            <Card className="border-dashed border-primary/30 bg-primary/3">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Scan className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <p className="font-medium text-sm text-foreground">Start by scanning your first food</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Use the barcode scanner or AI food photo scanner to log your first meal.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleFinish}
              disabled={saveProfile.isPending}
              className="w-full h-12 text-base gap-2"
            >
              {saveProfile.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>Go to Dashboard <ArrowRight className="w-4 h-4" /></>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
