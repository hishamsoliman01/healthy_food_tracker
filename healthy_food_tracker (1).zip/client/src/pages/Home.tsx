import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import {
  Activity,
  Apple,
  BarChart3,
  Bluetooth,
  Camera,
  ChevronRight,
  Droplets,
  ExternalLink,
  Flame,
  Heart,
  Leaf,
  Linkedin,
  Scale,
  ScanSearch,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Trophy,
  Twitter,
  Utensils,
  Zap,
  Instagram,
  BadgeCheck,
  Users,
} from "lucide-react";
import { useLocation } from "wouter";

const features = [
  {
    icon: Camera,
    title: "Barcode Scanner",
    description: "Instantly scan any product barcode. If not found locally, we fetch it from the Open Food Facts database of 3 million+ products.",
    badge: "Live Camera",
  },
  {
    icon: ScanSearch,
    title: "AI Food Scanner",
    description: "Photograph any dish or ingredient — our AI identifies it, estimates macros, and cross-references a verified nutrition database.",
    badge: "AI-Powered",
  },
  {
    icon: Sparkles,
    title: "AI Label Reader",
    description: "Point your camera at any nutrition label and the AI extracts all values automatically — no typing required.",
    badge: "AI-Powered",
  },
  {
    icon: BarChart3,
    title: "Smart Dashboard",
    description: "Calorie progress ring, macro bars, and 4 meal cards (Breakfast, Lunch, Dinner, Snacks) updated in real time.",
    badge: null,
  },
  {
    icon: Utensils,
    title: "Recipe Builder",
    description: "Combine ingredients into saved recipes. Log an entire meal in one tap and see its combined nutritional profile.",
    badge: "New",
  },
  {
    icon: Flame,
    title: "Streaks & Badges",
    description: "Stay motivated with daily logging streaks, milestone badges, and a gamified achievement system.",
    badge: null,
  },
  {
    icon: Droplets,
    title: "Water Tracker",
    description: "Log your daily water intake with quick-add buttons and a visual progress ring toward your hydration goal.",
    badge: null,
  },
  {
    icon: Scale,
    title: "Weight Log",
    description: "Track your weight over time with a trend chart. See your progress toward your goal alongside your nutrition data.",
    badge: null,
  },
  {
    icon: Bluetooth,
    title: "Wearable Connect",
    description: "Pair a Bluetooth heart rate monitor or fitness tracker to see live heart rate and estimated calorie burn on your Dashboard.",
    badge: "New",
  },
  {
    icon: Activity,
    title: "Weekly Reports",
    description: "A full 7-day summary with calorie trends, macro balance, Nutri-Score distribution, and your top foods.",
    badge: null,
  },
  {
    icon: Heart,
    title: "Favourites",
    description: "Star your most-eaten foods for one-tap logging directly from the Dashboard — no scanning needed.",
    badge: null,
  },
  {
    icon: ShieldCheck,
    title: "Secure & Private",
    description: "Your health data is yours. Secured with OAuth 2.0 and never sold or shared with third parties.",
    badge: null,
  },
];

const stats = [
  { value: "12,400+", label: "Active Users", icon: Users },
  { value: "1.2M+", label: "Meals Logged", icon: Apple },
  { value: "4.8★", label: "Average Rating", icon: Star },
  { value: "3M+", label: "Food Products", icon: Zap },
];

const howItWorks = [
  {
    step: "1",
    title: "Scan or Photograph",
    description: "Use the barcode scanner, AI food photo scanner, or AI label reader to identify any food instantly.",
  },
  {
    step: "2",
    title: "See Your Nutrition",
    description: "Get a full nutritional breakdown with Nutri-Score rating, macros, ingredients, and health tips.",
  },
  {
    step: "3",
    title: "Track Your Progress",
    description: "Log meals, monitor daily calorie goals, build streaks, and review weekly reports to stay on track.",
  },
];

const testimonials = [
  {
    name: "Sarah M.",
    role: "Fitness Enthusiast",
    text: "The AI food scanner is incredible — it identified my home-cooked pasta dish and gave me accurate macros instantly.",
    rating: 5,
    date: "March 2026",
    platform: "via App Store",
  },
  {
    name: "Ahmed K.",
    role: "Nutritionist",
    text: "I recommend NutriTrack to all my clients. The Nutri-Score system makes healthy choices obvious and easy.",
    rating: 5,
    date: "February 2026",
    platform: "via Google Play",
  },
  {
    name: "Priya R.",
    role: "Busy Parent",
    text: "Finally an app that works for real life. The barcode scanner finds everything, and the weekly report keeps me accountable.",
    rating: 5,
    date: "March 2026",
    platform: "via App Store",
  },
];

const team = [
  {
    initials: "JC",
    name: "James Chen",
    title: "Founder & CEO",
    bio: "Former Google Health PM. Obsessed with making nutrition science accessible to everyone.",
  },
  {
    initials: "LN",
    name: "Layla Nasser",
    title: "Head of AI/ML",
    bio: "PhD in Computer Vision from MIT. Built the food recognition models powering our AI scanners.",
  },
  {
    initials: "MO",
    name: "Marco Oliveira",
    title: "Head of Product",
    bio: "10 years designing health apps. Believes great UX is the best health intervention.",
  },
];

const footerCompany = ["About Us", "Team", "Careers"];
const footerLegal = ["Privacy Policy", "Terms of Service", "Cookie Policy"];

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      window.location.href = getLoginUrl(window.location.pathname);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ── Navigation ────────────────────────────────────────────────── */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg text-foreground">NutriTrack</span>
          </div>

          {/* Centre links — hidden on mobile */}
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
            <button onClick={() => navigate("/")} className="hover:text-foreground transition-colors">Home</button>
            <button onClick={() => {
              document.getElementById("features-section")?.scrollIntoView({ behavior: "smooth" });
            }} className="hover:text-foreground transition-colors">Features</button>
            <button onClick={() => navigate("/teams")} className="hover:text-foreground transition-colors">For Teams</button>
            <button onClick={() => navigate("/pricing")} className="hover:text-foreground transition-colors">Pricing</button>
            <button onClick={() => navigate("/blog")} className="hover:text-foreground transition-colors text-muted-foreground/60 cursor-not-allowed" title="Coming soon">Blog</button>
          </div>

          {/* CTA buttons */}
          <div className="flex items-center gap-2">
            {!loading && (
              isAuthenticated ? (
                <Button onClick={() => navigate("/dashboard")} size="sm">
                  Go to Dashboard <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              ) : (
                <>
                  <Button variant="outline" size="sm" onClick={handleGetStarted} className="hidden sm:flex bg-transparent">
                    Sign In
                  </Button>
                  <Button size="sm" onClick={handleGetStarted} className="shadow-sm shadow-primary/30">
                    Start Free →
                  </Button>
                </>
              )
            )}
          </div>
        </div>
      </nav>

      {/* ── Hero ──────────────────────────────────────────────────────── */}
      <section className="pt-32 pb-24 px-4 relative overflow-hidden">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-20 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-primary/8 rounded-full blur-3xl" />
        </div>
        <div className="container max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-6 border border-primary/20">
            <Sparkles className="w-4 h-4" />
            AI-Powered Nutrition Tracking
          </div>
          <h1 className="text-5xl sm:text-7xl font-extrabold text-foreground leading-[1.1] mb-6 tracking-tight">
            Know What You Eat,{" "}
            <span className="text-primary">Every Day</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Scan barcodes, photograph meals, read nutrition labels with AI — then track calories, macros, and health scores across every meal. Built for people who take their health seriously.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={handleGetStarted} className="text-base px-8 h-12 shadow-lg shadow-primary/25">
              Start Tracking Free
              <ChevronRight className="w-5 h-5 ml-1" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => isAuthenticated ? navigate("/scan/photo") : handleGetStarted()} className="text-base px-8 h-12">
              <ScanSearch className="w-5 h-5 mr-2" />
              Try AI Food Scanner
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-16 max-w-2xl mx-auto">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-2">
                  <s.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="text-2xl font-extrabold text-primary">{s.value}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground/60 mt-3">
            Local verified database + Open Food Facts global database
          </p>
        </div>
      </section>

      {/* ── Nutri-Score Visual ────────────────────────────────────────── */}
      <section className="py-16 bg-muted/40 border-y border-border/40">
        <div className="container max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-foreground mb-2">The Nutri-Score System</h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto text-sm">
            Based on the official European nutritional grading system — each product receives a score from A (healthiest) to E (least healthy), so you always know what you're putting in your body.
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            {(["A", "B", "C", "D", "E"] as const).map((score, i) => {
              const labels = ["Excellent", "Good", "Average", "Poor", "Bad"];
              const sizes = ["w-20 h-20 text-3xl", "w-16 h-16 text-2xl", "w-14 h-14 text-xl", "w-16 h-16 text-2xl", "w-20 h-20 text-3xl"];
              return (
                <div key={score} className="flex flex-col items-center gap-2">
                  <div className={`nutri-${score.toLowerCase()} rounded-2xl flex items-center justify-center font-extrabold shadow-md ${sizes[i]} transition-transform hover:scale-110`}>
                    {score}
                  </div>
                  <span className="text-xs text-muted-foreground">{labels[i]}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── How It Works ──────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-foreground mb-3">How It Works</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Three simple steps to take full control of your nutrition.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {howItWorks.map((step) => (
              <div key={step.step} className="relative text-center">
                <div className="w-14 h-14 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center text-2xl font-extrabold mx-auto mb-5 shadow-lg shadow-primary/25">
                  {step.step}
                </div>
                <h3 className="font-semibold text-foreground text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features Grid ─────────────────────────────────────────────── */}
      <section id="features-section" className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-foreground mb-3">Everything You Need</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              A complete nutrition tracking toolkit — from AI-powered scanning to social challenges and wearable integration.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {features.map((f) => (
              <div
                key={f.title}
                className="bg-card rounded-2xl p-5 border border-border/60 hover:shadow-md hover:border-primary/30 transition-all duration-200 relative group"
              >
                {f.badge && (
                  <span className={`absolute top-4 right-4 text-xs font-semibold px-2 py-0.5 rounded-full ${
                    f.badge === "AI-Powered" ? "bg-purple-100 text-purple-700" :
                    f.badge === "New" ? "bg-green-100 text-green-700" :
                    "bg-blue-100 text-blue-700"
                  }`}>
                    {f.badge}
                  </span>
                )}
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-1.5 text-sm">{f.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ──────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-foreground mb-3">Loved by Health-Conscious Users</h2>
            <p className="text-muted-foreground">Real feedback from people who track their nutrition daily.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="bg-card rounded-2xl p-6 border border-border/60 hover:shadow-md transition-shadow flex flex-col">
                {/* Star rating */}
                <div className="flex gap-0.5 mb-3">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-5 italic flex-1">"{t.text}"</p>
                <div className="flex items-end justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-muted-foreground/70">{t.date}</p>
                    <span className="inline-block mt-0.5 text-[10px] font-medium bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{t.platform}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Team / Founder Section ────────────────────────────────────── */}
      <section className="py-20 bg-muted/30">
        <div className="container max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-foreground mb-3">Built by people obsessed with nutrition</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              We combine deep expertise in AI, product design, and health science to build tools that actually change behaviour.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {team.map((member) => (
              <div key={member.name} className="bg-card rounded-2xl p-6 border border-border/60 hover:shadow-md transition-shadow text-center">
                <div className="w-16 h-16 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-4 text-primary font-bold text-xl">
                  {member.initials}
                </div>
                <p className="font-semibold text-foreground text-base">{member.name}</p>
                <p className="text-xs font-medium text-primary mt-0.5 mb-3">{member.title}</p>
                <p className="text-xs text-muted-foreground leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ─────────────────────────────────────────────────── */}
      <section className="py-24 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 -z-0">
          <div className="absolute top-0 left-1/3 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-white/5 rounded-full blur-3xl" />
        </div>
        <div className="container text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-white/15 text-white px-4 py-1.5 rounded-full text-sm font-medium mb-6">
            <Trophy className="w-4 h-4" />
            Join 12,400+ health-conscious users
          </div>
          <h2 className="text-4xl font-bold text-primary-foreground mb-4">
            Start Your Health Journey Today
          </h2>
          <p className="text-primary-foreground/80 mb-6 max-w-md mx-auto text-lg">
            Free forever. No credit card. No ads. Just powerful nutrition tracking built for real people.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              size="lg"
              onClick={handleGetStarted}
              className="text-base px-10 h-12 bg-white text-primary hover:bg-white/90 shadow-xl"
            >
              Get Started — It's Free
              <ChevronRight className="w-5 h-5 ml-1" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/pricing")}
              className="text-base px-8 h-12 border-white/40 text-white hover:bg-white/10 bg-transparent"
            >
              View Pricing
            </Button>
          </div>
        </div>
      </section>

      {/* ── Footer ────────────────────────────────────────────────────── */}
      <footer className="bg-background border-t border-border/50 pt-14 pb-8">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            {/* Brand */}
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                  <Leaf className="w-4 h-4 text-primary-foreground" />
                </div>
                <span className="text-sm font-bold text-foreground">NutriTrack</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed max-w-xs">
                AI-powered nutrition tracking for people who take their health seriously.
              </p>
              {/* Social icons */}
              <div className="flex items-center gap-3 mt-4">
                <a href="#" aria-label="Twitter/X" className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center hover:bg-primary/10 transition-colors">
                  <Twitter className="w-3.5 h-3.5 text-muted-foreground" />
                </a>
                <a href="#" aria-label="LinkedIn" className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center hover:bg-primary/10 transition-colors">
                  <Linkedin className="w-3.5 h-3.5 text-muted-foreground" />
                </a>
                <a href="#" aria-label="Instagram" className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center hover:bg-primary/10 transition-colors">
                  <Instagram className="w-3.5 h-3.5 text-muted-foreground" />
                </a>
              </div>
            </div>

            {/* Company */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60 mb-3">Company</p>
              <ul className="space-y-2">
                {footerCompany.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">{link}</a>
                  </li>
                ))}
                <li>
                  <button onClick={() => navigate("/teams")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">For Teams</button>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60 mb-3">Legal</p>
              <ul className="space-y-2">
                {footerLegal.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">{link}</a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Product */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60 mb-3">Product</p>
              <ul className="space-y-2">
                <li><button onClick={() => navigate("/pricing")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Pricing</button></li>
                <li><button onClick={() => navigate("/teams")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Enterprise</button></li>
                <li>
                  <a href="https://world.openfoodfacts.org/data" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                    Open Food Facts <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium bg-muted text-muted-foreground px-3 py-1.5 rounded-full border border-border/60">
              <BadgeCheck className="w-3.5 h-3.5 text-primary" /> GDPR Compliant
            </span>
            <span className="inline-flex items-center gap-1.5 text-xs font-medium bg-muted text-muted-foreground px-3 py-1.5 rounded-full border border-border/60">
              <ShieldCheck className="w-3.5 h-3.5 text-primary" /> SOC 2 Ready
            </span>
            <span className="inline-flex items-center gap-1.5 text-xs font-medium bg-muted text-muted-foreground px-3 py-1.5 rounded-full border border-border/60">
              <Leaf className="w-3.5 h-3.5 text-primary" /> Open Food Facts Partner
            </span>
          </div>

          {/* Bottom bar */}
          <div className="border-t border-border/40 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">© 2026 NutriTrack Technologies Ltd. All rights reserved.</p>
            <p className="text-xs text-muted-foreground/60">Nutritional data for informational purposes only. Consult a healthcare professional for dietary advice.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
