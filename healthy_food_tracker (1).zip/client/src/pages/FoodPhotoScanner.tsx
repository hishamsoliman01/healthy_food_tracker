import { useRef, useState, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { NutriScoreBadge } from "@/components/NutriScoreBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";
import {
  Camera,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Info,
  Leaf,
  Zap,
  Dumbbell,
  Wheat,
  Droplets,
  RotateCcw,
  Database,
  Brain,
  ChevronDown,
  ChevronUp,
  UtensilsCrossed,
  FlameIcon,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type RecognizedItem = {
  name: string;
  commonName: string;
  description: string | null;
  category: string | null;
  cookingMethod: string | null;
  portionSize: "small" | "medium" | "large";
  confidence: number;
  nutriScore: "A" | "B" | "C" | "D" | "E" | null;
  novaGroup: 1 | 2 | 3 | 4 | null;
  allergens: string[];
  vitamins: string[];
  healthTips: string | null;
  dataSource: "reference_db" | "ai_estimate";
  calories: number | null;
  fat: number | null;
  saturatedFat: number | null;
  carbohydrates: number | null;
  sugars: number | null;
  fiber: number | null;
  proteins: number | null;
  salt: number | null;
  portionNutrition: {
    calories: number | null;
    fat: number | null;
    proteins: number | null;
    carbohydrates: number | null;
  } | null;
};

type ScanResult = {
  items: RecognizedItem[];
  mealDescription: string | null;
  overallNutriScore: "A" | "B" | "C" | "D" | "E" | null;
};

type AppState = "idle" | "capturing" | "uploading" | "analysing" | "results" | "logging";

const MEAL_OPTIONS = [
  { value: "breakfast", label: "Breakfast", emoji: "🌅" },
  { value: "lunch", label: "Lunch", emoji: "☀️" },
  { value: "dinner", label: "Dinner", emoji: "🌙" },
  { value: "snacks", label: "Snacks", emoji: "🍎" },
] as const;

type MealType = (typeof MEAL_OPTIONS)[number]["value"];

const NOVA_LABELS: Record<number, { label: string; color: string }> = {
  1: { label: "Unprocessed", color: "text-green-700 bg-green-50" },
  2: { label: "Minimally Processed", color: "text-lime-700 bg-lime-50" },
  3: { label: "Processed", color: "text-orange-700 bg-orange-50" },
  4: { label: "Ultra-Processed", color: "text-red-700 bg-red-50" },
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function ConfidenceMeter({ value }: { value: number }) {
  const color = value >= 80 ? "bg-green-500" : value >= 60 ? "bg-yellow-500" : "bg-orange-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${value}%` }} />
      </div>
      <span className="text-xs font-medium text-muted-foreground w-8 text-right">{value}%</span>
    </div>
  );
}

function MacroBar({ label, value, max, color, unit = "g" }: { label: string; value: number | null; max: number; color: string; unit?: string }) {
  const pct = value !== null ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium">{value !== null ? `${value}${unit}` : "—"}</span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function FoodItemCard({
  item,
  index,
  selectedMeal,
  portionGrams,
  onLog,
  isLogging,
}: {
  item: RecognizedItem;
  index: number;
  selectedMeal: MealType;
  portionGrams: number;
  onLog: (item: RecognizedItem) => void;
  isLogging: boolean;
}) {
  const [expanded, setExpanded] = useState(index === 0);
  const nova = item.novaGroup ? NOVA_LABELS[item.novaGroup] : null;
  const portionFactor = portionGrams / 100;

  const scaledCalories = item.calories !== null ? Math.round(item.calories * portionFactor) : null;
  const scaledProteins = item.proteins !== null ? Math.round(item.proteins * portionFactor * 10) / 10 : null;
  const scaledCarbs = item.carbohydrates !== null ? Math.round(item.carbohydrates * portionFactor * 10) / 10 : null;
  const scaledFat = item.fat !== null ? Math.round(item.fat * portionFactor * 10) / 10 : null;

  return (
    <Card className="overflow-hidden border border-border/60 shadow-sm hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="p-4 pb-0">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-base leading-tight">{item.name}</h3>
              {item.cookingMethod && (
                <Badge variant="outline" className="text-xs capitalize">{item.cookingMethod}</Badge>
              )}
            </div>
            {item.category && (
              <p className="text-xs text-muted-foreground mt-0.5">{item.category}</p>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {item.nutriScore && <NutriScoreBadge score={item.nutriScore} size="sm" />}
          </div>
        </div>

        {/* Confidence + data source */}
        <div className="mt-2 space-y-1">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>AI Confidence</span>
            <div className="flex items-center gap-1">
              {item.dataSource === "reference_db" ? (
                <><Database className="w-3 h-3 text-primary" /><span className="text-primary font-medium">Verified Data</span></>
              ) : (
                <><Brain className="w-3 h-3 text-amber-500" /><span className="text-amber-600 font-medium">AI Estimate</span></>
              )}
            </div>
          </div>
          <ConfidenceMeter value={item.confidence} />
        </div>

        {/* Calorie highlight for current portion */}
        {scaledCalories !== null && (
          <div className="mt-3 flex items-center gap-3 bg-primary/5 rounded-lg px-3 py-2">
            <FlameIcon className="w-4 h-4 text-primary shrink-0" />
            <div className="flex-1">
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold text-primary">{scaledCalories}</span>
                <span className="text-xs text-muted-foreground">kcal for {portionGrams}g</span>
              </div>
              <div className="flex gap-3 text-xs text-muted-foreground mt-0.5">
                {scaledProteins !== null && <span>P: {scaledProteins}g</span>}
                {scaledCarbs !== null && <span>C: {scaledCarbs}g</span>}
                {scaledFat !== null && <span>F: {scaledFat}g</span>}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Expandable details */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-4 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
      >
        <span>{expanded ? "Hide details" : "Show nutritional details"}</span>
        {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
      </button>

      {expanded && (
        <CardContent className="pt-0 pb-4 space-y-4">
          {/* Description */}
          {item.description && (
            <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
          )}

          {/* Macros per 100g */}
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">Per 100g</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
              <MacroBar label="Calories" value={item.calories} max={900} color="bg-orange-400" unit=" kcal" />
              <MacroBar label="Protein" value={item.proteins} max={40} color="bg-blue-400" />
              <MacroBar label="Carbs" value={item.carbohydrates} max={100} color="bg-yellow-400" />
              <MacroBar label="Fat" value={item.fat} max={50} color="bg-red-400" />
              <MacroBar label="Fibre" value={item.fiber} max={15} color="bg-green-400" />
              <MacroBar label="Sugars" value={item.sugars} max={50} color="bg-pink-400" />
            </div>
          </div>

          {/* NOVA group */}
          {nova && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Processing:</span>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${nova.color}`}>
                NOVA {item.novaGroup} — {nova.label}
              </span>
            </div>
          )}

          {/* Vitamins */}
          {item.vitamins.length > 0 && (
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wide">Key Nutrients</p>
              <div className="flex flex-wrap gap-1.5">
                {item.vitamins.map((v) => (
                  <Badge key={v} variant="secondary" className="text-xs bg-green-50 text-green-700 border-green-200">
                    <Leaf className="w-2.5 h-2.5 mr-1" />{v}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Allergens */}
          {item.allergens.length > 0 && (
            <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-2.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium text-amber-800">Contains allergens</p>
                <p className="text-xs text-amber-700 mt-0.5">{item.allergens.join(", ")}</p>
              </div>
            </div>
          )}

          {/* Health tips */}
          {item.healthTips && (
            <div className="flex items-start gap-2 bg-primary/5 border border-primary/15 rounded-lg p-2.5">
              <Info className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">{item.healthTips}</p>
            </div>
          )}
        </CardContent>
      )}

      {/* Log button */}
      <div className="px-4 pb-4">
        <Button
          className="w-full"
          size="sm"
          onClick={() => onLog(item)}
          disabled={isLogging}
        >
          {isLogging ? (
            <><Sparkles className="w-3.5 h-3.5 mr-1.5 animate-spin" />Logging…</>
          ) : (
            <><CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />Log to {MEAL_OPTIONS.find((m) => m.value === selectedMeal)?.label}</>
          )}
        </Button>
      </div>
    </Card>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function FoodPhotoScanner() {
  const [, navigate] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [state, setState] = useState<AppState>("idle");
  const [capturedImage, setCapturedImage] = useState<string | null>(null); // data URL for preview
  const [results, setResults] = useState<ScanResult | null>(null);
  const [selectedMeal, setSelectedMeal] = useState<MealType>("lunch");
  const [portionGrams, setPortionGrams] = useState(150);
  const [loggingItem, setLoggingItem] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const recognizeMutation = trpc.products.recognizeFood.useMutation();
  const findOrCreateProduct = trpc.products.findOrCreate.useMutation();
  const addConsumption = trpc.consumption.add.useMutation();
  const utils = trpc.useUtils();

  // Start camera
  const startCamera = useCallback(async () => {
    setCameraError(null);

    // Check if mediaDevices API is available (requires HTTPS or localhost)
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError(
        "Camera not available. This feature requires a secure (HTTPS) connection. Please use the Upload option instead."
      );
      return;
    }

    // Try with rear camera first, fall back to any camera
    const constraints: MediaStreamConstraints[] = [
      { video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } } },
      { video: { facingMode: "user" } },
      { video: true },
    ];

    let stream: MediaStream | null = null;
    let lastError: unknown = null;

    for (const constraint of constraints) {
      try {
        stream = await navigator.mediaDevices.getUserMedia(constraint);
        break;
      } catch (err) {
        lastError = err;
      }
    }

    if (!stream) {
      const err = lastError as { name?: string };
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        setCameraError(
          "Camera permission denied. Please allow camera access in your browser settings, then try again."
        );
      } else if (err?.name === "NotFoundError" || err?.name === "DevicesNotFoundError") {
        setCameraError(
          "No camera found on this device. Please use the Upload option to select a photo from your gallery."
        );
      } else if (err?.name === "NotReadableError" || err?.name === "TrackStartError") {
        setCameraError(
          "Camera is in use by another app. Please close other apps using the camera and try again."
        );
      } else {
        setCameraError(
          "Could not access camera. Please use the Upload option to select a photo from your gallery."
        );
      }
      return;
    }

    streamRef.current = stream;
    // Set state FIRST so the <video> element mounts in the DOM,
    // then assign srcObject in the useEffect below (Android Chrome fix)
    setState("capturing");
  }, []);

  // Stop camera
  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  // Android Chrome fix: assign srcObject AFTER the video element is in the DOM
  // (setting srcObject before the element mounts causes a black screen on Android)
  useEffect(() => {
    if (state === "capturing" && videoRef.current && streamRef.current) {
      const video = videoRef.current;
      video.srcObject = streamRef.current;
      video.setAttribute("autoplay", "");
      video.setAttribute("playsinline", "");
      video.setAttribute("muted", "");
      // Force play — required on some Android browsers
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // Retry once on user-gesture-required error
          video.play().catch(() => {});
        });
      }
    }
  }, [state]);

  // Capture photo from camera
  const capturePhoto = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    setCapturedImage(dataUrl);
    stopCamera();
    analyseImage(dataUrl);
  }, [stopCamera]); // eslint-disable-line react-hooks/exhaustive-deps

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 16 * 1024 * 1024) {
      toast.error("File too large. Maximum size is 16MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setCapturedImage(dataUrl);
      analyseImage(dataUrl);
    };
    reader.readAsDataURL(file);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Upload image to server and run AI analysis
  const analyseImage = useCallback(async (dataUrl: string) => {
    setState("uploading");
    try {
      // Convert data URL to blob and upload
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      const formData = new FormData();
      formData.append("image", blob, "food-photo.jpg");

      const uploadRes = await fetch("/api/upload-label", { method: "POST", body: formData });
      if (!uploadRes.ok) throw new Error("Upload failed");
      const { url: imageUrl } = await uploadRes.json() as { url: string };

      setState("analysing");
      const result = await recognizeMutation.mutateAsync({ imageUrl, portionGrams });
      setResults(result as ScanResult);
      setState("results");
    } catch (err) {
      console.error(err);
      toast.error("Analysis failed. Please try again with a clearer photo.");
      setState("idle");
      setCapturedImage(null);
    }
  }, [recognizeMutation, portionGrams]);

  // Log a recognised item to consumption
  const handleLog = useCallback(async (item: RecognizedItem) => {
    setLoggingItem(item.name);
    setState("logging");
    try {
      // Find existing product by name or create a new one (no duplicate errors)
      const product = await findOrCreateProduct.mutateAsync({
        name: item.name,
        category: item.category ?? undefined,
        nutriScore: item.nutriScore ?? undefined,
        novaGroup: item.novaGroup ?? undefined,
        calories: item.calories ?? undefined,
        fat: item.fat ?? undefined,
        saturatedFat: item.saturatedFat ?? undefined,
        carbohydrates: item.carbohydrates ?? undefined,
        sugars: item.sugars ?? undefined,
        fiber: item.fiber ?? undefined,
        proteins: item.proteins ?? undefined,
        salt: item.salt ?? undefined,
      });

      await addConsumption.mutateAsync({
        productId: product.id,
        quantity: 1,
        mealType: selectedMeal,
      });

      await utils.consumption.getToday.invalidate();
      await utils.dashboard.stats.invalidate();

      toast.success(`${item.name} logged to ${selectedMeal}!`);
      navigate("/dashboard");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to log food";
      toast.error(msg);
    } finally {
      setLoggingItem(null);
      setState("results");
    }
  }, [findOrCreateProduct, addConsumption, selectedMeal, utils, navigate]);

  const reset = useCallback(() => {
    setState("idle");
    setCapturedImage(null);
    setResults(null);
    setCameraError(null);
    stopCamera();
  }, [stopCamera]);

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6 pb-10">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            AI Food Scanner
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Photograph any food or dish — AI identifies it, cross-references a nutrition database, and gives you verified data.
          </p>
        </div>

        {/* Meal selector */}
        <div className="flex gap-2 flex-wrap">
          {MEAL_OPTIONS.map((m) => (
            <button
              key={m.value}
              onClick={() => setSelectedMeal(m.value)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                selectedMeal === m.value
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary/50"
              }`}
            >
              <span>{m.emoji}</span>{m.label}
            </button>
          ))}
        </div>

        {/* Portion size control */}
        {(state === "idle" || state === "capturing" || state === "results") && (
          <Card className="border-border/60">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <UtensilsCrossed className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Portion Size</span>
                </div>
                <span className="text-sm font-bold text-primary">{portionGrams}g</span>
              </div>
              <Slider
                value={[portionGrams]}
                onValueChange={([v]) => setPortionGrams(v)}
                min={10}
                max={500}
                step={10}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>10g</span><span>250g</span><span>500g</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Camera / capture area */}
        {state === "idle" && (
          <Card className="border-dashed border-2 border-border/60">
            <CardContent className="pt-8 pb-8">
              {cameraError && (
                <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3 mb-6 text-sm text-amber-800">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium mb-1">Camera unavailable</p>
                    <p>{cameraError}</p>
                    <button
                      className="mt-2 text-amber-900 underline font-medium text-xs"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      Upload a photo instead →
                    </button>
                  </div>
                </div>
              )}
              <div className="flex flex-col items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <Camera className="w-10 h-10 text-primary" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-lg">Scan your food</p>
                  <p className="text-muted-foreground text-sm mt-1">Take a photo or upload an image of any food, dish, or ingredient</p>
                </div>
                <div className="flex flex-col gap-2 w-full max-w-xs">
                  {/* Primary: upload from gallery — works on all devices without camera permission */}
                  <Button className="w-full" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="w-4 h-4 mr-2" />Upload Photo from Gallery
                  </Button>
                  {/* Secondary: live camera — requires HTTPS + camera permission */}
                  <Button variant="outline" className="w-full bg-background" onClick={startCamera}>
                    <Camera className="w-4 h-4 mr-2" />Use Live Camera
                  </Button>
                </div>
                {/* capture=environment opens rear camera directly on mobile */}
                <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
              </div>

              {/* Feature highlights */}
              <div className="mt-8 grid grid-cols-3 gap-3 text-center">
                {[
                  { icon: Database, label: "Verified Data", desc: "Cross-referenced with nutrition DB" },
                  { icon: Zap, label: "Instant Analysis", desc: "Results in seconds" },
                  { icon: Leaf, label: "Health Insights", desc: "Allergens, vitamins & tips" },
                ].map(({ icon: Icon, label, desc }) => (
                  <div key={label} className="p-3 rounded-xl bg-muted/40">
                    <Icon className="w-5 h-5 text-primary mx-auto mb-1.5" />
                    <p className="text-xs font-medium">{label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Live camera viewfinder */}
        {state === "capturing" && (
          <Card className="overflow-hidden">
            <div className="relative bg-black aspect-video">
              <video ref={videoRef} className="w-full h-full object-cover" playsInline autoPlay muted />
              {/* Overlay guide */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="border-2 border-white/70 rounded-2xl w-3/4 h-3/4 flex items-center justify-center">
                  <p className="text-white/80 text-sm font-medium bg-black/40 px-3 py-1 rounded-full">
                    Centre food in frame
                  </p>
                </div>
              </div>
            </div>
            <CardContent className="pt-4 pb-4 flex gap-3">
              <Button className="flex-1" size="lg" onClick={capturePhoto}>
                <Camera className="w-5 h-5 mr-2" />Capture Photo
              </Button>
              <Button variant="outline" className="bg-background" onClick={reset}>
                <RotateCcw className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Hidden canvas for capture */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Uploading / analysing state */}
        {(state === "uploading" || state === "analysing") && (
          <Card>
            <CardContent className="pt-8 pb-8">
              {capturedImage && (
                <div className="mb-6 rounded-xl overflow-hidden aspect-video bg-muted">
                  <img src={capturedImage} alt="Captured food" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex flex-col items-center gap-4">
                <div className="relative w-16 h-16">
                  <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                  <div className="relative w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    {state === "uploading"
                      ? <Upload className="w-7 h-7 text-primary animate-bounce" />
                      : <Brain className="w-7 h-7 text-primary animate-pulse" />
                    }
                  </div>
                </div>
                <div className="text-center">
                  <p className="font-semibold">
                    {state === "uploading" ? "Uploading photo…" : "AI is analysing your food…"}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {state === "uploading"
                      ? "Preparing image for analysis"
                      : "Identifying foods, checking nutrition database, calculating values"
                    }
                  </p>
                </div>
                <div className="w-full max-w-xs space-y-2">
                  {["Identifying food items", "Checking nutrition database", "Calculating values"].map((step, i) => (
                    <div key={step} className="flex items-center gap-2 text-sm">
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 ${
                        state === "analysing" && i === 0 ? "bg-primary" :
                        state === "analysing" && i === 1 ? "bg-primary/60 animate-pulse" :
                        state === "analysing" && i === 2 ? "bg-muted animate-pulse" :
                        "bg-muted"
                      }`}>
                        {state === "analysing" && i === 0 && <CheckCircle2 className="w-3 h-3 text-white" />}
                      </div>
                      <span className={state === "analysing" && i <= 1 ? "text-foreground" : "text-muted-foreground"}>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {(state === "results" || state === "logging") && results && (
          <div className="space-y-4">
            {/* Captured image */}
            {capturedImage && (
              <div className="rounded-xl overflow-hidden aspect-video bg-muted shadow-sm">
                <img src={capturedImage} alt="Analysed food" className="w-full h-full object-cover" />
              </div>
            )}

            {/* Meal summary */}
            {results.mealDescription && (
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-semibold">Meal Analysis</p>
                        {results.overallNutriScore && (
                          <NutriScoreBadge score={results.overallNutriScore} size="sm" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{results.mealDescription}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* No items found */}
            {results.items.length === 0 && (
              <Card>
                <CardContent className="pt-8 pb-8 text-center">
                  <UtensilsCrossed className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="font-medium">No food detected</p>
                  <p className="text-sm text-muted-foreground mt-1">Try a clearer photo with better lighting and the food centred in frame.</p>
                  <Button className="mt-4" onClick={reset}>Try Again</Button>
                </CardContent>
              </Card>
            )}

            {/* Food item cards */}
            {results.items.map((item, i) => (
              <FoodItemCard
                key={`${item.name}-${i}`}
                item={item}
                index={i}
                selectedMeal={selectedMeal}
                portionGrams={portionGrams}
                onLog={handleLog}
                isLogging={state === "logging" && loggingItem === item.name}
              />
            ))}

            {/* Scan again */}
            {results.items.length > 0 && (
              <Button variant="outline" className="w-full bg-background" onClick={reset}>
                <RotateCcw className="w-4 h-4 mr-2" />Scan Another Food
              </Button>
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
