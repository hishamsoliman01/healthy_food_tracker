import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  BadgeCheck,
  Building2,
  ChevronRight,
  Heart,
  Leaf,
  Stethoscope,
  TrendingDown,
  Users,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

const useCases = [
  {
    icon: Building2,
    title: "Corporate Wellness Programs",
    description:
      "Equip your HR team with a powerful nutrition platform. Track team-wide health metrics, run wellness challenges, and reward healthy habits — all from one dashboard.",
    highlight: "Reduce absenteeism by up to 28%",
  },
  {
    icon: Heart,
    title: "Health Insurance Partners",
    description:
      "Offer NutriTrack as a value-add benefit to your policyholders. Preventative nutrition tracking reduces chronic disease risk and lowers long-term claims.",
    highlight: "Lower claims through prevention",
  },
  {
    icon: Stethoscope,
    title: "Dietitian & Clinic Networks",
    description:
      "Give your practitioners a shared platform to monitor patient nutrition, assign meal plans, and review weekly reports — without the manual data entry.",
    highlight: "Save 3+ hours per patient per week",
  },
];

const trustStats = [
  { value: "12,400+", label: "Active users" },
  { value: "1.2M+", label: "Meals logged" },
  { value: "3M+", label: "Food products" },
  { value: "4.8★", label: "Average rating" },
];

export default function Teams() {
  const [, navigate] = useLocation();
  const { isAuthenticated, loading } = useAuth();
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    teamSize: "",
    email: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.company || !formData.teamSize || !formData.email) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setSubmitting(true);
    // Simulate form submission (no backend required per spec)
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      toast.success("Demo request received! We'll be in touch within 1 business day.");
    }, 1200);
  };

  const handleCTA = () => {
    if (isAuthenticated) navigate("/dashboard");
    else window.location.href = getLoginUrl("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <button onClick={() => navigate("/")} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg text-foreground">NutriTrack</span>
          </button>
          <div className="flex items-center gap-2">
            {!loading && (
              isAuthenticated ? (
                <Button onClick={() => navigate("/dashboard")} size="sm">
                  Dashboard <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              ) : (
                <>
                  <Button variant="outline" size="sm" onClick={handleCTA} className="hidden sm:flex bg-transparent">Sign In</Button>
                  <Button size="sm" onClick={handleCTA}>Start Free →</Button>
                </>
              )
            )}
          </div>
        </div>
      </nav>

      <div className="pt-24">
        {/* ── Hero ────────────────────────────────────────────────── */}
        <section className="py-20 px-4 relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-10 left-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-primary/8 rounded-full blur-3xl" />
          </div>
          <div className="container max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-6 border border-primary/20">
              <Users className="w-4 h-4" />
              NutriTrack for Teams
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold text-foreground leading-[1.1] mb-5 tracking-tight">
              Bring NutriTrack{" "}
              <span className="text-primary">to your team</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Help your employees eat better, reduce sick days, and lower your health insurance costs. Nutrition is the highest-ROI workplace wellness investment.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => {
                document.getElementById("demo-form")?.scrollIntoView({ behavior: "smooth" });
              }} className="text-base px-8 h-12 shadow-lg shadow-primary/25">
                Request a Demo
                <ChevronRight className="w-5 h-5 ml-1" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate("/pricing")} className="text-base px-8 h-12">
                View Pricing
              </Button>
            </div>

            {/* Trust stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-14 max-w-2xl mx-auto">
              {trustStats.map((s) => (
                <div key={s.label} className="text-center">
                  <div className="text-2xl font-extrabold text-primary">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Use Cases ───────────────────────────────────────────── */}
        <section className="py-20 bg-muted/30 px-4">
          <div className="container max-w-5xl mx-auto">
            <div className="text-center mb-14">
              <h2 className="text-3xl font-bold text-foreground mb-3">Built for every health-focused organisation</h2>
              <p className="text-muted-foreground max-w-lg mx-auto">
                Whether you're an HR director, an insurer, or a clinical network — NutriTrack scales to your needs.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {useCases.map((uc) => (
                <div key={uc.title} className="bg-card rounded-2xl p-6 border border-border/60 hover:shadow-md hover:border-primary/30 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5">
                    <uc.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground text-base mb-2">{uc.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{uc.description}</p>
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary bg-primary/10 px-3 py-1 rounded-full">
                    <TrendingDown className="w-3 h-3" /> {uc.highlight}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Why NutriTrack for Teams ─────────────────────────── */}
        <section className="py-20 px-4">
          <div className="container max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground mb-3">Why teams choose NutriTrack</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {[
                { icon: Zap, title: "Fast deployment", desc: "Onboard your entire team in under 10 minutes. No IT setup required." },
                { icon: BadgeCheck, title: "GDPR compliant", desc: "All data is encrypted, stored in the EU, and never shared with third parties." },
                { icon: Users, title: "Team dashboards", desc: "Aggregate anonymised health metrics to measure programme effectiveness." },
                { icon: Heart, title: "Proven engagement", desc: "Gamified streaks and challenges keep participation rates above 70% after 90 days." },
              ].map((item) => (
                <div key={item.title} className="flex gap-4 p-5 bg-card rounded-2xl border border-border/60">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm mb-1">{item.title}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Inquiry Form ─────────────────────────────────────── */}
        <section id="demo-form" className="py-20 bg-muted/30 px-4">
          <div className="container max-w-2xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-foreground mb-3">Request a Demo</h2>
              <p className="text-muted-foreground">
                Tell us about your team and we'll tailor a demo to your use case.
              </p>
              <p className="text-sm text-primary font-medium mt-2">
                Custom pricing for teams of 10+. Volume discounts available.
              </p>
            </div>

            {submitted ? (
              <div className="bg-card rounded-2xl border border-primary/30 p-10 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <BadgeCheck className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">Request received!</h3>
                <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                  Thanks, {formData.name}. Our team will reach out to <strong>{formData.email}</strong> within 1 business day to schedule your personalised demo.
                </p>
                <Button onClick={() => navigate("/")} className="mt-6">Back to Home</Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="bg-card rounded-2xl border border-border/60 p-8 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <Label htmlFor="name">Name <span className="text-destructive">*</span></Label>
                    <Input
                      id="name"
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="company">Company <span className="text-destructive">*</span></Label>
                    <Input
                      id="company"
                      placeholder="Company or organisation name"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <Label htmlFor="email">Work Email <span className="text-destructive">*</span></Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="teamSize">Team Size <span className="text-destructive">*</span></Label>
                    <Select
                      value={formData.teamSize}
                      onValueChange={(v) => setFormData({ ...formData, teamSize: v })}
                    >
                      <SelectTrigger id="teamSize">
                        <SelectValue placeholder="Select team size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10-50">10 – 50 employees</SelectItem>
                        <SelectItem value="50-200">50 – 200 employees</SelectItem>
                        <SelectItem value="200+">200+ employees</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Tell us about your wellness goals or any specific requirements…"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  />
                </div>
                <Button type="submit" size="lg" className="w-full" disabled={submitting}>
                  {submitting ? "Sending…" : "Request a Demo →"}
                </Button>
                <p className="text-center text-xs text-muted-foreground">
                  We respond within 1 business day. No spam, ever.
                </p>
              </form>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
