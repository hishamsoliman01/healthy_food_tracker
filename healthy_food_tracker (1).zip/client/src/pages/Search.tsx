import DashboardLayout from "@/components/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { Search as SearchIcon, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import type { Product } from "../../../drizzle/schema";
import { ProductCard } from "../components/ProductCard";

export default function Search() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  // Debounce
  useMemo(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const { data: results, isLoading } = trpc.products.search.useQuery(
    { query: debouncedQuery },
    { enabled: debouncedQuery.length >= 1 }
  );

  const { data: allProducts, isLoading: allLoading } = trpc.products.list.useQuery(
    undefined,
    { enabled: debouncedQuery.length === 0 }
  );

  const addMutation = trpc.consumption.add.useMutation({
    onSuccess: (_, vars) => toast.success("Added to today's log!"),
    onError: () => toast.error("Failed to add to log"),
  });

  const displayProducts = debouncedQuery.length >= 1 ? results : allProducts;
  const loading = debouncedQuery.length >= 1 ? isLoading : allLoading;

  const handleAddToLog = (product: Product) => {
    addMutation.mutate({ productId: product.id, quantity: 1 });
  };

  return (
    <DashboardLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Search Products</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Find food products by name, brand, or category.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for Nutella, Coca-Cola, Oat Flakes…"
            className="pl-9 h-11"
            autoFocus
          />
        </div>

        {/* Results */}
        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-xl" />
            ))}
          </div>
        ) : displayProducts && displayProducts.length > 0 ? (
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              {debouncedQuery ? `${displayProducts.length} result${displayProducts.length !== 1 ? "s" : ""} for "${debouncedQuery}"` : `${displayProducts.length} products in database`}
            </p>
            {displayProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToLog={handleAddToLog}
              />
            ))}
          </div>
        ) : debouncedQuery.length >= 1 ? (
          <div className="py-16 text-center">
            <SearchIcon className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">No products found for "{debouncedQuery}"</p>
          </div>
        ) : (
          <div className="py-16 text-center">
            <Sparkles className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">Start typing to search products</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
