import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, Plus, Trash2, Utensils, CheckCircle2, CalendarDays } from "lucide-react";

const MEAL_TYPES = ["breakfast", "lunch", "dinner", "snacks"] as const;
type MealType = typeof MEAL_TYPES[number];

const MEAL_LABELS: Record<MealType, string> = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  dinner: "Dinner",
  snacks: "Snacks",
};

const MEAL_COLORS: Record<MealType, string> = {
  breakfast: "bg-amber-50 border-amber-200 text-amber-800",
  lunch: "bg-green-50 border-green-200 text-green-800",
  dinner: "bg-blue-50 border-blue-200 text-blue-800",
  snacks: "bg-purple-50 border-purple-200 text-purple-800",
};

function getMonday(d: Date): Date {
  const date = new Date(d);
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  date.setDate(diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function formatDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function addDays(d: Date, n: number): Date {
  const result = new Date(d);
  result.setDate(result.getDate() + n);
  return result;
}

function formatDayLabel(d: Date): string {
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

export default function MealPlan() {
  const [weekOffset, setWeekOffset] = useState(0);
  const [addOpen, setAddOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedMeal, setSelectedMeal] = useState<MealType>("breakfast");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [amountGrams, setAmountGrams] = useState("100");

  const weekStart = useMemo(() => {
    const monday = getMonday(new Date());
    monday.setDate(monday.getDate() + weekOffset * 7);
    return formatDate(monday);
  }, [weekOffset]);

  const weekDays = useMemo(() => {
    const start = new Date(weekStart);
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  }, [weekStart]);

  const { data: plans = [], refetch } = trpc.mealPlan.listWeek.useQuery({ weekStart });
  const { data: searchResults = [] } = trpc.products.search.useQuery(
    { query: searchQuery, limit: 8 },
    { enabled: searchQuery.length > 1 }
  );

  const addMutation = trpc.mealPlan.add.useMutation({
    onSuccess: () => {
      toast.success("Meal added to plan!");
      setAddOpen(false);
      setSearchQuery("");
      setSelectedProductId(null);
      setAmountGrams("100");
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const removeMutation = trpc.mealPlan.remove.useMutation({
    onSuccess: () => { toast.success("Removed from plan"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const logMutation = trpc.mealPlan.logToday.useMutation({
    onSuccess: () => toast.success("Logged to today's diary!"),
    onError: (e) => toast.error(e.message),
  });

  // Group plans by date + mealType
  const plansByDateMeal = useMemo(() => {
    const map: Record<string, Record<MealType, typeof plans>> = {};
    for (const day of weekDays) {
      const d = formatDate(day);
      map[d] = { breakfast: [], lunch: [], dinner: [], snacks: [] };
    }
    for (const plan of plans) {
      if (map[plan.date]) {
        map[plan.date][plan.mealType as MealType].push(plan);
      }
    }
    return map;
  }, [plans, weekDays]);

  // Calculate daily calorie totals
  const dailyCalories = useMemo(() => {
    const totals: Record<string, number> = {};
    for (const plan of plans) {
      const cals = plan.product
        ? Math.round(((plan.product.calories ?? 0) * plan.amountGrams) / 100)
        : 0;
      totals[plan.date] = (totals[plan.date] ?? 0) + cals;
    }
    return totals;
  }, [plans]);

  const handleAdd = () => {
    if (!selectedProductId) { toast.error("Please select a product"); return; }
    if (!selectedDate) { toast.error("Please select a date"); return; }
    addMutation.mutate({
      date: selectedDate,
      mealType: selectedMeal,
      productId: selectedProductId,
      amountGrams: parseFloat(amountGrams) || 100,
    });
  };

  const openAddDialog = (date: string, meal: MealType) => {
    setSelectedDate(date);
    setSelectedMeal(meal);
    setAddOpen(true);
  };

  const today = formatDate(new Date());

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <CalendarDays className="w-6 h-6 text-primary" />
              Meal Planner
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Plan your meals for the week and track calorie budgets
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setWeekOffset(w => w - 1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setWeekOffset(0)} className="min-w-[80px]">
              {weekOffset === 0 ? "This Week" : weekOffset === 1 ? "Next Week" : weekOffset === -1 ? "Last Week" : `Week ${weekOffset > 0 ? "+" : ""}${weekOffset}`}
            </Button>
            <Button variant="outline" size="icon" onClick={() => setWeekOffset(w => w + 1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Weekly grid */}
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
          {weekDays.map((day) => {
            const dateStr = formatDate(day);
            const isToday = dateStr === today;
            const dayPlans = plansByDateMeal[dateStr] ?? { breakfast: [], lunch: [], dinner: [], snacks: [] };
            const dayCals = dailyCalories[dateStr] ?? 0;

            return (
              <div
                key={dateStr}
                className={`rounded-xl border ${isToday ? "border-primary ring-2 ring-primary/20" : "border-border"} bg-card overflow-hidden`}
              >
                {/* Day header */}
                <div className={`px-3 py-2 ${isToday ? "bg-primary text-primary-foreground" : "bg-muted/50"}`}>
                  <p className={`text-xs font-semibold ${isToday ? "text-primary-foreground" : "text-foreground"}`}>
                    {formatDayLabel(day)}
                  </p>
                  {dayCals > 0 && (
                    <p className={`text-xs ${isToday ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                      {dayCals} kcal
                    </p>
                  )}
                </div>

                {/* Meal slots */}
                <div className="p-2 space-y-2">
                  {MEAL_TYPES.map((meal) => {
                    const mealPlans = dayPlans[meal];
                    return (
                      <div key={meal} className={`rounded-lg border p-2 ${MEAL_COLORS[meal]}`}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-semibold">{MEAL_LABELS[meal]}</span>
                          <button
                            onClick={() => openAddDialog(dateStr, meal)}
                            className="w-5 h-5 rounded-full bg-white/60 hover:bg-white flex items-center justify-center transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        {mealPlans.length === 0 ? (
                          <p className="text-xs opacity-50 italic">Empty</p>
                        ) : (
                          <div className="space-y-1">
                            {mealPlans.map((plan) => {
                              const planCals = plan.product
                                ? Math.round(((plan.product.calories ?? 0) * plan.amountGrams) / 100)
                                : 0;
                              return (
                                <div key={plan.id} className="flex items-center justify-between gap-1 bg-white/60 rounded px-1.5 py-1">
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-medium truncate">{plan.product?.name ?? "Unknown"}</p>
                                    <p className="text-xs opacity-70">{plan.amountGrams}g · {planCals} kcal</p>
                                  </div>
                                  <div className="flex gap-0.5 shrink-0">
                                    {isToday && (
                                      <button
                                        onClick={() => logMutation.mutate({ mealPlanId: plan.id })}
                                        className="p-0.5 hover:text-green-600 transition-colors"
                                        title="Log to today"
                                      >
                                        <CheckCircle2 className="w-3.5 h-3.5" />
                                      </button>
                                    )}
                                    <button
                                      onClick={() => removeMutation.mutate({ id: plan.id })}
                                      className="p-0.5 hover:text-red-500 transition-colors"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Add Meal Dialog */}
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Utensils className="w-5 h-5 text-primary" />
                Add to Meal Plan
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Meal</Label>
                  <Select value={selectedMeal} onValueChange={(v) => setSelectedMeal(v as MealType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MEAL_TYPES.map((m) => (
                        <SelectItem key={m} value={m}>{MEAL_LABELS[m]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Search Food</Label>
                <Input
                  placeholder="Type to search..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setSelectedProductId(null); }}
                />
                {searchResults.length > 0 && !selectedProductId && (
                  <div className="border rounded-lg overflow-hidden max-h-48 overflow-y-auto">
                    {searchResults.map((p: any) => (
                      <button
                        key={p.id}
                        className="w-full text-left px-3 py-2 hover:bg-muted transition-colors border-b last:border-0"
                        onClick={() => { setSelectedProductId(p.id); setSearchQuery(p.name); }}
                      >
                        <p className="text-sm font-medium">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{p.calories ?? 0} kcal/100g</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <Label>Amount (grams)</Label>
                <Input
                  type="number"
                  min={1}
                  max={2000}
                  value={amountGrams}
                  onChange={(e) => setAmountGrams(e.target.value)}
                />
              </div>

              {selectedProductId && (
                <div className="bg-muted rounded-lg px-3 py-2 text-sm text-muted-foreground">
                  ✓ Selected: <strong className="text-foreground">{searchQuery}</strong>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setAddOpen(false)}>
                  Cancel
                </Button>
                <Button className="flex-1" onClick={handleAdd} disabled={addMutation.isPending}>
                  {addMutation.isPending ? "Adding..." : "Add to Plan"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
