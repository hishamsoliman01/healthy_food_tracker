import { useState } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { UserPlus, Users, Check, X, Trash2, Trophy, Flame } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Friends() {
  const { user } = useAuth();
  const [friendOpenId, setFriendOpenId] = useState("");

  const { data: friendships = [], refetch } = trpc.friends.list.useQuery();

  const sendMutation = trpc.friends.sendRequest.useMutation({
    onSuccess: (data) => {
      toast.success(`Friend request sent to ${data.friendName ?? "user"}!`);
      setFriendOpenId("");
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const respondMutation = trpc.friends.respond.useMutation({
    onSuccess: (_, vars) => {
      toast.success(vars.accept ? "Friend request accepted!" : "Request declined");
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const removeMutation = trpc.friends.remove.useMutation({
    onSuccess: () => { toast.success("Friend removed"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const myId = user?.id?.toString() ?? "";

  const pending = friendships.filter(
    (f) => f.status === "pending" && f.friendId === myId
  );
  const sent = friendships.filter(
    (f) => f.status === "pending" && f.userId === myId
  );
  const accepted = friendships.filter((f) => f.status === "accepted");

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6 max-w-2xl mx-auto">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" />
            Friends
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Connect with friends and compete on challenges together
          </p>
        </div>

        {/* Add Friend */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-primary" />
              Add a Friend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground mb-3">
              Enter your friend's NutriTrack User ID (found in their Profile page)
            </p>
            <div className="flex gap-2">
              <Input
                placeholder="Paste User ID here..."
                value={friendOpenId}
                onChange={(e) => setFriendOpenId(e.target.value)}
                className="flex-1"
              />
              <Button
                onClick={() => {
                  if (!friendOpenId.trim()) { toast.error("Enter a User ID"); return; }
                  sendMutation.mutate({ friendOpenId: friendOpenId.trim() });
                }}
                disabled={sendMutation.isPending}
              >
                {sendMutation.isPending ? "Sending..." : "Send Request"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pending incoming requests */}
        {pending.length > 0 && (
          <Card className="border-amber-200 bg-amber-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-amber-800">
                Incoming Requests ({pending.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {pending.map((f) => (
                <div key={f.id} className="flex items-center justify-between bg-white rounded-lg px-3 py-2 border border-amber-100">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-amber-100 text-amber-700 text-xs">
                        {f.userId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">User {f.userId.slice(0, 8)}...</p>
                      <p className="text-xs text-muted-foreground">Wants to be your friend</p>
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <Button
                      size="sm"
                      className="h-7 gap-1"
                      onClick={() => respondMutation.mutate({ id: f.id, accept: true })}
                    >
                      <Check className="w-3 h-3" /> Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 gap-1"
                      onClick={() => respondMutation.mutate({ id: f.id, accept: false })}
                    >
                      <X className="w-3 h-3" /> Decline
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Sent requests */}
        {sent.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-muted-foreground">
                Sent Requests ({sent.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {sent.map((f) => (
                <div key={f.id} className="flex items-center justify-between bg-muted/30 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">
                        {f.friendId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">User {f.friendId.slice(0, 8)}...</p>
                      <Badge variant="secondary" className="text-xs h-4">Pending</Badge>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 text-muted-foreground hover:text-destructive"
                    onClick={() => removeMutation.mutate({ id: f.id })}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Friends list */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Trophy className="w-4 h-4 text-primary" />
              My Friends ({accepted.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {accepted.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No friends yet</p>
                <p className="text-xs mt-1">Send a friend request to get started!</p>
              </div>
            ) : (
              <div className="space-y-2">
                {accepted.map((f, idx) => {
                  const isMe = f.userId === myId;
                  const displayId = isMe ? f.friendId : f.userId;
                  return (
                    <div key={f.id} className="flex items-center justify-between bg-muted/30 rounded-lg px-3 py-2.5">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <Avatar className="w-9 h-9">
                            <AvatarFallback className="bg-primary/10 text-primary text-sm font-bold">
                              {displayId.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          {idx === 0 && (
                            <span className="absolute -top-1 -right-1 text-xs">🥇</span>
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">Friend {idx + 1}</p>
                          <p className="text-xs text-muted-foreground">ID: {displayId.slice(0, 12)}...</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 text-orange-500">
                          <Flame className="w-3.5 h-3.5" />
                          <span className="text-xs font-semibold">—</span>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-muted-foreground hover:text-destructive"
                          onClick={() => removeMutation.mutate({ id: f.id })}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Your ID card */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-4">
            <p className="text-sm font-medium text-foreground mb-1">Your User ID</p>
            <p className="text-xs text-muted-foreground mb-2">Share this with friends so they can add you</p>
            <div className="flex items-center gap-2">
              <code className="flex-1 bg-background border rounded px-3 py-1.5 text-xs font-mono break-all">
                {user?.openId ?? "Login to see your ID"}
              </code>
              <Button
                size="sm"
                variant="outline"
                className="shrink-0"
                onClick={() => {
                  if (user?.openId) {
                    navigator.clipboard.writeText(user.openId);
                    toast.success("Copied to clipboard!");
                  }
                }}
              >
                Copy
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
