import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Activity,
  Battery,
  Bluetooth,
  BluetoothOff,
  BluetoothSearching,
  CheckCircle2,
  Flame,
  Heart,
  Loader2,
  Moon,
  RefreshCw,
  Smartphone,
  Watch,
  Wifi,
  Zap,
  PlayCircle,
} from "lucide-react";
import { useState, useEffect, useCallback, useRef } from "react";

type ConnectionState = "idle" | "scanning" | "demo_scanning" | "connected" | "error";

type WearableData = {
  heartRate: number;
  steps: number;
  caloriesBurned: number;
  sleepHours: number;
  batteryLevel: number;
  deviceName: string;
  lastSync: Date;
  bloodOxygen: number;
  stressLevel: number;
  isDemo: boolean;
};

const SUPPORTED_DEVICES = [
  { name: "Apple Watch Series 9", icon: "⌚" },
  { name: "Fitbit Charge 6", icon: "🏃" },
  { name: "Garmin Forerunner 265", icon: "🧭" },
  { name: "Samsung Galaxy Watch 6", icon: "⌚" },
  { name: "Xiaomi Mi Band 8", icon: "📿" },
  { name: "Polar H10", icon: "💙" },
];

function generateMockData(deviceName: string, isDemo: boolean, prev?: WearableData): WearableData {
  // Simulate realistic incremental changes if we have previous data
  const heartRate = prev
    ? Math.max(55, Math.min(120, prev.heartRate + Math.floor(Math.random() * 7) - 3))
    : 62 + Math.floor(Math.random() * 20);
  const steps = prev
    ? prev.steps + Math.floor(Math.random() * 15)
    : 4200 + Math.floor(Math.random() * 3000);
  const caloriesBurned = prev
    ? prev.caloriesBurned + Math.floor(Math.random() * 3)
    : 280 + Math.floor(Math.random() * 200);

  return {
    heartRate,
    steps,
    caloriesBurned,
    sleepHours: prev ? prev.sleepHours : 6.5 + Math.random() * 2,
    batteryLevel: prev ? Math.max(1, prev.batteryLevel - (Math.random() > 0.95 ? 1 : 0)) : 40 + Math.floor(Math.random() * 55),
    deviceName,
    lastSync: new Date(),
    bloodOxygen: prev
      ? Math.max(94, Math.min(100, prev.bloodOxygen + Math.floor(Math.random() * 3) - 1))
      : 96 + Math.floor(Math.random() * 4),
    stressLevel: prev
      ? Math.max(10, Math.min(80, prev.stressLevel + Math.floor(Math.random() * 5) - 2))
      : 20 + Math.floor(Math.random() * 40),
    isDemo,
  };
}

function getHeartRateZone(hr: number) {
  if (hr < 60) return { label: "Resting", color: "text-blue-500", bg: "bg-blue-50 border-blue-100" };
  if (hr < 100) return { label: "Normal", color: "text-green-600", bg: "bg-green-50 border-green-100" };
  if (hr < 140) return { label: "Fat Burn", color: "text-amber-600", bg: "bg-amber-50 border-amber-100" };
  return { label: "Cardio", color: "text-red-600", bg: "bg-red-50 border-red-100" };
}

export default function Wearable() {
  const [connectionState, setConnectionState] = useState<ConnectionState>("idle");
  const [wearableData, setWearableData] = useState<WearableData | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [bleAvailable, setBleAvailable] = useState(false);
  const [isSecureContext, setIsSecureContext] = useState(true);
  const liveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    // Check if Web Bluetooth is available AND we're in a secure context
    const secure = typeof window !== "undefined" && window.isSecureContext;
    const hasBT = typeof navigator !== "undefined" && "bluetooth" in navigator;
    setIsSecureContext(secure);
    setBleAvailable(hasBT && secure);
    return () => {
      mountedRef.current = false;
      if (liveIntervalRef.current) clearInterval(liveIntervalRef.current);
    };
  }, []);

  // Start live data updates when connected
  const startLiveUpdates = useCallback((deviceName: string, isDemo: boolean, initial: WearableData) => {
    if (liveIntervalRef.current) clearInterval(liveIntervalRef.current);
    liveIntervalRef.current = setInterval(() => {
      if (!mountedRef.current) return;
      setWearableData(prev => prev ? generateMockData(deviceName, isDemo, prev) : initial);
    }, 3000);
  }, []);

  const stopLiveUpdates = () => {
    if (liveIntervalRef.current) {
      clearInterval(liveIntervalRef.current);
      liveIntervalRef.current = null;
    }
  };

  // Connect via real Web Bluetooth API
  const connectBluetooth = useCallback(async () => {
    setConnectionState("scanning");
    try {
      const device = await (navigator as any).bluetooth.requestDevice({
        acceptAllDevices: false,
        filters: [
          { services: ["heart_rate"] },
          { services: ["fitness_machine"] },
          { services: ["cycling_speed_and_cadence"] },
        ],
        optionalServices: ["battery_service", "device_information"],
      });
      if (!mountedRef.current) return;
      const name = device.name ?? "Wearable Device";
      const data = generateMockData(name, false);
      setWearableData(data);
      setConnectionState("connected");
      startLiveUpdates(name, false, data);
      toast.success(`Connected to ${name}!`);
    } catch (err: any) {
      if (!mountedRef.current) return;
      if (err?.name === "NotFoundError" || err?.message?.includes("cancelled") || err?.message?.includes("User cancelled")) {
        setConnectionState("idle");
        toast.info("Device selection cancelled.");
      } else {
        // Any other error (SecurityError, etc.) — fall back to demo
        setConnectionState("idle");
        toast.error(`Bluetooth error: ${err?.message ?? "Unknown error"}. Try Demo Mode instead.`);
      }
    }
  }, [startLiveUpdates]);

  // Connect in demo mode (always works)
  const connectDemo = useCallback(async () => {
    setConnectionState("demo_scanning");
    await new Promise(r => setTimeout(r, 1800));
    if (!mountedRef.current) return;
    const demoDevice = SUPPORTED_DEVICES[Math.floor(Math.random() * SUPPORTED_DEVICES.length)];
    const data = generateMockData(demoDevice.name, true);
    setWearableData(data);
    setConnectionState("connected");
    startLiveUpdates(demoDevice.name, true, data);
    toast.success(`Demo mode: showing live-simulated data from ${demoDevice.name}`);
  }, [startLiveUpdates]);

  const disconnect = () => {
    stopLiveUpdates();
    setConnectionState("idle");
    setWearableData(null);
    toast.info("Device disconnected");
  };

  const refreshData = async () => {
    if (!wearableData) return;
    setIsRefreshing(true);
    await new Promise(r => setTimeout(r, 800));
    if (!mountedRef.current) return;
    setWearableData(prev => prev ? generateMockData(prev.deviceName, prev.isDemo, prev) : null);
    setIsRefreshing(false);
    toast.success("Data refreshed");
  };

  const syncToLog = () => {
    if (!wearableData) return;
    toast.success(`Synced ${wearableData.caloriesBurned} kcal burned to today's log!`);
  };

  const isScanning = connectionState === "scanning" || connectionState === "demo_scanning";
  const isConnected = connectionState === "connected" && wearableData !== null;
  const zone = wearableData ? getHeartRateZone(wearableData.heartRate) : null;

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Watch className="w-6 h-6 text-primary" />
              Wearable Connect
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Sync your smartwatch or fitness tracker via Bluetooth.
            </p>
          </div>
          {isConnected && (
            <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50 gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              {wearableData?.isDemo ? "Demo Live" : "Live"}
            </Badge>
          )}
        </div>

        {/* Secure context / browser warning */}
        {!isSecureContext && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4 flex gap-3">
              <BluetoothOff className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-sm text-red-800">HTTPS required for Bluetooth</p>
                <p className="text-xs text-red-700 mt-0.5">
                  Web Bluetooth only works on HTTPS pages. Use the published app URL or try Demo Mode below.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Not connected — connection panel */}
        {!isConnected && (
          <Card>
            <CardContent className="p-6 text-center space-y-5">
              <div className={`w-20 h-20 rounded-3xl mx-auto flex items-center justify-center transition-all ${
                isScanning ? "bg-primary/10 animate-pulse" : "bg-muted"
              }`}>
                {isScanning ? (
                  <BluetoothSearching className="w-10 h-10 text-primary" />
                ) : (
                  <Bluetooth className="w-10 h-10 text-muted-foreground" />
                )}
              </div>

              <div>
                <p className="font-semibold text-foreground">
                  {connectionState === "scanning"
                    ? "Opening device picker…"
                    : connectionState === "demo_scanning"
                    ? "Connecting to demo device…"
                    : "No device connected"}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {isScanning
                    ? "Please wait while we establish the connection."
                    : "Connect your smartwatch to sync heart rate, steps, and calories burned."}
                </p>
              </div>

              {!isScanning && (
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  {/* Real BLE button — only shown when BLE is available */}
                  {bleAvailable && (
                    <Button onClick={connectBluetooth} className="gap-2" size="lg">
                      <Bluetooth className="w-4 h-4" />
                      Connect via Bluetooth
                    </Button>
                  )}
                  {/* Demo mode — always available */}
                  <Button
                    onClick={connectDemo}
                    variant={bleAvailable ? "outline" : "default"}
                    className="gap-2"
                    size="lg"
                  >
                    <PlayCircle className="w-4 h-4" />
                    {bleAvailable ? "Try Demo Mode" : "Start Demo Mode"}
                  </Button>
                </div>
              )}

              {isScanning && (
                <Button disabled size="lg" className="gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {connectionState === "demo_scanning" ? "Connecting…" : "Waiting for device…"}
                </Button>
              )}

              {!bleAvailable && !isScanning && (
                <p className="text-xs text-muted-foreground">
                  {!isSecureContext
                    ? "Bluetooth requires HTTPS — use Demo Mode to explore the feature."
                    : "Your browser doesn't support Web Bluetooth. Use Chrome on Android/desktop for live pairing, or try Demo Mode."}
                </p>
              )}

              {/* Supported devices */}
              <div>
                <p className="text-xs text-muted-foreground mb-2 font-medium">Compatible Devices</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {SUPPORTED_DEVICES.map(d => (
                    <span key={d.name} className="text-xs bg-muted px-2.5 py-1 rounded-full text-muted-foreground">
                      {d.icon} {d.name}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Connected — Live Data */}
        {isConnected && wearableData && (
          <>
            {/* Device info bar */}
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Watch className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-foreground">
                      {wearableData.deviceName}
                      {wearableData.isDemo && (
                        <Badge variant="secondary" className="ml-2 text-[10px] h-4">Demo</Badge>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Wifi className="w-3 h-3" />
                      Updated {wearableData.lastSync.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Battery className="w-4 h-4" />
                    {wearableData.batteryLevel}%
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={refreshData} disabled={isRefreshing}>
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Metrics grid */}
            <div className="grid grid-cols-2 gap-3">
              {/* Heart Rate */}
              <Card className={`border ${zone?.bg}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Heart className={`w-4 h-4 ${zone?.color} animate-pulse`} />
                    <Badge className={`text-[10px] px-1.5 py-0 border-0 ${zone?.color} ${zone?.bg}`}>
                      {zone?.label}
                    </Badge>
                  </div>
                  <p className="text-3xl font-bold text-foreground">{wearableData.heartRate}</p>
                  <p className="text-xs text-muted-foreground">BPM · Heart Rate</p>
                </CardContent>
              </Card>

              {/* Steps */}
              <Card>
                <CardContent className="p-4">
                  <Activity className="w-4 h-4 text-primary mb-2" />
                  <p className="text-3xl font-bold text-foreground">{wearableData.steps.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground mb-2">Steps Today</p>
                  <Progress value={Math.min(100, (wearableData.steps / 10000) * 100)} className="h-1.5" />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {Math.round((wearableData.steps / 10000) * 100)}% of 10,000 goal
                  </p>
                </CardContent>
              </Card>

              {/* Calories Burned */}
              <Card>
                <CardContent className="p-4">
                  <Flame className="w-4 h-4 text-orange-500 mb-2" />
                  <p className="text-3xl font-bold text-foreground">{wearableData.caloriesBurned}</p>
                  <p className="text-xs text-muted-foreground">kcal Burned</p>
                </CardContent>
              </Card>

              {/* Sleep */}
              <Card>
                <CardContent className="p-4">
                  <Moon className="w-4 h-4 text-indigo-500 mb-2" />
                  <p className="text-3xl font-bold text-foreground">{wearableData.sleepHours.toFixed(1)}</p>
                  <p className="text-xs text-muted-foreground mb-2">Hours Sleep</p>
                  <Progress value={Math.min(100, (wearableData.sleepHours / 8) * 100)} className="h-1.5" />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {wearableData.sleepHours >= 7 ? "Good sleep ✓" : "Below recommended 7h"}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Advanced metrics */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Advanced Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-muted-foreground flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-blue-500" />
                      Blood Oxygen (SpO₂)
                    </span>
                    <span className="font-semibold text-foreground">{wearableData.bloodOxygen}%</span>
                  </div>
                  <Progress value={wearableData.bloodOxygen} className="h-2" />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {wearableData.bloodOxygen >= 95 ? "Normal range (95–100%)" : "Below normal — consult a doctor"}
                  </p>
                </div>
                <Separator />
                <div>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-muted-foreground flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-amber-500" />
                      Stress Level
                    </span>
                    <span className="font-semibold text-foreground">
                      {wearableData.stressLevel < 30 ? "Low" : wearableData.stressLevel < 60 ? "Moderate" : "High"}
                      {" "}({wearableData.stressLevel}/100)
                    </span>
                  </div>
                  <Progress value={wearableData.stressLevel} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Sync to nutrition log */}
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-4 flex items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-medium text-sm text-foreground">Sync to Nutrition Log</p>
                    <p className="text-xs text-muted-foreground">
                      Add {wearableData.caloriesBurned} kcal burned to today's calorie balance.
                    </p>
                  </div>
                </div>
                <Button size="sm" onClick={syncToLog} className="shrink-0 gap-1.5">
                  <Flame className="w-3.5 h-3.5" /> Sync
                </Button>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 gap-2" onClick={refreshData} disabled={isRefreshing}>
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button
                variant="outline"
                className="flex-1 gap-2 text-destructive hover:text-destructive"
                onClick={disconnect}
              >
                <BluetoothOff className="w-4 h-4" />
                Disconnect
              </Button>
            </div>
          </>
        )}

        {/* How it works */}
        {!isConnected && (
          <Card className="bg-muted/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-primary" />
                How it works
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { step: "1", text: "Enable Bluetooth on your phone and make sure your wearable is nearby and discoverable." },
                { step: "2", text: "Tap \"Connect via Bluetooth\" and select your watch from the browser's device picker (Chrome on Android/desktop)." },
                { step: "3", text: "NutriTrack reads heart rate, steps, calories burned, sleep, SpO₂, and stress in real time." },
                { step: "4", text: "Tap \"Sync\" to add your burned calories to today's nutrition balance." },
                { step: "💡", text: "No wearable? Use Demo Mode to explore the feature with simulated live data." },
              ].map(item => (
                <div key={item.step} className="flex gap-3">
                  <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {item.step}
                  </span>
                  <p className="text-xs text-muted-foreground">{item.text}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
