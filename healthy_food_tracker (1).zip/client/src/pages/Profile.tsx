import { useEffect, useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  User,
  Weight,
  Ruler,
  Activity,
  Target,
  Flame,
  Dumbbell,
  TrendingDown,
  Minus,
  CheckCircle2,
  Info,
} from "lucide-react";

const profileSchema = z.object({
  gender: z.enum(["male", "female"]),
  age: z.coerce.number().int().min(10).max(120),
  weight: z.coerce.number().min(20).max(500),
  height: z.coerce.number().min(50).max(300),
  activityLevel: z.enum([
    "sedentary",
    "lightly_active",
    "moderately_active",
    "very_active",
    "extra_active",
  ]),
  goal: z.enum(["lose_weight", "maintain", "gain_muscle"]),
});

type ProfileForm = z.infer<typeof profileSchema>;

const ACTIVITY_OPTIONS = [
  {
    value: "sedentary",
    label: "Sedentary",
    description: "Desk job, little or no exercise",
    multiplier: "×1.2",
  },
  {
    value: "lightly_active",
    label: "Lightly Active",
    description: "Light exercise 1–3 days/week",
    multiplier: "×1.375",
  },
  {
    value: "moderately_active",
    label: "Moderately Active",
    description: "Moderate exercise 3–5 days/week",
    multiplier: "×1.55",
  },
  {
    value: "very_active",
    label: "Very Active",
    description: "Hard exercise 6–7 days/week",
    multiplier: "×1.725",
  },
  {
    value: "extra_active",
    label: "Extra Active",
    description: "Very hard exercise + physical job",
    multiplier: "×1.9",
  },
];

const GOAL_OPTIONS = [
  {
    value: "lose_weight",
    label: "Lose Weight",
    description: "Calorie deficit of 500 kcal/day",
    icon: TrendingDown,
    color: "text-blue-600",
    bg: "bg-blue-50 border-blue-200",
  },
  {
    value: "maintain",
    label: "Maintain Weight",
    description: "Eat at your maintenance calories",
    icon: Minus,
    color: "text-green-600",
    bg: "bg-green-50 border-green-200",
  },
  {
    value: "gain_muscle",
    label: "Gain Muscle",
    description: "Calorie surplus of 300 kcal/day",
    icon: Dumbbell,
    color: "text-orange-600",
    bg: "bg-orange-50 border-orange-200",
  },
];

function StatCard({ label, value, unit, icon: Icon, color }: {
  label: string; value: number | string; unit: string; icon: React.ElementType; color: string;
}) {
  return (
    <div className="flex flex-col gap-1 p-4 rounded-xl bg-white border border-border shadow-sm">
      <div className={`flex items-center gap-2 text-sm font-medium ${color}`}>
        <Icon className="h-4 w-4" />
        {label}
      </div>
      <div className="text-2xl font-bold text-foreground">
        {typeof value === "number" ? value.toLocaleString() : value}
        <span className="text-sm font-normal text-muted-foreground ml-1">{unit}</span>
      </div>
    </div>
  );
}

export default function Profile() {
  const { data: profile, isLoading, refetch } = trpc.profile.get.useQuery();
  const saveMutation = trpc.profile.save.useMutation({
    onSuccess: () => {
      toast.success("Profile saved! Your calorie targets have been updated.");
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const [selectedGoal, setSelectedGoal] = useState<string>("maintain");
  const [selectedActivity, setSelectedActivity] = useState<string>("moderately_active");

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isDirty },
  } = useForm<ProfileForm>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(profileSchema) as any,
    defaultValues: {
      gender: "male",
      age: 25,
      weight: 70,
      height: 170,
      activityLevel: "moderately_active",
      goal: "maintain",
    },
  });

  // Populate form when profile loads
  useEffect(() => {
    if (profile) {
      reset({
        gender: profile.gender,
        age: profile.age,
        weight: profile.weight,
        height: profile.height,
        activityLevel: profile.activityLevel,
        goal: profile.goal,
      });
      setSelectedGoal(profile.goal);
      setSelectedActivity(profile.activityLevel);
    }
  }, [profile, reset]);

  const onSubmit = (data: ProfileForm) => {
    saveMutation.mutate(data);
  };

  const weight = watch("weight");
  const height = watch("height");
  const age = watch("age");
  const gender = watch("gender");

  // Live BMR preview
  const liveBMR = (() => {
    if (!weight || !height || !age) return null;
    const base = 10 * weight + 6.25 * height - 5 * age;
    return Math.round(gender === "male" ? base + 5 : base - 161);
  })();

  const MULTIPLIERS: Record<string, number> = {
    sedentary: 1.2, lightly_active: 1.375, moderately_active: 1.55,
    very_active: 1.725, extra_active: 1.9,
  };
  const liveTDEE = liveBMR ? Math.round(liveBMR * (MULTIPLIERS[selectedActivity] ?? 1.55)) : null;
  const liveTarget = liveTDEE
    ? selectedGoal === "lose_weight" ? Math.max(1200, liveTDEE - 500)
      : selectedGoal === "gain_muscle" ? liveTDEE + 300
        : liveTDEE
    : null;

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto space-y-8 pb-12">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">My Profile</h1>
          <p className="text-muted-foreground mt-1">
            Enter your body data and daily activity to get a personalised calorie target.
          </p>
        </div>

        {/* Saved results banner */}
        {profile && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatCard label="BMR" value={profile.bmr} unit="kcal" icon={Flame} color="text-orange-500" />
            <StatCard label="TDEE" value={profile.tdee} unit="kcal" icon={Activity} color="text-blue-500" />
            <StatCard label="Daily Target" value={profile.calorieTarget} unit="kcal" icon={Target} color="text-green-600" />
            <StatCard label="Protein Goal" value={profile.macroTargets.proteins} unit="g/day" icon={Dumbbell} color="text-purple-500" />
          </div>
        )}

        {/* Live preview while editing */}
        {!profile && liveTarget && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-4 pb-3">
              <div className="flex items-center gap-2 text-sm text-primary font-medium mb-2">
                <Info className="h-4 w-4" /> Live preview — save to apply
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-xl font-bold">{liveBMR?.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">BMR (kcal)</div>
                </div>
                <div>
                  <div className="text-xl font-bold">{liveTDEE?.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">TDEE (kcal)</div>
                </div>
                <div>
                  <div className="text-xl font-bold text-primary">{liveTarget?.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">Daily Target</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit(onSubmit as unknown as SubmitHandler<Record<string, unknown>>)} className="space-y-6">
          {/* Body Data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <User className="h-4 w-4 text-primary" /> Body Data
              </CardTitle>
              <CardDescription>Used to calculate your Basal Metabolic Rate (BMR)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Gender */}
              <div className="space-y-2">
                <Label>Gender</Label>
                <div className="flex gap-3">
                  {(["male", "female"] as const).map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setValue("gender", g, { shouldDirty: true })}
                      className={`flex-1 py-2.5 rounded-lg border text-sm font-medium transition-all capitalize ${
                        watch("gender") === g
                          ? "bg-primary text-primary-foreground border-primary shadow-sm"
                          : "bg-background text-foreground border-border hover:border-primary/50"
                      }`}
                    >
                      {g === "male" ? "♂ Male" : "♀ Female"}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {/* Age */}
                <div className="space-y-2">
                  <Label htmlFor="age" className="flex items-center gap-1.5">
                    Age <span className="text-muted-foreground font-normal">(years)</span>
                  </Label>
                  <Input id="age" type="number" min={10} max={120} {...register("age")} />
                  {errors.age && <p className="text-xs text-destructive">{errors.age.message}</p>}
                </div>

                {/* Weight */}
                <div className="space-y-2">
                  <Label htmlFor="weight" className="flex items-center gap-1.5">
                    <Weight className="h-3.5 w-3.5" /> Weight <span className="text-muted-foreground font-normal">(kg)</span>
                  </Label>
                  <Input id="weight" type="number" step="0.1" min={20} max={500} {...register("weight")} />
                  {errors.weight && <p className="text-xs text-destructive">{errors.weight.message}</p>}
                </div>

                {/* Height */}
                <div className="space-y-2">
                  <Label htmlFor="height" className="flex items-center gap-1.5">
                    <Ruler className="h-3.5 w-3.5" /> Height <span className="text-muted-foreground font-normal">(cm)</span>
                  </Label>
                  <Input id="height" type="number" step="0.1" min={50} max={300} {...register("height")} />
                  {errors.height && <p className="text-xs text-destructive">{errors.height.message}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Activity Level */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Activity className="h-4 w-4 text-primary" /> Daily Activity Level
              </CardTitle>
              <CardDescription>How active are you on a typical day?</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {ACTIVITY_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => {
                      setValue("activityLevel", opt.value as ProfileForm["activityLevel"], { shouldDirty: true });
                      setSelectedActivity(opt.value);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-lg border text-left transition-all ${
                      selectedActivity === opt.value
                        ? "bg-primary/10 border-primary text-foreground"
                        : "bg-background border-border hover:border-primary/40"
                    }`}
                  >
                    <div>
                      <div className="font-medium text-sm">{opt.label}</div>
                      <div className="text-xs text-muted-foreground">{opt.description}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs font-mono">{opt.multiplier}</Badge>
                      {selectedActivity === opt.value && (
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Goal */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Target className="h-4 w-4 text-primary" /> Your Goal
              </CardTitle>
              <CardDescription>This adjusts your daily calorie target</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {GOAL_OPTIONS.map((opt) => {
                  const Icon = opt.icon;
                  const isSelected = selectedGoal === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => {
                        setValue("goal", opt.value as ProfileForm["goal"], { shouldDirty: true });
                        setSelectedGoal(opt.value);
                      }}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-center transition-all ${
                        isSelected ? opt.bg + " shadow-sm" : "bg-background border-border hover:border-primary/30"
                      }`}
                    >
                      <Icon className={`h-6 w-6 ${isSelected ? opt.color : "text-muted-foreground"}`} />
                      <div className={`font-semibold text-sm ${isSelected ? opt.color : "text-foreground"}`}>
                        {opt.label}
                      </div>
                      <div className="text-xs text-muted-foreground">{opt.description}</div>
                      {isSelected && <CheckCircle2 className={`h-4 w-4 ${opt.color}`} />}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Formula explanation */}
          <Card className="bg-muted/30">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-start gap-3">
                <Info className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                <div className="text-xs text-muted-foreground space-y-1">
                  <p><strong>BMR</strong> (Basal Metabolic Rate) is calculated using the <strong>Mifflin-St Jeor</strong> equation — the most accurate formula for estimating resting calorie burn.</p>
                  <p><strong>TDEE</strong> (Total Daily Energy Expenditure) = BMR × activity multiplier.</p>
                  <p>Your <strong>daily target</strong> is then adjusted based on your goal (−500 kcal to lose weight, +300 kcal to gain muscle).</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Separator />

          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? "Saving…" : profile ? "Update Profile" : "Save Profile & Calculate Targets"}
          </Button>
        </form>
      </div>
    </DashboardLayout>
  );
}
