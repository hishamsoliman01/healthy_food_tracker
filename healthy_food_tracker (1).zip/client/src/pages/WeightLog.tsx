import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Scale, TrendingDown, TrendingUp, Minus, Trash2 } from "lucide-react";
import { useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";

export default function WeightLog() {
  const utils = trpc.useUtils();
  const [weightInput, setWeightInput] = useState("");
  const [notes, setNotes] = useState("");
  const [days, setDays] = useState(30);

  const { data: logs = [], isLoading } = trpc.weight.list.useQuery({ days });
  const profile = trpc.profile.get.useQuery();

  const addMutation = trpc.weight.add.useMutation({
    onSuccess: () => {
      utils.weight.list.invalidate();
      setWeightInput("");
      setNotes("");
      toast.success("Weight logged!");
    },
    onError: () => toast.error("Failed to log weight"),
  });

  const deleteMutation = trpc.weight.delete.useMutation({
    onSuccess: () => utils.weight.list.invalidate(),
    onError: () => toast.error("Failed to delete entry"),
  });

  const handleAdd = () => {
    const kg = parseFloat(weightInput);
    if (isNaN(kg) || kg < 20 || kg > 500) {
      toast.error("Please enter a valid weight (20–500 kg)");
      return;
    }
    addMutation.mutate({ weightKg: kg, notes: notes || undefined });
  };

  const chartData = logs.map((l) => ({
    date: new Date(l.loggedAt).toLocaleDateString([], { month: "short", day: "numeric" }),
    weight: l.weightKg,
  }));

  const latestWeight = logs.length > 0 ? logs[logs.length - 1]!.weightKg : null;
  const firstWeight = logs.length > 0 ? logs[0]!.weightKg : null;
  const change = latestWeight !== null && firstWeight !== null ? latestWeight - firstWeight : null;
  const goalWeight = profile.data?.weight ?? null;

  const TrendIcon = change === null ? Minus : change < 0 ? TrendingDown : change > 0 ? TrendingUp : Minus;
  const trendColor = change === null ? "text-muted-foreground" : change < 0 ? "text-emerald-600" : change > 0 ? "text-rose-500" : "text-muted-foreground";

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Scale className="h-6 w-6 text-violet-500" />
            Weight Log
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Track your weight over time to monitor progress toward your goal
          </p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <p className="text-xs text-muted-foreground mb-1">Current</p>
              <p className="text-xl font-bold text-foreground">
                {latestWeight !== null ? `${latestWeight}kg` : "—"}
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <p className="text-xs text-muted-foreground mb-1">{days}-day change</p>
              <p className={`text-xl font-bold flex items-center justify-center gap-1 ${trendColor}`}>
                <TrendIcon className="h-4 w-4" />
                {change !== null ? `${change > 0 ? "+" : ""}${change.toFixed(1)}kg` : "—"}
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <p className="text-xs text-muted-foreground mb-1">Profile weight</p>
              <p className="text-xl font-bold text-foreground">
                {goalWeight !== null ? `${goalWeight}kg` : "—"}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        {logs.length > 1 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-base font-semibold">Trend</CardTitle>
              <div className="flex gap-1">
                {[30, 60, 90].map((d) => (
                  <Button
                    key={d}
                    variant={days === d ? "default" : "outline"}
                    size="sm"
                    className="h-6 text-xs px-2"
                    onClick={() => setDays(d)}
                  >
                    {d}d
                  </Button>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
                  <defs>
                    <linearGradient id="weightGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                  <YAxis
                    tick={{ fontSize: 10 }} tickLine={false} axisLine={false}
                    domain={["auto", "auto"]}
                    tickFormatter={(v) => `${v}kg`}
                  />
                  <Tooltip
                    formatter={(v: number) => [`${v}kg`, "Weight"]}
                    contentStyle={{ fontSize: 12, borderRadius: 8 }}
                  />
                  <Area
                    type="monotone" dataKey="weight"
                    stroke="#8b5cf6" strokeWidth={2}
                    fill="url(#weightGrad)"
                    dot={{ fill: "#8b5cf6", r: 3 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Add Entry */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold">Log Today's Weight</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-3">
              <div className="flex-1">
                <Label htmlFor="weight" className="text-xs text-muted-foreground mb-1 block">Weight (kg)</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.1"
                  min="20"
                  max="500"
                  placeholder="e.g. 72.5"
                  value={weightInput}
                  onChange={(e) => setWeightInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="notes" className="text-xs text-muted-foreground mb-1 block">Notes (optional)</Label>
                <Input
                  id="notes"
                  placeholder="e.g. after workout"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            </div>
            <Button
              className="w-full"
              onClick={handleAdd}
              disabled={addMutation.isPending || !weightInput}
            >
              {addMutation.isPending ? "Saving…" : "Log Weight"}
            </Button>
          </CardContent>
        </Card>

        {/* History */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold">History</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => <div key={i} className="h-10 bg-muted rounded animate-pulse" />)}
              </div>
            ) : logs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Scale className="h-10 w-10 mx-auto mb-2 opacity-30 text-violet-400" />
                <p className="text-sm">No weight entries yet.</p>
                <p className="text-xs mt-1">Log your first weight above to start tracking.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {[...logs].reverse().map((log, idx) => {
                  const prev = [...logs].reverse()[idx + 1];
                  const diff = prev ? log.weightKg - prev.weightKg : null;
                  return (
                    <div
                      key={log.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/40 border border-border/50"
                    >
                      <div className="flex items-center gap-3">
                        <Scale className="h-4 w-4 text-violet-500" />
                        <div>
                          <p className="text-sm font-semibold">{log.weightKg} kg</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(log.loggedAt).toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}
                            {log.notes && ` · ${log.notes}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {diff !== null && (
                          <span className={`text-xs font-medium ${diff < 0 ? "text-emerald-600" : diff > 0 ? "text-rose-500" : "text-muted-foreground"}`}>
                            {diff > 0 ? "+" : ""}{diff.toFixed(1)}kg
                          </span>
                        )}
                        <Button
                          variant="ghost" size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-destructive"
                          onClick={() => deleteMutation.mutate({ id: log.id })}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
