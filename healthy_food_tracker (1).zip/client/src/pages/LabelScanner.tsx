import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  AlertCircle,
  Camera,
  CheckCircle2,
  ChevronLeft,
  FlipHorizontal,
  Loader2,
  ScanLine,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type ExtractedData = {
  name: string | null;
  brand: string | null;
  category: string | null;
  ingredients: string | null;
  servingSize: string | null;
  calories: number | null;
  fat: number | null;
  saturatedFat: number | null;
  carbohydrates: number | null;
  sugars: number | null;
  fiber: number | null;
  proteins: number | null;
  salt: number | null;
  sodium: number | null;
};

type FormData = {
  name: string;
  brand: string;
  category: string;
  ingredients: string;
  nutriScore: "A" | "B" | "C" | "D" | "E";
  novaGroup: number;
  calories: string;
  fat: string;
  saturatedFat: string;
  carbohydrates: string;
  sugars: string;
  fiber: string;
  proteins: string;
  salt: string;
};

const NUTRI_SCORES = ["A", "B", "C", "D", "E"] as const;

function guessNutriScore(data: ExtractedData): "A" | "B" | "C" | "D" | "E" {
  const cal = data.calories ?? 0;
  const sat = data.saturatedFat ?? 0;
  const sug = data.sugars ?? 0;
  const fib = data.fiber ?? 0;
  const pro = data.proteins ?? 0;
  // Simple heuristic scoring
  let score = 0;
  if (cal > 400) score += 3; else if (cal > 200) score += 1;
  if (sat > 10) score += 3; else if (sat > 5) score += 1;
  if (sug > 20) score += 2; else if (sug > 10) score += 1;
  if (fib > 5) score -= 2; else if (fib > 2) score -= 1;
  if (pro > 15) score -= 1;
  if (score <= 0) return "A";
  if (score <= 2) return "B";
  if (score <= 4) return "C";
  if (score <= 6) return "D";
  return "E";
}

export default function LabelScanner() {
  const [, navigate] = useLocation();

  // Camera state
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<"environment" | "user">("environment");
  const [capturedImage, setCapturedImage] = useState<string | null>(null); // data URL
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);

  // Flow state
  const [step, setStep] = useState<"capture" | "uploading" | "analyzing" | "review" | "saving" | "done">("capture");
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [form, setForm] = useState<FormData>({
    name: "", brand: "", category: "", ingredients: "",
    nutriScore: "C", novaGroup: 3,
    calories: "", fat: "", saturatedFat: "", carbohydrates: "",
    sugars: "", fiber: "", proteins: "", salt: "",
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scanLabelMutation = trpc.products.scanLabel.useMutation();
  const createProductMutation = trpc.products.create.useMutation();

  // ─── Camera helpers ──────────────────────────────────────────────────────
  const startCamera = useCallback(async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: cameraFacing, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraActive(true);
      setError(null);
    } catch (e) {
      setError("Camera access denied. Please allow camera access or upload a photo instead.");
    }
  }, [cameraFacing]);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setCameraActive(false);
  }, []);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  const flipCamera = async () => {
    const next = cameraFacing === "environment" ? "user" : "environment";
    setCameraFacing(next);
    stopCamera();
    // startCamera will re-run via the effect dependency
  };

  useEffect(() => {
    if (!cameraActive && step === "capture" && !capturedImage) {
      startCamera();
    }
  }, [cameraFacing]); // eslint-disable-line react-hooks/exhaustive-deps

  // ─── Capture photo from camera ───────────────────────────────────────────
  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext("2d")?.drawImage(videoRef.current, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
    setCapturedImage(dataUrl);
    stopCamera();
    processImage(dataUrl);
  };

  // ─── Handle file upload ──────────────────────────────────────────────────
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Image must be under 10 MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setCapturedImage(dataUrl);
      stopCamera();
      processImage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  // ─── Upload to S3 and call AI ─────────────────────────────────────────────
  const processImage = async (dataUrl: string) => {
    setStep("uploading");
    setError(null);
    try {
      // Convert data URL to Blob
      const res = await fetch(dataUrl);
      const blob = await res.blob();

      // Upload to S3 via server endpoint
      const formData = new FormData();
      formData.append("file", blob, "label.jpg");

      const uploadRes = await fetch("/api/upload-label", {
        method: "POST",
        body: formData,
      });

      if (!uploadRes.ok) {
        throw new Error("Upload failed");
      }

      const { url } = await uploadRes.json() as { url: string };
      setUploadedImageUrl(url);
      setStep("analyzing");

      // Call AI label scanner
      const extracted = await scanLabelMutation.mutateAsync({ imageUrl: url });
      populateForm(extracted);
      setStep("review");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to process image";
      setError(msg);
      setStep("capture");
      setCapturedImage(null);
      startCamera();
    }
  };

  const populateForm = (data: ExtractedData) => {
    const n = (v: number | null) => (v != null ? String(v) : "");
    setForm({
      name: data.name ?? "",
      brand: data.brand ?? "",
      category: data.category ?? "",
      ingredients: data.ingredients ?? "",
      nutriScore: guessNutriScore(data),
      novaGroup: 3,
      calories: n(data.calories),
      fat: n(data.fat),
      saturatedFat: n(data.saturatedFat),
      carbohydrates: n(data.carbohydrates),
      sugars: n(data.sugars),
      fiber: n(data.fiber),
      proteins: n(data.proteins),
      salt: n(data.salt),
    });
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast.error("Product name is required");
      return;
    }
    setStep("saving");
    try {
      const product = await createProductMutation.mutateAsync({
        name: form.name,
        brand: form.brand || undefined,
        category: form.category || undefined,
        ingredients: form.ingredients || undefined,
        nutriScore: form.nutriScore,
        novaGroup: form.novaGroup,
        calories: form.calories ? parseFloat(form.calories) : undefined,
        fat: form.fat ? parseFloat(form.fat) : undefined,
        saturatedFat: form.saturatedFat ? parseFloat(form.saturatedFat) : undefined,
        carbohydrates: form.carbohydrates ? parseFloat(form.carbohydrates) : undefined,
        sugars: form.sugars ? parseFloat(form.sugars) : undefined,
        fiber: form.fiber ? parseFloat(form.fiber) : undefined,
        proteins: form.proteins ? parseFloat(form.proteins) : undefined,
        salt: form.salt ? parseFloat(form.salt) : undefined,
      });
      setStep("done");
      toast.success(`"${product.name}" saved to database!`);
      setTimeout(() => navigate(`/products/${product.id}`), 1500);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to save product";
      toast.error(msg);
      setStep("review");
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    setUploadedImageUrl(null);
    setError(null);
    setStep("capture");
    startCamera();
  };

  const setField = (key: keyof FormData, value: string | number) =>
    setForm(prev => ({ ...prev, [key]: value }));

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/scan")}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              AI Label Scanner
            </h1>
            <p className="text-sm text-muted-foreground">
              Point your camera at a nutrition label — AI will extract all the data for you
            </p>
          </div>
        </div>

        {/* Error banner */}
        {error && (
          <div className="flex items-start gap-3 bg-destructive/10 text-destructive rounded-xl p-4 text-sm">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {/* ── Step: Capture ── */}
        {step === "capture" && (
          <div className="space-y-4">
            <Card className="overflow-hidden border-0 shadow-md">
              <div className="relative bg-black aspect-[4/3] flex items-center justify-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {/* Overlay guide */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="border-2 border-white/60 rounded-xl w-4/5 h-3/5 flex items-center justify-center">
                    <p className="text-white/80 text-xs font-medium bg-black/40 px-3 py-1 rounded-full">
                      Align nutrition label here
                    </p>
                  </div>
                </div>
                {/* Flip camera button */}
                <button
                  onClick={flipCamera}
                  className="absolute top-3 right-3 bg-black/50 text-white rounded-full p-2 hover:bg-black/70 transition-colors"
                >
                  <FlipHorizontal className="w-4 h-4" />
                </button>
              </div>
            </Card>

            <div className="flex gap-3">
              <Button className="flex-1 h-12 text-base" onClick={capturePhoto} disabled={!cameraActive}>
                <Camera className="w-5 h-5 mr-2" />
                Capture Label
              </Button>
              <Button
                variant="outline"
                className="h-12 px-4"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            <p className="text-center text-xs text-muted-foreground">
              Tip: Make sure the label is well-lit and the text is clearly visible for best results
            </p>
          </div>
        )}

        {/* ── Step: Uploading / Analyzing ── */}
        {(step === "uploading" || step === "analyzing") && (
          <Card className="border-0 shadow-md">
            <CardContent className="py-12 flex flex-col items-center gap-6">
              {capturedImage && (
                <div className="w-48 h-36 rounded-xl overflow-hidden shadow-md">
                  <img src={capturedImage} alt="Captured label" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex flex-col items-center gap-3">
                <div className="relative">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                    {step === "uploading" ? (
                      <Upload className="w-6 h-6 text-primary" />
                    ) : (
                      <Sparkles className="w-6 h-6 text-primary" />
                    )}
                  </div>
                  <Loader2 className="absolute -top-1 -right-1 w-5 h-5 text-primary animate-spin" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground">
                    {step === "uploading" ? "Uploading image…" : "AI is reading the label…"}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {step === "uploading"
                      ? "Preparing your image for analysis"
                      : "Extracting nutritional facts — this takes 5–15 seconds"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* ── Step: Review ── */}
        {step === "review" && (
          <div className="space-y-4">
            {/* Captured image preview */}
            {capturedImage && (
              <Card className="border-0 shadow-sm overflow-hidden">
                <div className="flex items-center gap-3 p-3">
                  <div className="w-16 h-12 rounded-lg overflow-hidden shrink-0">
                    <img src={capturedImage} alt="Label" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                      <p className="text-sm font-medium">Label scanned successfully</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Review and edit the extracted data below before saving
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleRetake}>
                    <X className="w-4 h-4 mr-1" />
                    Retake
                  </Button>
                </div>
              </Card>
            )}

            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <ScanLine className="w-4 h-4 text-primary" />
                  Product Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2 space-y-1.5">
                    <Label htmlFor="name">Product Name *</Label>
                    <Input
                      id="name"
                      value={form.name}
                      onChange={e => setField("name", e.target.value)}
                      placeholder="e.g. Whole Grain Cereal"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="brand">Brand</Label>
                    <Input
                      id="brand"
                      value={form.brand}
                      onChange={e => setField("brand", e.target.value)}
                      placeholder="e.g. Kellogg's"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={form.category}
                      onChange={e => setField("category", e.target.value)}
                      placeholder="e.g. Cereals"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Nutri-Score</Label>
                    <Select
                      value={form.nutriScore}
                      onValueChange={v => setField("nutriScore", v as "A" | "B" | "C" | "D" | "E")}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {NUTRI_SCORES.map(s => (
                          <SelectItem key={s} value={s}>
                            {s} — {s === "A" ? "Excellent" : s === "B" ? "Good" : s === "C" ? "Average" : s === "D" ? "Poor" : "Bad"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>NOVA Group</Label>
                    <Select
                      value={String(form.novaGroup)}
                      onValueChange={v => setField("novaGroup", parseInt(v))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 — Unprocessed</SelectItem>
                        <SelectItem value="2">2 — Processed ingredients</SelectItem>
                        <SelectItem value="3">3 — Processed foods</SelectItem>
                        <SelectItem value="4">4 — Ultra-processed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Nutritional Values (per 100g)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: "calories", label: "Calories (kcal)" },
                    { key: "proteins", label: "Protein (g)" },
                    { key: "carbohydrates", label: "Carbohydrates (g)" },
                    { key: "sugars", label: "of which Sugars (g)" },
                    { key: "fat", label: "Fat (g)" },
                    { key: "saturatedFat", label: "Saturated Fat (g)" },
                    { key: "fiber", label: "Fibre (g)" },
                    { key: "salt", label: "Salt (g)" },
                  ].map(({ key, label }) => (
                    <div key={key} className="space-y-1.5">
                      <Label htmlFor={key} className="text-xs">{label}</Label>
                      <Input
                        id={key}
                        type="number"
                        min="0"
                        step="0.1"
                        value={form[key as keyof FormData] as string}
                        onChange={e => setField(key as keyof FormData, e.target.value)}
                        placeholder="0"
                        className="h-9"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Ingredients</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={form.ingredients}
                  onChange={e => setField("ingredients", e.target.value)}
                  placeholder="e.g. Whole grain oats, sugar, salt…"
                  rows={3}
                />
              </CardContent>
            </Card>

            <div className="flex gap-3 pb-6">
              <Button variant="outline" onClick={handleRetake} className="flex-1">
                <Camera className="w-4 h-4 mr-2" />
                Retake Photo
              </Button>
              <Button className="flex-1" onClick={handleSave}>
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Save Product
              </Button>
            </div>
          </div>
        )}

        {/* ── Step: Saving ── */}
        {step === "saving" && (
          <Card className="border-0 shadow-md">
            <CardContent className="py-12 flex flex-col items-center gap-4">
              <Loader2 className="w-10 h-10 text-primary animate-spin" />
              <p className="font-medium">Saving product…</p>
            </CardContent>
          </Card>
        )}

        {/* ── Step: Done ── */}
        {step === "done" && (
          <Card className="border-0 shadow-md">
            <CardContent className="py-12 flex flex-col items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7 text-green-600" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-lg">Product Saved!</p>
                <p className="text-sm text-muted-foreground mt-1">Redirecting to product page…</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
