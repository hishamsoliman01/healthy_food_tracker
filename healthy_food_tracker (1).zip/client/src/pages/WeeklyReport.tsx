import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { NutriScoreBadge } from "@/components/NutriScoreBadge";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, ReferenceLine,
} from "recharts";
import { BarChart2, TrendingUp, Award, Flame, Leaf } from "lucide-react";

export default function WeeklyReport() {
  const { data, isLoading } = trpc.report.weekly.useQuery();

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-40 bg-muted rounded-xl animate-pulse" />
          ))}
        </div>
      </DashboardLayout>
    );
  }

  if (!data) return null;

  const { days = [], avgCalories = 0, activeDays = 0, totalScores = {}, calorieTarget } = data;

  // Chart data
  const calorieChartData = days.map((d) => ({
    date: new Date(d.date).toLocaleDateString([], { weekday: "short" }),
    calories: d.calories,
    target: calorieTarget,
  }));

  const macroChartData = days.map((d) => ({
    date: new Date(d.date).toLocaleDateString([], { weekday: "short" }),
    protein: Math.round(d.protein),
    carbs: Math.round(d.carbs),
    fat: Math.round(d.fat),
  }));

  const nutriScoreData = Object.entries(totalScores as Record<string, number>)
    .filter(([, count]) => count > 0)
    .map(([score, count]) => ({ score, count }))
    .sort((a, b) => a.score.localeCompare(b.score));

  const scoreColors: Record<string, string> = {
    A: "#22c55e", B: "#84cc16", C: "#eab308", D: "#f97316", E: "#ef4444",
  };

  const avgCaloriePct = calorieTarget > 0 ? Math.round((avgCalories / calorieTarget) * 100) : 0;

  // Calculate avg macros from active days
  const activeDaysData = days.filter(d => d.items > 0);
  const avgProtein = activeDaysData.length > 0
    ? Math.round(activeDaysData.reduce((s, d) => s + d.protein, 0) / activeDaysData.length)
    : 0;
  const avgCarbs = activeDaysData.length > 0
    ? Math.round(activeDaysData.reduce((s, d) => s + d.carbs, 0) / activeDaysData.length)
    : 0;
  const avgFat = activeDaysData.length > 0
    ? Math.round(activeDaysData.reduce((s, d) => s + d.fat, 0) / activeDaysData.length)
    : 0;

  const topScore = nutriScoreData[0];

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <BarChart2 className="h-6 w-6 text-indigo-500" />
            Weekly Report
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Your nutrition summary for the past 7 days
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center gap-2 mb-1">
                <Flame className="h-4 w-4 text-orange-500" />
                <p className="text-xs text-muted-foreground">Avg Daily Calories</p>
              </div>
              <p className="text-2xl font-bold text-foreground">{avgCalories}</p>
              <p className={`text-xs mt-0.5 ${avgCaloriePct >= 90 && avgCaloriePct <= 110 ? "text-emerald-600" : "text-muted-foreground"}`}>
                {avgCaloriePct}% of {calorieTarget} kcal target
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="h-4 w-4 text-blue-500" />
                <p className="text-xs text-muted-foreground">Avg Protein</p>
              </div>
              <p className="text-2xl font-bold text-foreground">{avgProtein}g</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Carbs: {avgCarbs}g · Fat: {avgFat}g
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center gap-2 mb-1">
                <Award className="h-4 w-4 text-amber-500" />
                <p className="text-xs text-muted-foreground">Days Logged</p>
              </div>
              <p className="text-2xl font-bold text-foreground">{activeDays} / 7</p>
              <p className="text-xs text-muted-foreground mt-0.5">days with food logged</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center gap-2 mb-1">
                <Leaf className="h-4 w-4 text-emerald-500" />
                <p className="text-xs text-muted-foreground">Top Nutri-Score</p>
              </div>
              {topScore ? (
                <div className="flex items-center gap-2">
                  <NutriScoreBadge score={topScore.score as "A" | "B" | "C" | "D" | "E"} size="lg" />
                  <p className="text-xs text-muted-foreground">{topScore.count} items</p>
                </div>
              ) : (
                <p className="text-2xl font-bold text-muted-foreground">—</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Calorie Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Daily Calories vs Target</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={calorieChartData} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                <Tooltip
                  formatter={(v: number, name: string) => [
                    `${v} kcal`,
                    name === "calories" ? "Consumed" : "Target",
                  ]}
                  contentStyle={{ fontSize: 12, borderRadius: 8 }}
                />
                <ReferenceLine y={calorieTarget} stroke="#22c55e" strokeDasharray="4 4" strokeWidth={1.5} />
                <Bar dataKey="calories" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Macro Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Daily Macros (g)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={macroChartData} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="protein" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="carbs" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="fat" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Nutri-Score Distribution */}
        {nutriScoreData.length > 0 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-semibold">Nutri-Score Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-3 justify-center">
                {nutriScoreData.map(({ score, count }) => (
                  <div key={score} className="flex flex-col items-center gap-1">
                    <span className="text-xs font-medium text-muted-foreground">{count}</span>
                    <div
                      className="w-10 rounded-t-md transition-all"
                      style={{
                        height: `${Math.max(20, (count as number) * 16)}px`,
                        backgroundColor: scoreColors[score] ?? "#888",
                      }}
                    />
                    <NutriScoreBadge score={score as "A" | "B" | "C" | "D" | "E"} size="sm" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Empty state */}
        {activeDays === 0 && (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-12 text-center">
              <BarChart2 className="h-12 w-12 mx-auto mb-3 opacity-20 text-indigo-400" />
              <p className="text-base font-medium text-foreground mb-1">No data yet</p>
              <p className="text-sm text-muted-foreground">
                Start logging food this week to see your weekly nutrition report here.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
