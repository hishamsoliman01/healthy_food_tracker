import { useState, useMemo, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Trophy, Flame, Droplets, Footprints, Zap, Plus, Users, Medal,
  Crown, Target, Calendar, Bell
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

const CHALLENGE_TYPES = [
  { value: "streak", label: "Logging Streak", icon: Flame, color: "text-orange-500", unit: "days" },
  { value: "calories", label: "Calorie Goal", icon: Zap, color: "text-yellow-500", unit: "days on target" },
  { value: "water", label: "Water Intake", icon: Droplets, color: "text-blue-500", unit: "days hitting goal" },
  { value: "steps", label: "Step Count", icon: Footprints, color: "text-green-500", unit: "days active" },
] as const;

type ChallengeType = typeof CHALLENGE_TYPES[number]["value"];

function getRankIcon(rank: number) {
  if (rank === 0) return <Crown className="w-4 h-4 text-yellow-500" />;
  if (rank === 1) return <Medal className="w-4 h-4 text-gray-400" />;
  if (rank === 2) return <Medal className="w-4 h-4 text-amber-600" />;
  return <span className="text-xs text-muted-foreground font-bold">#{rank + 1}</span>;
}

function getDaysLeft(endDate: string): number {
  const end = new Date(endDate);
  const now = new Date();
  const diff = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, diff);
}

export default function Challenges() {
  const { user } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedChallenge, setSelectedChallenge] = useState<number | null>(null);
  const [nudgeOpen, setNudgeOpen] = useState(false);
  const [nudgeTarget, setNudgeTarget] = useState("");
  const [nudgeMsg, setNudgeMsg] = useState("");
  const [joinId, setJoinId] = useState("");

  // Create form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<ChallengeType>("streak");
  const [targetValue, setTargetValue] = useState("7");
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  });

  const { data: challenges = [], refetch } = trpc.challenges.list.useQuery();

  const joinMutation = trpc.challenges.join.useMutation({
    onSuccess: () => {
      toast.success("Joined challenge! You're now a participant.");
      setJoinId("");
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  // Auto-join from ?join= URL param
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const joinParam = params.get("join");
    if (joinParam) {
      const id = parseInt(joinParam, 10);
      if (!isNaN(id)) {
        joinMutation.mutate({ challengeId: id });
        // Remove param from URL without reload
        const url = new URL(window.location.href);
        url.searchParams.delete("join");
        window.history.replaceState({}, "", url.toString());
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { data: leaderboard = [] } = trpc.challenges.leaderboard.useQuery(
    { challengeId: selectedChallenge! },
    { enabled: selectedChallenge !== null }
  );

  const createMutation = trpc.challenges.create.useMutation({
    onSuccess: () => {
      toast.success("Challenge created! You've been auto-joined.");
      setCreateOpen(false);
      setTitle(""); setDescription(""); setTargetValue("7");
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const nudgeMutation = trpc.challenges.nudge.useMutation({
    onSuccess: () => { toast.success("Nudge sent! 💪"); setNudgeOpen(false); setNudgeMsg(""); },
    onError: (e) => toast.error(e.message),
  });

  const handleCreate = () => {
    if (!title.trim()) { toast.error("Enter a challenge title"); return; }
    createMutation.mutate({
      title,
      description: description || undefined,
      type,
      targetValue: parseInt(targetValue) || 7,
      startDate,
      endDate,
    });
  };

  const typeInfo = CHALLENGE_TYPES.find((t) => t.value === type)!;

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6 max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Trophy className="w-6 h-6 text-primary" />
              Challenges
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Compete with friends, build habits, and stay motivated
            </p>
          </div>
          <Button onClick={() => setCreateOpen(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            New Challenge
          </Button>
        </div>

        {/* Active challenges */}
        {challenges.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-12 text-center">
              <Trophy className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
              <p className="font-medium text-muted-foreground">No active challenges</p>
              <p className="text-sm text-muted-foreground/70 mt-1 mb-4">
                Create a challenge and invite your friends to compete!
              </p>
              <Button onClick={() => setCreateOpen(true)} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" />
                Create your first challenge
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {challenges.map((c) => {
              const typeData = CHALLENGE_TYPES.find((t) => t.value === c.type);
              const Icon = typeData?.icon ?? Trophy;
              const daysLeft = getDaysLeft(c.endDate);
              const isSelected = selectedChallenge === c.id;

              return (
                <Card
                  key={c.id}
                  className={`cursor-pointer transition-all ${isSelected ? "ring-2 ring-primary border-primary" : "hover:border-primary/40"}`}
                  onClick={() => setSelectedChallenge(isSelected ? null : c.id)}
                >
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0`}>
                          <Icon className={`w-5 h-5 ${typeData?.color ?? "text-primary"}`} />
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">{c.title}</h3>
                          {c.description && (
                            <p className="text-sm text-muted-foreground mt-0.5">{c.description}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 flex-wrap">
                            <Badge variant="secondary" className="text-xs gap-1">
                              <Target className="w-3 h-3" />
                              {c.targetValue} {typeData?.unit}
                            </Badge>
                            <Badge variant="secondary" className="text-xs gap-1">
                              <Calendar className="w-3 h-3" />
                              {daysLeft} days left
                            </Badge>
                            <Badge
                              className={`text-xs ${c.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}
                            >
                              {c.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Leaderboard (expanded) */}
                    {isSelected && (
                      <div className="mt-4 border-t pt-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-sm font-semibold flex items-center gap-1.5">
                            <Users className="w-4 h-4 text-primary" />
                            Leaderboard
                          </h4>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 gap-1.5 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              setNudgeTarget("");
                              setNudgeOpen(true);
                            }}
                          >
                            <Bell className="w-3 h-3" />
                            Nudge Friend
                          </Button>
                        </div>
                        {leaderboard.length === 0 ? (
                          <p className="text-sm text-muted-foreground text-center py-3">
                            No participants yet
                          </p>
                        ) : (
                          <div className="space-y-2">
                            {leaderboard.map((p, idx) => {
                              const isMe = p.userId === user?.id?.toString();
                              return (
                                <div
                                  key={p.id}
                                  className={`flex items-center justify-between rounded-lg px-3 py-2 ${isMe ? "bg-primary/10 border border-primary/20" : "bg-muted/40"}`}
                                >
                                  <div className="flex items-center gap-2.5">
                                    <div className="w-6 flex items-center justify-center">
                                      {getRankIcon(idx)}
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">
                                        {p.userName}
                                        {isMe && <span className="text-xs text-primary ml-1">(you)</span>}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1 font-bold text-sm">
                                    <Flame className="w-3.5 h-3.5 text-orange-500" />
                                    {p.currentScore}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Create Challenge Dialog */}
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" />
                Create a Challenge
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Challenge Title</Label>
                <Input
                  placeholder="e.g. 7-Day Logging Streak"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-1.5">
                <Label>Description (optional)</Label>
                <Textarea
                  placeholder="What's this challenge about?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Type</Label>
                  <Select value={type} onValueChange={(v) => setType(v as ChallengeType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CHALLENGE_TYPES.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Target ({typeInfo.unit})</Label>
                  <Input
                    type="number"
                    min={1}
                    value={targetValue}
                    onChange={(e) => setTargetValue(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Start Date</Label>
                  <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>End Date</Label>
                  <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-3 text-sm text-muted-foreground">
                💡 You'll be automatically added as the first participant. Share the challenge ID with friends so they can join!
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setCreateOpen(false)}>
                  Cancel
                </Button>
                <Button className="flex-1" onClick={handleCreate} disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create Challenge"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Nudge Dialog */}
        <Dialog open={nudgeOpen} onOpenChange={setNudgeOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-primary" />
                Send a Nudge
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Send a motivational message to encourage a friend in this challenge!
              </p>
              <div className="space-y-1.5">
                <Label>Message</Label>
                <Textarea
                  placeholder="You've got this! Keep going! 💪"
                  value={nudgeMsg}
                  onChange={(e) => setNudgeMsg(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setNudgeOpen(false)}>
                  Cancel
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => {
                    if (!nudgeMsg.trim()) { toast.error("Write a message first"); return; }
                    nudgeMutation.mutate({
                      challengeId: selectedChallenge!,
                      targetUserId: nudgeTarget || "all",
                      message: nudgeMsg,
                    });
                  }}
                  disabled={nudgeMutation.isPending}
                >
                  {nudgeMutation.isPending ? "Sending..." : "Send Nudge 💪"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
