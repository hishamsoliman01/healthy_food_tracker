import { useState } from "react";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  BadgeCheck,
  Camera,
  ChevronRight,
  Flame,
  Leaf,
  Lock,
  ScanSearch,
  Sparkles,
  Star,
  Trophy,
  Utensils,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";

const FREE_FEATURES = [
  { icon: Camera, text: "Barcode scanner (5 scans/day)" },
  { icon: Zap, text: "Manual food logging" },
  { icon: BadgeCheck, text: "Basic dashboard (calories + macros)" },
  { icon: Flame, text: "7-day history" },
];

const PRO_FEATURES = [
  { icon: ScanSearch, text: "Unlimited AI food photo scanning" },
  { icon: Sparkles, text: "Unlimited AI label reader" },
  { icon: BadgeCheck, text: "Full history + weekly reports" },
  { icon: Utensils, text: "Recipe Builder" },
  { icon: Zap, text: "Wearable Connect (Bluetooth HR)" },
  { icon: Star, text: "Advanced macro breakdowns" },
  { icon: Trophy, text: "Priority support" },
];

export default function Pricing() {
  const [annual, setAnnual] = useState(false);
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  const monthlyPrice = 9.99;
  const annualPrice = 79;
  const annualMonthly = (annualPrice / 12).toFixed(2);
  const saving = Math.round(100 - (annualPrice / (monthlyPrice * 12)) * 100);

  const handleCTA = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      window.location.href = getLoginUrl("/dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <button onClick={() => navigate("/")} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg text-foreground">NutriTrack</span>
          </button>
          <div className="flex items-center gap-2">
            {!loading && (
              isAuthenticated ? (
                <Button onClick={() => navigate("/dashboard")} size="sm">
                  Dashboard <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              ) : (
                <>
                  <Button variant="outline" size="sm" onClick={handleCTA} className="hidden sm:flex bg-transparent">Sign In</Button>
                  <Button size="sm" onClick={handleCTA}>Start Free →</Button>
                </>
              )
            )}
          </div>
        </div>
      </nav>

      <div className="pt-28 pb-24 px-4">
        <div className="container max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium mb-5 border border-primary/20">
              <Star className="w-4 h-4" />
              Simple, transparent pricing
            </div>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-foreground mb-4 tracking-tight">
              Choose your plan
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              Start free. Upgrade when you're ready for the full AI-powered experience.
            </p>

            {/* Billing toggle */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <span className={`text-sm font-medium ${!annual ? "text-foreground" : "text-muted-foreground"}`}>Monthly</span>
              <button
                onClick={() => setAnnual(!annual)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${annual ? "bg-primary" : "bg-muted-foreground/30"}`}
                aria-label="Toggle annual billing"
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${annual ? "translate-x-6" : "translate-x-1"}`} />
              </button>
              <span className={`text-sm font-medium ${annual ? "text-foreground" : "text-muted-foreground"}`}>
                Annual
                <span className="ml-1.5 inline-block bg-green-100 text-green-700 text-xs font-semibold px-2 py-0.5 rounded-full">
                  Save {saving}%
                </span>
              </span>
            </div>
          </div>

          {/* Pricing cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {/* Free */}
            <div className="bg-card rounded-2xl border border-border/60 p-8 flex flex-col">
              <div className="mb-6">
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60 mb-2">Free Plan</p>
                <div className="flex items-end gap-1">
                  <span className="text-4xl font-extrabold text-foreground">$0</span>
                  <span className="text-muted-foreground text-sm mb-1">/month</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">Everything you need to get started. No credit card required.</p>
              </div>
              <ul className="space-y-3 flex-1 mb-8">
                {FREE_FEATURES.map((f) => (
                  <li key={f.text} className="flex items-center gap-3 text-sm text-foreground">
                    <div className="w-5 h-5 rounded-full bg-muted flex items-center justify-center shrink-0">
                      <f.icon className="w-3 h-3 text-muted-foreground" />
                    </div>
                    {f.text}
                  </li>
                ))}
              </ul>
              <Button variant="outline" size="lg" onClick={handleCTA} className="w-full bg-transparent">
                Get Started Free
              </Button>
            </div>

            {/* Pro */}
            <div className="bg-primary rounded-2xl p-8 flex flex-col relative overflow-hidden shadow-xl shadow-primary/25">
              <div className="absolute top-4 right-4 bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                Most Popular
              </div>
              <div className="mb-6">
                <p className="text-xs font-semibold uppercase tracking-widest text-primary-foreground/70 mb-2">Pro Plan</p>
                <div className="flex items-end gap-1">
                  <span className="text-4xl font-extrabold text-primary-foreground">
                    ${annual ? annualMonthly : monthlyPrice}
                  </span>
                  <span className="text-primary-foreground/70 text-sm mb-1">/month</span>
                </div>
                {annual && (
                  <p className="text-sm text-primary-foreground/80 mt-1">
                    Billed annually at <strong className="text-primary-foreground">${annualPrice}/year</strong>
                  </p>
                )}
                <p className="text-sm text-primary-foreground/80 mt-2">
                  Unlock unlimited AI scanning, full history, and advanced analytics.
                </p>
              </div>
              <ul className="space-y-3 flex-1 mb-8">
                {PRO_FEATURES.map((f) => (
                  <li key={f.text} className="flex items-center gap-3 text-sm text-primary-foreground">
                    <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                      <f.icon className="w-3 h-3 text-primary-foreground" />
                    </div>
                    {f.text}
                  </li>
                ))}
              </ul>
              <Button
                size="lg"
                onClick={handleCTA}
                className="w-full bg-white text-primary hover:bg-white/90 font-semibold shadow-md"
              >
                Upgrade to Pro →
              </Button>
              <p className="text-center text-xs text-primary-foreground/60 mt-3 flex items-center justify-center gap-1">
                <Lock className="w-3 h-3" /> Secure checkout via Stripe
              </p>
            </div>
          </div>

          {/* Feature comparison note */}
          <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground">
              All plans include data security, GDPR compliance, and access to 3M+ food products via Open Food Facts.
            </p>
            <p className="text-xs text-muted-foreground/60 mt-2">
              Pro plan billing is handled securely by Stripe. Cancel anytime — no lock-in.
            </p>
          </div>

          {/* FAQ teaser */}
          <div className="mt-16 bg-muted/40 rounded-2xl border border-border/50 p-8 max-w-2xl mx-auto">
            <h3 className="font-bold text-foreground text-lg mb-4 text-center">Frequently Asked Questions</h3>
            <div className="space-y-4">
              {[
                { q: "Can I cancel anytime?", a: "Yes. Cancel your Pro subscription at any time from your account settings — no questions asked." },
                { q: "Is my data safe?", a: "Your health data is encrypted, never sold, and fully GDPR-compliant. You can export or delete it at any time." },
                { q: "What happens to my data if I downgrade?", a: "Your history is preserved. You'll just lose access to Pro features until you re-subscribe." },
              ].map((item) => (
                <div key={item.q} className="border-b border-border/40 pb-4 last:border-0 last:pb-0">
                  <p className="text-sm font-semibold text-foreground mb-1">{item.q}</p>
                  <p className="text-sm text-muted-foreground">{item.a}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Teams CTA */}
          <div className="mt-10 text-center">
            <p className="text-sm text-muted-foreground">
              Need NutriTrack for your whole team?{" "}
              <button onClick={() => navigate("/teams")} className="text-primary font-medium hover:underline">
                See Team & Enterprise pricing →
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
