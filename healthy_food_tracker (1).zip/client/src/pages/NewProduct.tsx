import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Loader2, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type NutriScore = "A" | "B" | "C" | "D" | "E";

export default function NewProduct() {
  const [, navigate] = useLocation();

  const [form, setForm] = useState({
    name: "",
    brand: "",
    category: "",
    barcode: "",
    nutriScore: "" as NutriScore | "",
    novaGroup: "" as string,
    ingredients: "",
    calories: "",
    fat: "",
    saturatedFat: "",
    carbohydrates: "",
    sugars: "",
    fiber: "",
    proteins: "",
    salt: "",
  });

  const createMutation = trpc.products.create.useMutation({
    onSuccess: (product) => {
      toast.success(`"${product?.name}" added to the database!`);
      navigate(`/products/${product?.id}`);
    },
    onError: (err) => {
      if (err.message.includes("barcode already exists")) {
        toast.error("A product with this barcode already exists.");
      } else {
        toast.error("Failed to create product. Please try again.");
      }
    },
  });

  const set = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error("Product name is required."); return; }

    createMutation.mutate({
      name: form.name.trim(),
      brand: form.brand || undefined,
      category: form.category || undefined,
      barcode: form.barcode || undefined,
      nutriScore: (form.nutriScore as NutriScore) || undefined,
      novaGroup: form.novaGroup ? Number(form.novaGroup) : undefined,
      ingredients: form.ingredients || undefined,
      calories: form.calories ? Number(form.calories) : undefined,
      fat: form.fat ? Number(form.fat) : undefined,
      saturatedFat: form.saturatedFat ? Number(form.saturatedFat) : undefined,
      carbohydrates: form.carbohydrates ? Number(form.carbohydrates) : undefined,
      sugars: form.sugars ? Number(form.sugars) : undefined,
      fiber: form.fiber ? Number(form.fiber) : undefined,
      proteins: form.proteins ? Number(form.proteins) : undefined,
      salt: form.salt ? Number(form.salt) : undefined,
    });
  };

  const numField = (label: string, field: keyof typeof form, unit = "g") => (
    <div>
      <Label htmlFor={field} className="text-sm font-medium">
        {label} <span className="text-muted-foreground font-normal">({unit})</span>
      </Label>
      <Input
        id={field}
        type="number"
        min="0"
        step="0.1"
        value={form[field]}
        onChange={set(field)}
        placeholder="0.0"
        className="mt-1"
      />
    </div>
  );

  return (
    <DashboardLayout>
      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1 as never)} className="gap-2 -ml-2">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Add New Product</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Manually enter product details for items not in our database.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Basic Info */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-sm font-medium">
                  Product Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={set("name")}
                  placeholder="e.g. Organic Greek Yogurt"
                  className="mt-1"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brand" className="text-sm font-medium">Brand</Label>
                  <Input id="brand" value={form.brand} onChange={set("brand")} placeholder="e.g. Danone" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="category" className="text-sm font-medium">Category</Label>
                  <Input id="category" value={form.category} onChange={set("category")} placeholder="e.g. Dairy" className="mt-1" />
                </div>
              </div>
              <div>
                <Label htmlFor="barcode" className="text-sm font-medium">Barcode (optional)</Label>
                <Input id="barcode" value={form.barcode} onChange={set("barcode")} placeholder="e.g. 1234567890123" className="mt-1 font-mono" />
              </div>
            </CardContent>
          </Card>

          {/* Health Classification */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Health Classification</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Nutri-Score</Label>
                  <Select
                    value={form.nutriScore}
                    onValueChange={(v) => setForm((p) => ({ ...p, nutriScore: v as NutriScore }))}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {(["A", "B", "C", "D", "E"] as const).map((s) => (
                        <SelectItem key={s} value={s}>
                          <span className={`inline-block w-5 h-5 rounded text-xs font-bold text-center leading-5 mr-2 nutri-${s.toLowerCase()}`}>{s}</span>
                          {s === "A" ? "Excellent" : s === "B" ? "Good" : s === "C" ? "Average" : s === "D" ? "Poor" : "Bad"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm font-medium">NOVA Group</Label>
                  <Select
                    value={form.novaGroup}
                    onValueChange={(v) => setForm((p) => ({ ...p, novaGroup: v }))}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 — Unprocessed</SelectItem>
                      <SelectItem value="2">2 — Processed ingredients</SelectItem>
                      <SelectItem value="3">3 — Processed food</SelectItem>
                      <SelectItem value="4">4 — Ultra-processed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="ingredients" className="text-sm font-medium">Ingredients</Label>
                <Textarea
                  id="ingredients"
                  value={form.ingredients}
                  onChange={set("ingredients")}
                  placeholder="List the ingredients…"
                  className="mt-1 resize-none"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Nutritional Info */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Nutritional Values <span className="text-muted-foreground font-normal text-sm">per 100g</span></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {numField("Calories", "calories", "kcal")}
                {numField("Fat", "fat")}
                {numField("Saturated Fat", "saturatedFat")}
                {numField("Carbohydrates", "carbohydrates")}
                {numField("Sugars", "sugars")}
                {numField("Fibre", "fiber")}
                {numField("Protein", "proteins")}
                {numField("Salt", "salt")}
              </div>
            </CardContent>
          </Card>

          <Button
            type="submit"
            className="w-full h-11"
            disabled={createMutation.isPending || !form.name.trim()}
          >
            {createMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Plus className="w-4 h-4 mr-2" />
            )}
            Add Product to Database
          </Button>
        </form>
      </div>
    </DashboardLayout>
  );
}
