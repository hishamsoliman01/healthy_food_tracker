import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { Apple, Camera, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { NutriScoreBadge } from "../components/NutriScoreBadge";
import { MacroSummary } from "../components/NutritionalInfo";

export default function History() {
  const [, navigate] = useLocation();
  const [days, setDays] = useState(7);

  const { data: logs, isLoading, refetch } = trpc.consumption.getHistory.useQuery({ days });
  const deleteMutation = trpc.consumption.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("Entry removed"); },
    onError: () => toast.error("Failed to remove entry"),
  });

  // Group logs by date
  const grouped = logs
    ? logs.reduce<Record<string, typeof logs>>((acc, entry) => {
        const date = new Date(entry.log.consumedAt).toLocaleDateString("en", {
          weekday: "long",
          month: "long",
          day: "numeric",
        });
        if (!acc[date]) acc[date] = [];
        acc[date]!.push(entry);
        return acc;
      }, {})
    : {};

  return (
    <DashboardLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Consumption History</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Your food log for the past {days} days.</p>
          </div>
          <div className="flex gap-2">
            {[7, 14, 30].map((d) => (
              <button
                key={d}
                onClick={() => setDays(d)}
                className={`px-3 py-1.5 text-xs rounded-lg font-medium transition-all ${
                  days === d
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                {d}d
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))}
          </div>
        ) : Object.keys(grouped).length === 0 ? (
          <div className="py-20 text-center">
            <Apple className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
            <p className="text-muted-foreground">No consumption logged in the past {days} days.</p>
            <Button variant="outline" size="sm" className="mt-4" onClick={() => navigate("/scan")}>
              <Camera className="w-4 h-4 mr-2" />
              Scan a product
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).map(([date, entries]) => {
              const totalCal = entries.reduce(
                (sum, { log, product }) => sum + (product.calories ?? 0) * log.quantity,
                0
              );
              return (
                <div key={date}>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-sm font-semibold text-foreground">{date}</h2>
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                      {Math.round(totalCal)} kcal total
                    </span>
                  </div>
                  <Card className="border-border/60">
                    <CardContent className="p-0">
                      {entries.map(({ log, product }, idx) => (
                        <div
                          key={log.id}
                          className={`flex items-center gap-3 p-4 group hover:bg-muted/30 transition-colors ${
                            idx < entries.length - 1 ? "border-b border-border/50" : ""
                          }`}
                        >
                          <NutriScoreBadge score={product.nutriScore} size="sm" />
                          <div
                            className="flex-1 min-w-0 cursor-pointer"
                            onClick={() => navigate(`/products/${product.id}`)}
                          >
                            <p className="text-sm font-medium text-foreground truncate">{product.name}</p>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="text-xs text-muted-foreground">
                                ×{log.quantity} · {new Date(log.consumedAt).toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" })}
                              </span>
                              <MacroSummary product={product} quantity={log.quantity} />
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                            onClick={() => deleteMutation.mutate({ logId: log.id })}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
