import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { NutriScoreBadge } from "@/components/NutriScoreBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Camera,
  ChefHat,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Flame,
  ImagePlus,
  Loader2,
  Plus,
  Search,
  Sparkles,
  Trash2,
  UtensilsCrossed,
  X,
  Zap,
} from "lucide-react";
import { useState, useRef, useCallback } from "react";

// ─── Recipe Detail Panel ──────────────────────────────────────────────────────
function RecipeDetailPanel({
  recipeId,
  onLog,
  onClose,
}: {
  recipeId: number;
  onLog: (id: number) => void;
  onClose: () => void;
}) {
  const { data, isLoading } = trpc.recipes.get.useQuery({ id: recipeId });

  if (isLoading) {
    return (
      <div className="py-6 flex items-center justify-center gap-2 text-muted-foreground text-sm">
        <Loader2 className="w-4 h-4 animate-spin" />Loading details…
      </div>
    );
  }
  if (!data) return null;

  const ns = data.nutriScore as "A" | "B" | "C" | "D" | "E";

  return (
    <div className="mt-3 pt-3 border-t border-border/50 space-y-3">
      {/* Macro summary */}
      <div className="grid grid-cols-4 gap-2">
        <div className="text-center bg-orange-50 dark:bg-orange-950/20 rounded-lg py-2">
          <p className="text-base font-bold text-orange-500">{Math.round(data.totalCalories ?? 0)}</p>
          <p className="text-[10px] text-muted-foreground">kcal</p>
        </div>
        <div className="text-center bg-blue-50 dark:bg-blue-950/20 rounded-lg py-2">
          <p className="text-base font-bold text-blue-600">{Math.round(data.totalProtein ?? 0)}g</p>
          <p className="text-[10px] text-muted-foreground">protein</p>
        </div>
        <div className="text-center bg-amber-50 dark:bg-amber-950/20 rounded-lg py-2">
          <p className="text-base font-bold text-amber-500">{Math.round(data.totalCarbs ?? 0)}g</p>
          <p className="text-[10px] text-muted-foreground">carbs</p>
        </div>
        <div className="text-center bg-yellow-50 dark:bg-yellow-950/20 rounded-lg py-2">
          <p className="text-base font-bold text-yellow-600">{Math.round(data.totalFat ?? 0)}g</p>
          <p className="text-[10px] text-muted-foreground">fat</p>
        </div>
      </div>

      {/* Ingredients list */}
      {data.ingredients && data.ingredients.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Ingredients</p>
          <div className="space-y-1">
            {data.ingredients.map((row) => {
              const p = row.product;
              const ing = row.ingredient;
              const cal = Math.round((p.calories ?? 0) * ing.amountGrams / 100);
              return (
                <div key={ing.id} className="flex items-center justify-between py-1.5 px-3 rounded-lg bg-muted/40 text-sm">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-medium text-foreground truncate">{p.name}</span>
                    {p.nutriScore && ["A","B","C","D","E"].includes(p.nutriScore) && (
                      <NutriScoreBadge score={p.nutriScore as "A"|"B"|"C"|"D"|"E"} size="sm" />
                    )}
                  </div>
                  <div className="flex items-center gap-3 shrink-0 text-xs text-muted-foreground">
                    <span>{ing.amountGrams}g</span>
                    <span className="font-medium text-foreground">{cal} kcal</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Nutri-Score + actions */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          {data.nutriScore && ["A","B","C","D","E"].includes(ns) && (
            <NutriScoreBadge score={ns} />
          )}
          <span className="text-xs text-muted-foreground">{data.servings} serving{data.servings !== 1 ? "s" : ""}</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="h-8 text-xs text-muted-foreground" onClick={onClose}>
            Collapse
          </Button>
          <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={() => onLog(recipeId)}>
            <Zap className="w-3 h-3" />Log This Recipe
          </Button>
        </div>
      </div>
    </div>
  );
}

type Ingredient = {
  productId: number;
  productName: string;
  amountGrams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
};

type AIIngredient = {
  name: string;
  estimatedGrams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  nutriScore: string;
};

type AIAnalysis = {
  recipeName: string;
  description: string;
  estimatedServings: number;
  ingredients: AIIngredient[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  nutriScore: string;
  confidence: number;
};

const MEAL_OPTIONS = [
  { value: "breakfast", label: "🌅 Breakfast" },
  { value: "lunch", label: "☀️ Lunch" },
  { value: "dinner", label: "🌙 Dinner" },
  { value: "snacks", label: "🍎 Snacks" },
];

export default function Recipes() {
  const [mode, setMode] = useState<"list" | "photo" | "manual" | "reviewing">("list");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  // Manual create state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [servings, setServings] = useState(1);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [logRecipeId, setLogRecipeId] = useState<number | null>(null);
  const [logMeal, setLogMeal] = useState<"breakfast" | "lunch" | "dinner" | "snacks">("lunch");

  // Photo AI state
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [uploadedUrl, setUploadedUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [editedAnalysis, setEditedAnalysis] = useState<AIAnalysis | null>(null);
  const [isSavingFromPhoto, setIsSavingFromPhoto] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const utils = trpc.useUtils();
  const { data: recipes, isLoading } = trpc.recipes.list.useQuery();
  const { data: searchResults, isLoading: searching } = trpc.products.search.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length >= 2 }
  );

  const createMutation = trpc.recipes.create.useMutation({
    onSuccess: () => {
      utils.recipes.list.invalidate();
      setMode("list");
      setName(""); setDescription(""); setServings(1); setIngredients([]);
      toast.success("Recipe created!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.recipes.delete.useMutation({
    onSuccess: () => { utils.recipes.list.invalidate(); toast.success("Recipe deleted"); },
    onError: (e) => toast.error(e.message),
  });

  const logMutation = trpc.recipes.log.useMutation({
    onSuccess: () => {
      toast.success("Recipe logged to your meal!");
      setLogRecipeId(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const analyzePhotoMutation = trpc.recipes.analyzePhoto.useMutation({
    onSuccess: (data) => {
      setEditedAnalysis(JSON.parse(JSON.stringify(data)));
      setIsAnalyzing(false);
      setMode("reviewing");
    },
    onError: (e) => {
      setIsAnalyzing(false);
      toast.error(`AI analysis failed: ${e.message}`);
    },
  });

  const saveFromPhotoMutation = trpc.recipes.saveFromPhoto.useMutation({
    onSuccess: () => {
      utils.recipes.list.invalidate();
      setMode("list");
      setPhotoPreview(null);
      setUploadedUrl(null);
      setEditedAnalysis(null);
      setIsSavingFromPhoto(false);
      toast.success("Recipe saved from photo!");
    },
    onError: (e) => {
      setIsSavingFromPhoto(false);
      toast.error(e.message);
    },
  });

  const addIngredient = useCallback((p: { id: number; name: string; calories: number | null; proteins: number | null; carbohydrates: number | null; fat: number | null }) => {
    if (ingredients.some(i => i.productId === p.id)) { toast.info("Already added"); return; }
    setIngredients(prev => [...prev, {
      productId: p.id, productName: p.name, amountGrams: 100,
      calories: p.calories ?? 0, protein: p.proteins ?? 0,
      carbs: p.carbohydrates ?? 0, fat: p.fat ?? 0,
    }]);
    setSearchQuery("");
  }, [ingredients]);

  const updateAmount = (productId: number, grams: number) =>
    setIngredients(prev => prev.map(i => i.productId === productId ? { ...i, amountGrams: grams } : i));

  const removeIngredient = (productId: number) =>
    setIngredients(prev => prev.filter(i => i.productId !== productId));

  const totalCalories = ingredients.reduce((s, i) => s + (i.calories * i.amountGrams / 100), 0);
  const totalProtein = ingredients.reduce((s, i) => s + (i.protein * i.amountGrams / 100), 0);
  const totalCarbs = ingredients.reduce((s, i) => s + (i.carbs * i.amountGrams / 100), 0);
  const totalFat = ingredients.reduce((s, i) => s + (i.fat * i.amountGrams / 100), 0);

  const handleCreate = () => {
    if (!name.trim()) { toast.error("Enter a recipe name"); return; }
    if (ingredients.length === 0) { toast.error("Add at least one ingredient"); return; }
    createMutation.mutate({
      name, description: description || undefined, servings,
      ingredients: ingredients.map(i => ({ productId: i.productId, amountGrams: i.amountGrams })),
    });
  };

  const handleFileSelected = async (file: File) => {
    if (!file.type.startsWith("image/")) { toast.error("Please select an image file"); return; }
    if (file.size > 10 * 1024 * 1024) { toast.error("Image must be under 10MB"); return; }
    const reader = new FileReader();
    reader.onload = (e) => setPhotoPreview(e.target?.result as string);
    reader.readAsDataURL(file);
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("image", file);
      const res = await fetch("/api/upload-label", { method: "POST", body: formData });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json() as { url: string };
      setUploadedUrl(url);
      setIsUploading(false);
      setIsAnalyzing(true);
      analyzePhotoMutation.mutate({ imageUrl: url });
    } catch {
      setIsUploading(false);
      toast.error("Upload failed. Please try again.");
    }
  };

  const handleSaveFromPhoto = () => {
    if (!editedAnalysis) return;
    setIsSavingFromPhoto(true);
    saveFromPhotoMutation.mutate({
      name: editedAnalysis.recipeName,
      description: editedAnalysis.description || undefined,
      servings: editedAnalysis.estimatedServings || 1,
      totalCalories: editedAnalysis.totalCalories,
      totalProtein: editedAnalysis.totalProtein,
      totalCarbs: editedAnalysis.totalCarbs,
      totalFat: editedAnalysis.totalFat,
      totalFiber: editedAnalysis.totalFiber,
      nutriScore: (["A","B","C","D","E"].includes(editedAnalysis.nutriScore) ? editedAnalysis.nutriScore : "C") as "A"|"B"|"C"|"D"|"E",
      ingredients: editedAnalysis.ingredients,
    });
  };

  const updateAIIngredientGrams = (idx: number, grams: number) => {
    if (!editedAnalysis) return;
    const updated = { ...editedAnalysis, ingredients: [...editedAnalysis.ingredients] };
    const ing = { ...updated.ingredients[idx] };
    const factor = grams / (ing.estimatedGrams || 1);
    ing.estimatedGrams = grams;
    ing.calories = Math.round(ing.calories * factor);
    ing.protein = Math.round(ing.protein * factor * 10) / 10;
    ing.carbs = Math.round(ing.carbs * factor * 10) / 10;
    ing.fat = Math.round(ing.fat * factor * 10) / 10;
    ing.fiber = Math.round(ing.fiber * factor * 10) / 10;
    updated.ingredients[idx] = ing;
    updated.totalCalories = updated.ingredients.reduce((s, i) => s + i.calories, 0);
    updated.totalProtein = Math.round(updated.ingredients.reduce((s, i) => s + i.protein, 0) * 10) / 10;
    updated.totalCarbs = Math.round(updated.ingredients.reduce((s, i) => s + i.carbs, 0) * 10) / 10;
    updated.totalFat = Math.round(updated.ingredients.reduce((s, i) => s + i.fat, 0) * 10) / 10;
    setEditedAnalysis(updated);
  };

  const removeAIIngredient = (idx: number) => {
    if (!editedAnalysis) return;
    const updated = { ...editedAnalysis, ingredients: editedAnalysis.ingredients.filter((_, i) => i !== idx) };
    updated.totalCalories = updated.ingredients.reduce((s, i) => s + i.calories, 0);
    updated.totalProtein = Math.round(updated.ingredients.reduce((s, i) => s + i.protein, 0) * 10) / 10;
    updated.totalCarbs = Math.round(updated.ingredients.reduce((s, i) => s + i.carbs, 0) * 10) / 10;
    updated.totalFat = Math.round(updated.ingredients.reduce((s, i) => s + i.fat, 0) * 10) / 10;
    setEditedAnalysis(updated);
  };

  // ─── Photo mode ───────────────────────────────────────────────────────────
  if (mode === "photo") {
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto space-y-6 p-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => { setMode("list"); setPhotoPreview(null); setUploadedUrl(null); }} className="-ml-2">← Back</Button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2"><Sparkles className="w-5 h-5 text-primary" />AI Recipe from Photo</h1>
              <p className="text-sm text-muted-foreground">Take or upload a photo — AI identifies ingredients & calculates calories</p>
            </div>
          </div>

          {!photoPreview && (
            <Card className="border-2 border-dashed border-primary/30 hover:border-primary/60 transition-colors">
              <CardContent className="py-12 flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Camera className="w-8 h-8 text-primary" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground">Photograph your meal</p>
                  <p className="text-sm text-muted-foreground mt-1">AI will identify every ingredient and calculate calories automatically</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs">
                  <Button className="flex-1 gap-2" onClick={() => cameraInputRef.current?.click()}>
                    <Camera className="w-4 h-4" />Take Photo
                  </Button>
                  <Button variant="outline" className="flex-1 gap-2" onClick={() => fileInputRef.current?.click()}>
                    <ImagePlus className="w-4 h-4" />Upload Image
                  </Button>
                </div>
                <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFileSelected(e.target.files[0])} />
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFileSelected(e.target.files[0])} />
              </CardContent>
            </Card>
          )}

          {photoPreview && (
            <Card className="overflow-hidden">
              <div className="relative">
                <img src={photoPreview} alt="Meal photo" className="w-full max-h-72 object-cover" />
                {(isUploading || isAnalyzing) && (
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-3">
                    <div className="w-14 h-14 rounded-full bg-white/10 border-2 border-white/30 flex items-center justify-center">
                      <Loader2 className="w-7 h-7 text-white animate-spin" />
                    </div>
                    <p className="text-white font-semibold text-sm">
                      {isUploading ? "Uploading photo…" : "AI is analyzing your meal…"}
                    </p>
                    {isAnalyzing && (
                      <p className="text-white/70 text-xs text-center px-8">
                        Identifying ingredients, estimating portions, calculating nutrition…
                      </p>
                    )}
                  </div>
                )}
              </div>
              {!isUploading && !isAnalyzing && !editedAnalysis && (
                <CardContent className="pt-4 pb-4 flex gap-2">
                  <Button className="flex-1 gap-2" onClick={() => { if (uploadedUrl) { setIsAnalyzing(true); analyzePhotoMutation.mutate({ imageUrl: uploadedUrl }); } }} disabled={!uploadedUrl}>
                    <Sparkles className="w-4 h-4" />Analyze with AI
                  </Button>
                  <Button variant="outline" onClick={() => { setPhotoPreview(null); setUploadedUrl(null); }}>Retake</Button>
                </CardContent>
              )}
            </Card>
          )}
        </div>
      </DashboardLayout>
    );
  }

  // ─── AI Review mode ───────────────────────────────────────────────────────
  if (mode === "reviewing" && editedAnalysis) {
    const ns = editedAnalysis.nutriScore as "A"|"B"|"C"|"D"|"E";
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setMode("photo")} className="-ml-2">← Back</Button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />AI Analysis Complete
              </h1>
              <p className="text-sm text-muted-foreground">
                Review and adjust before saving
                {editedAnalysis.confidence > 0 && (
                  <span className="ml-2 text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                    {Math.round(editedAnalysis.confidence * 100)}% confidence
                  </span>
                )}
              </p>
            </div>
          </div>

          {photoPreview && (
            <div className="flex gap-4 items-start">
              <img src={photoPreview} alt="Meal" className="w-24 h-24 rounded-xl object-cover shrink-0 shadow-sm" />
              <div className="flex-1 space-y-2">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Recipe Name</Label>
                  <Input value={editedAnalysis.recipeName} onChange={(e) => setEditedAnalysis({ ...editedAnalysis, recipeName: e.target.value })} className="font-semibold" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Description</Label>
                  <Input value={editedAnalysis.description} onChange={(e) => setEditedAnalysis({ ...editedAnalysis, description: e.target.value })} className="text-sm" />
                </div>
              </div>
            </div>
          )}

          <Card className="bg-gradient-to-br from-emerald-50 to-green-50 dark:from-emerald-950/20 dark:to-green-950/20 border-emerald-200 dark:border-emerald-800">
            <CardContent className="pt-4 pb-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-3xl font-bold text-emerald-700 dark:text-emerald-300">{Math.round(editedAnalysis.totalCalories)} kcal</p>
                  <p className="text-xs text-muted-foreground">Total for {editedAnalysis.estimatedServings} serving(s)</p>
                </div>
                {["A","B","C","D","E"].includes(ns) && <NutriScoreBadge score={ns} />}
              </div>
              <div className="grid grid-cols-3 gap-3 mt-2">
                <div className="text-center"><p className="text-lg font-bold text-blue-600">{Math.round(editedAnalysis.totalProtein)}g</p><p className="text-xs text-muted-foreground">Protein</p></div>
                <div className="text-center"><p className="text-lg font-bold text-orange-500">{Math.round(editedAnalysis.totalCarbs)}g</p><p className="text-xs text-muted-foreground">Carbs</p></div>
                <div className="text-center"><p className="text-lg font-bold text-yellow-600">{Math.round(editedAnalysis.totalFat)}g</p><p className="text-xs text-muted-foreground">Fat</p></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <ChefHat className="w-4 h-4 text-primary" />Identified Ingredients ({editedAnalysis.ingredients.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {editedAnalysis.ingredients.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No ingredients identified. Try a clearer photo.</p>
              ) : (
                editedAnalysis.ingredients.map((ing, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-muted/40 border border-border/50">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold text-foreground">{ing.name}</p>
                        {["A","B","C","D","E"].includes(ing.nutriScore) && (
                          <NutriScoreBadge score={ing.nutriScore as "A"|"B"|"C"|"D"|"E"} size="sm" />
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                        <span className="font-medium text-foreground">{ing.calories} kcal</span>
                        <span>P: {ing.protein}g</span>
                        <span>C: {ing.carbs}g</span>
                        <span>F: {ing.fat}g</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Input type="number" min={1} max={2000} value={ing.estimatedGrams}
                        onChange={(e) => updateAIIngredientGrams(idx, Math.max(1, parseInt(e.target.value) || 1))}
                        className="w-20 h-8 text-sm text-center" />
                      <span className="text-xs text-muted-foreground">g</span>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => removeAIIngredient(idx)}>
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <div className="flex items-center gap-3">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Servings</Label>
              <Input type="number" min={1} max={20} value={editedAnalysis.estimatedServings}
                onChange={(e) => setEditedAnalysis({ ...editedAnalysis, estimatedServings: Math.max(1, parseInt(e.target.value) || 1) })}
                className="w-24" />
            </div>
          </div>

          <div className="flex gap-3">
            <Button className="flex-1 gap-2" onClick={handleSaveFromPhoto} disabled={isSavingFromPhoto || editedAnalysis.ingredients.length === 0}>
              {isSavingFromPhoto ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChefHat className="w-4 h-4" />}
              {isSavingFromPhoto ? "Saving…" : "Save Recipe"}
            </Button>
            <Button variant="outline" onClick={() => { setMode("photo"); setEditedAnalysis(null); }}>Retake Photo</Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // ─── Manual create mode ───────────────────────────────────────────────────
  if (mode === "manual") {
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto space-y-5 p-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setMode("list")} className="-ml-2">← Back</Button>
            <h1 className="text-xl font-bold flex items-center gap-2"><ChefHat className="w-5 h-5 text-primary" />Build Recipe Manually</h1>
          </div>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1.5">
                <Label>Recipe Name *</Label>
                <Input placeholder="e.g. Chicken Stir Fry" value={name} onChange={e => setName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Servings</Label>
                <Input type="number" min={1} max={50} value={servings} onChange={e => setServings(Math.max(1, parseInt(e.target.value) || 1))} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description (optional)</Label>
              <Textarea placeholder="Brief description…" value={description} onChange={e => setDescription(e.target.value)} rows={2} />
            </div>
            <div className="space-y-2">
              <Label>Add Ingredients</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input className="pl-9" placeholder="Search foods to add…" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
              </div>
              {searchQuery.length >= 2 && (
                <div className="border rounded-xl overflow-hidden shadow-sm">
                  {searching ? (
                    <div className="flex items-center gap-2 p-3 text-sm text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin" /> Searching…</div>
                  ) : searchResults && searchResults.length > 0 ? (
                    <div className="divide-y max-h-48 overflow-y-auto">
                      {searchResults.slice(0, 8).map(p => (
                        <button key={p.id} onClick={() => addIngredient(p)} className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-accent text-left transition-colors">
                          <div>
                            <p className="text-sm font-medium text-foreground">{p.name}</p>
                            <p className="text-xs text-muted-foreground">{p.brand || p.category}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">{p.calories} kcal/100g</span>
                            {p.nutriScore && <NutriScoreBadge score={p.nutriScore as "A"|"B"|"C"|"D"|"E"} size="sm" />}
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="p-3 text-sm text-muted-foreground">No results. Try adding the product first via Add Product.</div>
                  )}
                </div>
              )}
            </div>
            {ingredients.length > 0 && (
              <div className="space-y-2">
                <Label>Ingredients ({ingredients.length})</Label>
                <div className="space-y-2">
                  {ingredients.map(ing => (
                    <div key={ing.productId} className="flex items-center gap-3 bg-muted/40 rounded-xl px-3 py-2.5">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{ing.productName}</p>
                        <p className="text-xs text-muted-foreground">{Math.round(ing.calories * ing.amountGrams / 100)} kcal</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input type="number" min={1} max={5000} value={ing.amountGrams}
                          onChange={e => updateAmount(ing.productId, Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-20 h-8 text-sm text-center" />
                        <span className="text-xs text-muted-foreground">g</span>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => removeIngredient(ing.productId)}>
                          <X className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <Card className="bg-muted/30">
                  <CardContent className="pt-3 pb-3">
                    <p className="text-xs font-semibold text-muted-foreground mb-2">TOTAL NUTRITION</p>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-2xl font-bold text-foreground">{Math.round(totalCalories)} kcal</span>
                      <span className="text-xs text-muted-foreground">for {servings} serving(s)</span>
                    </div>
                    <div className="flex gap-4 text-xs mt-2">
                      <span className="text-blue-600 font-medium">P: {Math.round(totalProtein)}g</span>
                      <span className="text-orange-500 font-medium">C: {Math.round(totalCarbs)}g</span>
                      <span className="text-yellow-600 font-medium">F: {Math.round(totalFat)}g</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setMode("list")}>Cancel</Button>
              <Button className="flex-1 gap-2" onClick={handleCreate} disabled={createMutation.isPending || !name.trim() || ingredients.length === 0}>
                {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                {createMutation.isPending ? "Saving…" : "Save Recipe"}
              </Button>
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  // ─── Recipe list ──────────────────────────────────────────────────────────
  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto space-y-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <ChefHat className="w-6 h-6 text-primary" />Recipes
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Build recipes manually or let AI analyze a photo</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setMode("manual")} variant="outline" className="gap-2 hidden sm:flex">
              <Plus className="w-4 h-4" />Manual
            </Button>
            <Button onClick={() => setMode("photo")} className="gap-2">
              <Sparkles className="w-4 h-4" />AI Photo
            </Button>
          </div>
        </div>

        <Card className="bg-gradient-to-r from-primary/10 via-emerald-50 to-green-50 dark:from-primary/10 dark:via-emerald-950/20 dark:to-green-950/20 border-primary/20">
          <CardContent className="pt-4 pb-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center shrink-0">
              <Camera className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-foreground">Snap a photo → get instant nutrition</p>
              <p className="text-sm text-muted-foreground mt-0.5">AI identifies every ingredient and calculates calories automatically</p>
            </div>
            <Button onClick={() => setMode("photo")} size="sm" className="shrink-0 gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />Try it
            </Button>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-24 bg-muted rounded-2xl animate-pulse" />)}</div>
        ) : !recipes?.length ? (
          <Card className="border-dashed">
            <CardContent className="py-14 text-center">
              <UtensilsCrossed className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
              <p className="font-medium text-muted-foreground">No recipes yet</p>
              <p className="text-sm text-muted-foreground/70 mt-1 mb-5">Take a photo of your meal and AI will build the recipe for you</p>
              <div className="flex flex-col sm:flex-row gap-2 justify-center">
                <Button onClick={() => setMode("photo")} className="gap-2"><Camera className="w-4 h-4" />Analyze a Photo</Button>
                <Button onClick={() => setMode("manual")} variant="outline" className="gap-2"><Plus className="w-4 h-4" />Build Manually</Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {recipes.map(r => {
              const ns = r.nutriScore as "A"|"B"|"C"|"D"|"E";
              const isExpanded = expandedId === r.id;
              return (
                <Card
                  key={r.id}
                  className={`transition-all duration-200 ${isExpanded ? "shadow-md ring-1 ring-primary/20" : "hover:shadow-md"}`}
                >
                  <CardContent className="pt-4 pb-4">
                    {/* Clickable header row */}
                    <button
                      className="w-full text-left"
                      onClick={() => setExpandedId(isExpanded ? null : r.id)}
                      aria-expanded={isExpanded}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold text-foreground">{r.name}</h3>
                            {r.nutriScore && ["A","B","C","D","E"].includes(ns) && <NutriScoreBadge score={ns} size="sm" />}
                            <Badge variant="secondary" className="text-xs">{r.servings} serving{r.servings !== 1 ? "s" : ""}</Badge>
                          </div>
                          {r.description && <p className="text-sm text-muted-foreground mt-0.5 truncate">{r.description}</p>}
                          <div className="flex items-center gap-4 mt-2 flex-wrap">
                            <span className="flex items-center gap-1 text-sm font-semibold text-orange-500"><Flame className="w-3.5 h-3.5" />{r.totalCalories ?? 0} kcal</span>
                            <span className="text-xs text-muted-foreground">P: {r.totalProtein ?? 0}g</span>
                            <span className="text-xs text-muted-foreground">C: {r.totalCarbs ?? 0}g</span>
                            <span className="text-xs text-muted-foreground">F: {r.totalFat ?? 0}g</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs"
                            onClick={(e) => { e.stopPropagation(); setLogRecipeId(r.id); }}>
                            <Zap className="w-3 h-3" />Log
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={(e) => { e.stopPropagation(); deleteMutation.mutate({ id: r.id }); }}
                            disabled={deleteMutation.isPending}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                          <div className="h-8 w-8 flex items-center justify-center text-muted-foreground">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </div>
                        </div>
                      </div>
                    </button>

                    {/* Expanded detail panel */}
                    {isExpanded && (
                      <RecipeDetailPanel
                        recipeId={r.id}
                        onLog={(id) => setLogRecipeId(id)}
                        onClose={() => setExpandedId(null)}
                      />
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <Dialog open={logRecipeId !== null} onOpenChange={(o) => !o && setLogRecipeId(null)}>
          <DialogContent className="max-w-sm">
            <DialogHeader><DialogTitle className="flex items-center gap-2"><Zap className="w-5 h-5 text-primary" />Log Recipe</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Which meal are you logging this to?</p>
              <Select value={logMeal} onValueChange={(v) => setLogMeal(v as typeof logMeal)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{MEAL_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setLogRecipeId(null)}>Cancel</Button>
                <Button className="flex-1" disabled={logMutation.isPending}
                  onClick={() => { if (logRecipeId !== null) logMutation.mutate({ recipeId: logRecipeId, mealType: logMeal }); }}>
                  {logMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Log to Meal"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
