import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Barcode, Loader2, Plus, Tag } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation, useParams } from "wouter";
import { NutriScoreBadge, NutriScoreScale } from "../components/NutriScoreBadge";
import { NutritionalInfo } from "../components/NutritionalInfo";

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const productId = Number(params.id);
  const [qty, setQty] = useState(1);

  const { data: product, isLoading, error } = trpc.products.getById.useQuery(
    { id: productId },
    { enabled: !isNaN(productId) }
  );

  const addMutation = trpc.consumption.add.useMutation({
    onSuccess: () => toast.success(`${product?.name} added to today's log!`),
    onError: () => toast.error("Failed to add to log"),
  });

  if (isNaN(productId)) {
    return (
      <DashboardLayout>
        <div className="p-6 text-center text-muted-foreground">Invalid product ID.</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Back button */}
        <Button variant="ghost" size="sm" onClick={() => navigate(-1 as never)} className="gap-2 -ml-2">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-48 rounded-xl" />
          </div>
        ) : error ? (
          <Card className="border-border/60">
            <CardContent className="p-6 text-center text-muted-foreground">
              Product not found.
            </CardContent>
          </Card>
        ) : product ? (
          <>
            {/* Product Header */}
            <Card className="border-border/60">
              <CardContent className="p-6">
                <div className="flex items-start gap-5">
                  <NutriScoreBadge score={product.nutriScore} size="xl" />
                  <div className="flex-1 min-w-0">
                    <h1 className="text-2xl font-bold text-foreground leading-tight">{product.name}</h1>
                    {product.brand && (
                      <p className="text-muted-foreground mt-0.5">{product.brand}</p>
                    )}
                    <div className="flex flex-wrap gap-2 mt-2">
                      {product.category && (
                        <span className="inline-flex items-center gap-1 text-xs bg-accent text-accent-foreground px-2.5 py-1 rounded-full">
                          <Tag className="w-3 h-3" />
                          {product.category}
                        </span>
                      )}
                      {product.barcode && (
                        <span className="inline-flex items-center gap-1 text-xs bg-muted text-muted-foreground px-2.5 py-1 rounded-full font-mono">
                          <Barcode className="w-3 h-3" />
                          {product.barcode}
                        </span>
                      )}
                      {product.novaGroup && (
                        <span className="inline-flex items-center gap-1 text-xs bg-muted text-muted-foreground px-2.5 py-1 rounded-full">
                          NOVA {product.novaGroup}
                        </span>
                      )}
                    </div>
                    <div className="mt-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-2">Nutri-Score</p>
                      <NutriScoreScale activeScore={product.nutriScore} />
                    </div>
                  </div>
                </div>

                {product.ingredients && (
                  <div className="mt-5 pt-5 border-t border-border/50">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Ingredients</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{product.ingredients}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Nutritional Info */}
            <NutritionalInfo product={product} />

            {/* Add to Log */}
            <Card className="border-border/60">
              <CardContent className="p-5">
                <p className="text-sm font-semibold text-foreground mb-3">Add to Today's Log</p>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                    >
                      −
                    </Button>
                    <span className="w-8 text-center font-semibold text-foreground">{qty}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setQty((q) => Math.min(99, q + 1))}
                    >
                      +
                    </Button>
                  </div>
                  <Button
                    className="flex-1"
                    onClick={() => addMutation.mutate({ productId: product.id, quantity: qty })}
                    disabled={addMutation.isPending}
                  >
                    {addMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Plus className="w-4 h-4 mr-2" />
                    )}
                    Add {qty > 1 ? `×${qty}` : ""} to Log
                  </Button>
                </div>
                {product.calories != null && (
                  <p className="text-xs text-muted-foreground mt-2">
                    ≈ {Math.round(product.calories * qty)} kcal total
                  </p>
                )}
              </CardContent>
            </Card>
          </>
        ) : null}
      </div>
    </DashboardLayout>
  );
}
