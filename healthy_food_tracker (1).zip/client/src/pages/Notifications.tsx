import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Bell,
  CheckCircle2,
  Mail,
  MessageSquare,
  Moon,
  Save,
  Smartphone,
  Sun,
  Zap,
} from "lucide-react";
import { useState } from "react";

type NotificationChannel = {
  emailEnabled: boolean;
  emailAddress: string;
  smsEnabled: boolean;
  phoneNumber: string;
  pushEnabled: boolean;
};

type NotificationTrigger = {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  email: boolean;
  sms: boolean;
  push: boolean;
};

export default function Notifications() {
  const [saved, setSaved] = useState(false);
  const [channels, setChannels] = useState<NotificationChannel>({
    emailEnabled: false,
    emailAddress: "",
    smsEnabled: false,
    phoneNumber: "",
    pushEnabled: true,
  });

  const [triggers, setTriggers] = useState<NotificationTrigger[]>([
    {
      id: "daily_reminder",
      label: "Daily Logging Reminder",
      description: "Remind me to log my meals each day",
      icon: <Sun className="w-4 h-4 text-amber-500" />,
      email: false,
      sms: false,
      push: true,
    },
    {
      id: "calorie_goal",
      label: "Calorie Goal Reached",
      description: "Notify when I hit my daily calorie target",
      icon: <Zap className="w-4 h-4 text-primary" />,
      email: true,
      sms: false,
      push: true,
    },
    {
      id: "streak_milestone",
      label: "Streak Milestones",
      description: "Celebrate 7, 30, 100-day logging streaks",
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
      email: true,
      sms: true,
      push: true,
    },
    {
      id: "weekly_report",
      label: "Weekly Nutrition Report",
      description: "Receive your weekly summary every Monday",
      icon: <Mail className="w-4 h-4 text-blue-500" />,
      email: true,
      sms: false,
      push: false,
    },
    {
      id: "bedtime_summary",
      label: "Bedtime Summary",
      description: "Evening recap of today's nutrition at 9 PM",
      icon: <Moon className="w-4 h-4 text-indigo-500" />,
      email: false,
      sms: false,
      push: true,
    },
  ]);

  const updateTrigger = (id: string, channel: "email" | "sms" | "push", value: boolean) => {
    setTriggers(prev => prev.map(t => t.id === id ? { ...t, [channel]: value } : t));
  };

  const handleSave = () => {
    if (channels.emailEnabled && !channels.emailAddress.includes("@")) {
      toast.error("Please enter a valid email address");
      return;
    }
    if (channels.smsEnabled && channels.phoneNumber.length < 8) {
      toast.error("Please enter a valid phone number");
      return;
    }
    // In a real app, this would call a tRPC mutation to save preferences
    setSaved(true);
    toast.success("Notification preferences saved!");
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Bell className="w-6 h-6 text-primary" />
            Notification Settings
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Choose how and when NutriTrack keeps you on track.
          </p>
        </div>

        {/* Channels */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Notification Channels</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Email */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center">
                    <Mail className="w-4 h-4 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-foreground">Email</p>
                    <p className="text-xs text-muted-foreground">Receive reports and reminders by email</p>
                  </div>
                </div>
                <Switch
                  checked={channels.emailEnabled}
                  onCheckedChange={v => setChannels(c => ({ ...c, emailEnabled: v }))}
                />
              </div>
              {channels.emailEnabled && (
                <div className="ml-12 space-y-1.5">
                  <Label className="text-xs">Email Address</Label>
                  <Input
                    type="email"
                    placeholder="you@example.com"
                    value={channels.emailAddress}
                    onChange={e => setChannels(c => ({ ...c, emailAddress: e.target.value }))}
                    className="h-9 text-sm"
                  />
                </div>
              )}
            </div>

            <Separator />

            {/* SMS */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-green-50 flex items-center justify-center">
                    <MessageSquare className="w-4 h-4 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-foreground">SMS</p>
                    <p className="text-xs text-muted-foreground">Get text messages for important alerts</p>
                  </div>
                </div>
                <Switch
                  checked={channels.smsEnabled}
                  onCheckedChange={v => setChannels(c => ({ ...c, smsEnabled: v }))}
                />
              </div>
              {channels.smsEnabled && (
                <div className="ml-12 space-y-1.5">
                  <Label className="text-xs">Mobile Number (with country code)</Label>
                  <Input
                    type="tel"
                    placeholder="+1 555 000 0000"
                    value={channels.phoneNumber}
                    onChange={e => setChannels(c => ({ ...c, phoneNumber: e.target.value }))}
                    className="h-9 text-sm"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Include country code, e.g. +44 for UK, +1 for US, +20 for Egypt
                  </p>
                </div>
              )}
            </div>

            <Separator />

            {/* Push */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-50 flex items-center justify-center">
                  <Smartphone className="w-4 h-4 text-purple-500" />
                </div>
                <div>
                  <p className="font-medium text-sm text-foreground">Push Notifications</p>
                  <p className="text-xs text-muted-foreground">In-app and browser push alerts</p>
                </div>
              </div>
              <Switch
                checked={channels.pushEnabled}
                onCheckedChange={v => setChannels(c => ({ ...c, pushEnabled: v }))}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notification Triggers */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">What to Notify Me About</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {triggers.map((trigger, idx) => (
              <div key={trigger.id}>
                {idx > 0 && <Separator className="mb-4" />}
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center mt-0.5 shrink-0">
                      {trigger.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm text-foreground">{trigger.label}</p>
                      <p className="text-xs text-muted-foreground">{trigger.description}</p>
                    </div>
                  </div>
                  <div className="ml-11 flex items-center gap-4 flex-wrap">
                    {[
                      { key: "email" as const, label: "Email", enabled: channels.emailEnabled },
                      { key: "sms" as const, label: "SMS", enabled: channels.smsEnabled },
                      { key: "push" as const, label: "Push", enabled: channels.pushEnabled },
                    ].map(ch => (
                      <label key={ch.key} className={`flex items-center gap-1.5 cursor-pointer ${!ch.enabled ? "opacity-40" : ""}`}>
                        <Switch
                          checked={trigger[ch.key] && ch.enabled}
                          onCheckedChange={v => updateTrigger(trigger.id, ch.key, v)}
                          disabled={!ch.enabled}
                          className="scale-75"
                        />
                        <span className="text-xs text-muted-foreground">{ch.label}</span>
                        {!ch.enabled && (
                          <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">Off</Badge>
                        )}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Save */}
        <Button onClick={handleSave} className="w-full h-11 gap-2">
          {saved ? (
            <><CheckCircle2 className="w-4 h-4" /> Saved!</>
          ) : (
            <><Save className="w-4 h-4" /> Save Preferences</>
          )}
        </Button>
      </div>
    </DashboardLayout>
  );
}
