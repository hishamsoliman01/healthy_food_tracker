import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { BrowserMultiFormatReader } from "@zxing/library";
import { AlertCircle, Apple, Camera, CameraOff, CheckCircle2, Coffee, Globe, Keyboard, Loader2, Moon, Plus, RotateCcw, Search, Sparkles, Sun } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation, useSearch } from "wouter";
import { NutriScoreBadge, NutriScoreScale } from "../components/NutriScoreBadge";
import { NutritionalInfo } from "../components/NutritionalInfo";
import type { Product } from "../../../drizzle/schema";

type ScanMode = "camera" | "manual";
type MealType = "breakfast" | "lunch" | "dinner" | "snacks";

const MEAL_OPTIONS: { value: MealType; label: string; icon: React.ElementType; color: string }[] = [
  { value: "breakfast", label: "Breakfast", icon: Coffee, color: "text-amber-500" },
  { value: "lunch",     label: "Lunch",     icon: Sun,    color: "text-orange-500" },
  { value: "dinner",    label: "Dinner",    icon: Moon,   color: "text-indigo-500" },
  { value: "snacks",    label: "Snacks",    icon: Apple,  color: "text-green-600" },
];

export default function Scanner() {
  const [, navigate] = useLocation();
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const initialMeal = (params.get("meal") as MealType) ?? "snacks";

  const [mode, setMode] = useState<ScanMode>("camera");
  const [selectedMeal, setSelectedMeal] = useState<MealType>(initialMeal);
  const [manualBarcode, setManualBarcode] = useState("");
  const [scanning, setScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scannedProduct, setScannedProduct] = useState<Product | null>(null);
  const [scanSource, setScanSource] = useState<"local" | "open_food_facts" | "none" | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [lastBarcode, setLastBarcode] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);

  const scanMutation = trpc.products.scan.useMutation();
  const addMutation = trpc.consumption.add.useMutation({
    onSuccess: () => {
      toast.success(`${scannedProduct?.name} added to ${selectedMeal}!`);
    },
    onError: () => toast.error("Failed to add to log"),
  });

  const handleScan = useCallback(async (barcode: string) => {
    if (barcode === lastBarcode) return;
    setLastBarcode(barcode);
    setNotFound(false);
    setScannedProduct(null);

    try {
      const result = await scanMutation.mutateAsync({ barcode });
      if (result.found && result.product) {
        setScannedProduct(result.product);
        setScanSource(result.source);
        // Stop camera after successful scan
        stopCamera();
      } else {
        setScanSource("none");
        setNotFound(true);
      }
    } catch {
      toast.error("Failed to look up product");
    }
  }, [lastBarcode]);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    setScanning(true);
    setScannedProduct(null);
    setNotFound(false);
    setLastBarcode(null);

    // Check if mediaDevices API is available (requires HTTPS or localhost)
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError("Camera not available. This feature requires a secure (HTTPS) connection. Use manual entry below.");
      setScanning(false);
      return;
    }

    try {
      const reader = new BrowserMultiFormatReader();
      readerRef.current = reader;

      const devices = await reader.listVideoInputDevices();
      if (devices.length === 0) {
        setCameraError("No camera found on this device. Use manual entry below.");
        setScanning(false);
        return;
      }

      // Prefer back camera
      const backCamera = devices.find((d: MediaDeviceInfo) => d.label.toLowerCase().includes("back") || d.label.toLowerCase().includes("rear")) ?? devices[0];

      await reader.decodeFromVideoDevice(backCamera?.deviceId ?? null, videoRef.current!, (result) => {
        if (result) {
          handleScan(result.getText());
        }
      });
    } catch (err: unknown) {
      const name = (err as { name?: string })?.name ?? "";
      const msg = err instanceof Error ? err.message : "";
      if (name === "NotAllowedError" || name === "PermissionDeniedError" || msg.includes("Permission") || msg.includes("NotAllowed")) {
        setCameraError("Camera permission denied. Please allow camera access in your browser settings, then try again.");
      } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
        setCameraError("No camera found on this device. Use manual entry below.");
      } else if (name === "NotReadableError" || name === "TrackStartError") {
        setCameraError("Camera is in use by another app. Close other apps using the camera and try again.");
      } else {
        setCameraError("Could not start camera. Use manual entry below.");
      }
      setScanning(false);
    }
  }, [handleScan]);

  const stopCamera = useCallback(() => {
    readerRef.current?.reset();
    readerRef.current = null;
    setScanning(false);
  }, []);

  useEffect(() => {
    if (mode === "camera") {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [mode]);

  // Android Chrome fix: force video play when the element is in the DOM and scanning is active
  useEffect(() => {
    if (scanning && videoRef.current) {
      const video = videoRef.current;
      // Ensure autoplay attributes are set imperatively (Android Chrome sometimes ignores JSX props)
      video.setAttribute("autoplay", "");
      video.setAttribute("playsinline", "");
      video.setAttribute("muted", "");
      if (video.paused) {
        video.play().catch(() => {});
      }
    }
  }, [scanning]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualBarcode.trim()) {
      handleScan(manualBarcode.trim());
    }
  };

  const handleReset = () => {
    setScannedProduct(null);
    setNotFound(false);
    setLastBarcode(null);
    setManualBarcode("");
    if (mode === "camera") {
      startCamera();
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Scan Product</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Scan a barcode or enter it manually to look up nutritional information.
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex gap-2 p-1 bg-muted rounded-xl w-fit">
          <button
            onClick={() => setMode("camera")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              mode === "camera" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Camera className="w-4 h-4" />
            Camera
          </button>
          <button
            onClick={() => setMode("manual")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              mode === "manual" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Keyboard className="w-4 h-4" />
            Manual
          </button>
        </div>

        {/* Camera View */}
        {mode === "camera" && !scannedProduct && !notFound && (
          <Card className="border-border/60 overflow-hidden">
            <CardContent className="p-0">
              {cameraError ? (
                <div className="h-64 flex flex-col items-center justify-center gap-3 bg-muted/30 p-6 text-center">
                  <CameraOff className="w-10 h-10 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">{cameraError}</p>
                  <Button variant="outline" size="sm" onClick={() => setMode("manual")}>
                    <Keyboard className="w-4 h-4 mr-2" />
                    Switch to Manual Entry
                  </Button>
                </div>
              ) : (
                <div className="relative">
                  <video
                    ref={videoRef}
                    className="w-full h-72 object-cover bg-black"
                    autoPlay
                    playsInline
                    muted
                  />
                  {/* Scan overlay */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-56 h-32 border-2 border-primary rounded-lg relative">
                      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary rounded-tl" />
                      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary rounded-tr" />
                      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary rounded-bl" />
                      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary rounded-br" />
                      {scanning && (
                        <div className="absolute top-0 left-0 right-0 h-0.5 bg-primary animate-[scanline_2s_ease-in-out_infinite]" />
                      )}
                    </div>
                  </div>
                  {scanning && (
                    <div className="absolute bottom-3 left-0 right-0 flex justify-center">
                      <div className="bg-black/60 text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-2">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Scanning…
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Manual Entry */}
        {mode === "manual" && !scannedProduct && !notFound && (
          <Card className="border-border/60">
            <CardContent className="p-6">
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">
                    Barcode Number
                  </label>
                  <div className="flex gap-2">
                    <Input
                      value={manualBarcode}
                      onChange={(e) => setManualBarcode(e.target.value)}
                      placeholder="e.g. 3017620422003"
                      className="font-mono"
                      autoFocus
                    />
                    <Button type="submit" disabled={!manualBarcode.trim() || scanMutation.isPending}>
                      {scanMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Try: 3017620422003 (Nutella), 5449000000996 (Coca-Cola), 3228857000166 (Oat Flakes)
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Loading */}
        {scanMutation.isPending && (
          <div className="flex items-center justify-center gap-3 py-8 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Looking up product…</span>
          </div>
        )}

        {/* Not Found */}
        {notFound && !scanMutation.isPending && (
          <Card className="border-border/60">
            <CardContent className="p-6 text-center">
              <AlertCircle className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="font-medium text-foreground mb-1">Product Not Found</p>
              <p className="text-sm text-muted-foreground mb-4">
                Barcode <span className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">{lastBarcode}</span> is not in our database.
              </p>
              <div className="flex gap-2 justify-center flex-wrap">
                <Button variant="outline" size="sm" onClick={handleReset}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button size="sm" variant="outline" onClick={() => navigate("/scan/label")}>
                  <Sparkles className="w-4 h-4 mr-2 text-primary" />
                  Scan Nutrition Label
                </Button>
                <Button size="sm" onClick={() => navigate("/products/new")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Manually
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Product Result */}
        {scannedProduct && !scanMutation.isPending && (
          <div className="space-y-4">
            {/* Success banner */}
            <div className="flex items-center gap-2 text-sm text-primary bg-primary/10 px-4 py-2.5 rounded-xl">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              Product found!
              {scanSource === "open_food_facts" && (
                <span className="ml-auto flex items-center gap-1 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">
                  <Globe className="w-3 h-3" />
                  Open Food Facts
                </span>
              )}
            </div>

            {/* Product card */}
            <Card className="border-border/60">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <NutriScoreBadge score={scannedProduct.nutriScore} size="xl" />
                  <div className="flex-1 min-w-0">
                    <h2 className="text-xl font-bold text-foreground">{scannedProduct.name}</h2>
                    {scannedProduct.brand && (
                      <p className="text-muted-foreground text-sm">{scannedProduct.brand}</p>
                    )}
                    {scannedProduct.category && (
                      <span className="inline-block mt-1 text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
                        {scannedProduct.category}
                      </span>
                    )}
                    <div className="mt-3">
                      <NutriScoreScale activeScore={scannedProduct.nutriScore} />
                    </div>
                  </div>
                </div>

                {scannedProduct.ingredients && (
                  <div className="mt-4 pt-4 border-t border-border/50">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Ingredients</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{scannedProduct.ingredients}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <NutritionalInfo product={scannedProduct} />

            {/* Meal Type Selector */}
            <div className="space-y-2">
              <p className="text-sm font-medium text-foreground">Add to which meal?</p>
              <div className="grid grid-cols-4 gap-2">
                {MEAL_OPTIONS.map(({ value, label, icon: Icon, color }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setSelectedMeal(value)}
                    className={`flex flex-col items-center gap-1 py-2.5 px-2 rounded-xl border text-xs font-medium transition-all ${
                      selectedMeal === value
                        ? "bg-primary/10 border-primary text-foreground"
                        : "bg-background border-border hover:border-primary/40 text-muted-foreground"
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${selectedMeal === value ? color : ""}`} />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                className="flex-1"
                onClick={() => {
                  addMutation.mutate({ productId: scannedProduct.id, quantity: 1, mealType: selectedMeal });
                }}
                disabled={addMutation.isPending}
              >
                {addMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4 mr-2" />
                )}
                Add to {MEAL_OPTIONS.find(m => m.value === selectedMeal)?.label ?? "Log"}
              </Button>
              <Button variant="outline" onClick={handleReset}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Scan Another
              </Button>
            </div>

            <Button
              variant="ghost"
              className="w-full text-sm"
              onClick={() => navigate(`/products/${scannedProduct.id}`)}
            >
              View Full Product Details
            </Button>
          </div>
        )}
      </div>

      <style>{`
        @keyframes scanline {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(calc(8rem - 2px)); }
        }
      `}</style>
    </DashboardLayout>
  );
}
