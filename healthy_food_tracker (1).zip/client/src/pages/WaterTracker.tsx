import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Bell, BellOff, Droplets, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useState, useEffect } from "react";

const QUICK_AMOUNTS = [150, 250, 350, 500];

// ─── Reminder helpers ─────────────────────────────────────────────────────────
const REMINDER_KEY = "water_reminder";

type ReminderConfig = {
  enabled: boolean;
  intervalHours: number;
  startTime: string; // "HH:MM"
  endTime: string;   // "HH:MM"
};

function loadReminder(): ReminderConfig | null {
  try {
    const raw = localStorage.getItem(REMINDER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveReminder(cfg: ReminderConfig) {
  localStorage.setItem(REMINDER_KEY, JSON.stringify(cfg));
}

function clearReminder() {
  localStorage.removeItem(REMINDER_KEY);
}

export default function WaterTracker() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.water.getToday.useQuery();

  const addMutation = trpc.water.add.useMutation({
    onSuccess: () => utils.water.getToday.invalidate(),
    onError: () => toast.error("Failed to log water"),
  });

  const deleteMutation = trpc.water.delete.useMutation({
    onSuccess: () => utils.water.getToday.invalidate(),
    onError: () => toast.error("Failed to remove entry"),
  });

  const totalMl = data?.totalMl ?? 0;
  const goalMl = data?.goalMl ?? 2000;
  const progressPct = Math.min(100, Math.round((totalMl / goalMl) * 100));
  const glasses = Math.round(totalMl / 250);
  const goalGlasses = Math.round(goalMl / 250);

  // ─── Reminder state ─────────────────────────────────────────────────────────
  const [reminder, setReminder] = useState<ReminderConfig | null>(null);
  const [showReminderDialog, setShowReminderDialog] = useState(false);
  const [draftInterval, setDraftInterval] = useState(2);
  const [draftStart, setDraftStart] = useState("08:00");
  const [draftEnd, setDraftEnd] = useState("22:00");
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>("default");

  useEffect(() => {
    const saved = loadReminder();
    if (saved) setReminder(saved);
    if ("Notification" in window) setNotifPermission(Notification.permission);
  }, []);

  const requestNotifPermission = async (): Promise<boolean> => {
    if (!("Notification" in window)) {
      toast.error("Your browser does not support notifications");
      return false;
    }
    if (Notification.permission === "granted") return true;
    const perm = await Notification.requestPermission();
    setNotifPermission(perm);
    if (perm !== "granted") {
      toast.error("Notification permission denied. Please allow notifications in your browser settings.");
      return false;
    }
    return true;
  };

  const handleSaveReminder = async () => {
    const granted = await requestNotifPermission();
    if (!granted) return;
    const cfg: ReminderConfig = {
      enabled: true,
      intervalHours: draftInterval,
      startTime: draftStart,
      endTime: draftEnd,
    };
    saveReminder(cfg);
    setReminder(cfg);
    setShowReminderDialog(false);
    toast.success(`Reminder set every ${draftInterval}h between ${draftStart} and ${draftEnd}`);
    // Fire a test notification immediately
    new Notification("💧 Water Reminder", {
      body: `Time to drink water! Your goal: ${goalMl >= 1000 ? `${(goalMl / 1000).toFixed(1)}L` : `${goalMl}ml`} today.`,
      icon: "/favicon.ico",
    });
  };

  const handleDisableReminder = () => {
    clearReminder();
    setReminder(null);
    toast.success("Reminder disabled");
  };

  const openReminderDialog = () => {
    if (reminder) {
      setDraftInterval(reminder.intervalHours);
      setDraftStart(reminder.startTime);
      setDraftEnd(reminder.endTime);
    }
    setShowReminderDialog(true);
  };

  const getProgressColor = () => {
    if (progressPct >= 100) return "text-emerald-600";
    if (progressPct >= 60) return "text-blue-500";
    return "text-orange-400";
  };

  const reminderActive = reminder?.enabled === true;

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Droplets className="h-6 w-6 text-blue-500" />
              Water Tracker
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Stay hydrated — aim for {goalMl >= 1000 ? `${(goalMl / 1000).toFixed(1)}L` : `${goalMl}ml`} per day
            </p>
          </div>
          {/* Reminder bell button */}
          <Button
            variant={reminderActive ? "default" : "outline"}
            size="sm"
            className={`gap-2 shrink-0 ${reminderActive ? "bg-blue-500 hover:bg-blue-600 text-white border-blue-500" : "border-blue-200 text-blue-600 hover:bg-blue-50"}`}
            onClick={openReminderDialog}
            title={reminderActive ? `Reminder: every ${reminder!.intervalHours}h` : "Set water reminder"}
          >
            {reminderActive ? (
              <>
                <Bell className="h-4 w-4 fill-current" />
                <span className="hidden sm:inline">Every {reminder!.intervalHours}h</span>
              </>
            ) : (
              <>
                <Bell className="h-4 w-4" />
                <span className="hidden sm:inline">Set Reminder</span>
              </>
            )}
            {reminderActive && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-background" />
            )}
          </Button>
        </div>

        {/* Active reminder banner */}
        {reminderActive && (
          <div className="flex items-center justify-between px-4 py-3 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800">
            <div className="flex items-center gap-3">
              <Bell className="h-4 w-4 text-blue-500 fill-blue-200" />
              <div>
                <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
                  Reminder active — every {reminder!.intervalHours}h
                </p>
                <p className="text-xs text-muted-foreground">
                  Between {reminder!.startTime} and {reminder!.endTime}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:bg-blue-100" onClick={openReminderDialog}>
                Edit
              </Button>
              <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground hover:text-destructive" onClick={handleDisableReminder}>
                <BellOff className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}

        {/* Progress Ring Card */}
        <Card className="border-0 shadow-md bg-gradient-to-br from-blue-50 to-sky-50 dark:from-blue-950/30 dark:to-sky-950/30">
          <CardContent className="pt-6 pb-6">
            <div className="flex items-center gap-6">
              {/* Circle */}
              <div className="relative w-28 h-28 shrink-0">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="8" className="text-blue-100 dark:text-blue-900" />
                  <circle
                    cx="50" cy="50" r="42" fill="none"
                    stroke="currentColor" strokeWidth="8"
                    strokeLinecap="round"
                    className="text-blue-500 transition-all duration-700"
                    strokeDasharray={`${2 * Math.PI * 42}`}
                    strokeDashoffset={`${2 * Math.PI * 42 * (1 - progressPct / 100)}`}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-2xl font-bold ${getProgressColor()}`}>{progressPct}%</span>
                  <span className="text-xs text-muted-foreground">of goal</span>
                </div>
              </div>

              {/* Stats */}
              <div className="flex-1 space-y-3">
                <div>
                  <p className="text-3xl font-bold text-blue-600">
                    {totalMl >= 1000 ? `${(totalMl / 1000).toFixed(2)}L` : `${totalMl}ml`}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    of {goalMl >= 1000 ? `${(goalMl / 1000).toFixed(1)}L` : `${goalMl}ml`} goal
                  </p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Droplets className="h-4 w-4 text-blue-400" />
                  <span>{glasses} / {goalGlasses} glasses (250ml each)</span>
                </div>
                {progressPct >= 100 && (
                  <div className="text-sm font-medium text-emerald-600 flex items-center gap-1">
                    🎉 Daily goal reached!
                  </div>
                )}
                {progressPct < 100 && (
                  <p className="text-xs text-muted-foreground">
                    {goalMl - totalMl}ml remaining
                  </p>
                )}
              </div>
            </div>

            <Progress value={progressPct} className="mt-4 h-2 bg-blue-100" />
          </CardContent>
        </Card>

        {/* Quick Add Buttons */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold">Quick Add</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-2">
              {QUICK_AMOUNTS.map((ml) => (
                <Button
                  key={ml}
                  variant="outline"
                  className="flex flex-col h-16 gap-0.5 border-blue-200 hover:bg-blue-50 hover:border-blue-400"
                  onClick={() => {
                    addMutation.mutate({ amountMl: ml });
                    toast.success(`+${ml}ml logged`);
                  }}
                  disabled={addMutation.isPending}
                >
                  <Plus className="h-3.5 w-3.5 text-blue-500" />
                  <span className="text-sm font-semibold text-blue-600">{ml}ml</span>
                  <span className="text-xs text-muted-foreground">
                    {ml === 150 ? "Small" : ml === 250 ? "Glass" : ml === 350 ? "Large" : "Bottle"}
                  </span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Today's Log */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold">Today's Log</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-10 bg-muted rounded animate-pulse" />
                ))}
              </div>
            ) : !data?.logs?.length ? (
              <div className="text-center py-8 text-muted-foreground">
                <Droplets className="h-10 w-10 mx-auto mb-2 opacity-30 text-blue-400" />
                <p className="text-sm">No water logged yet today.</p>
                <p className="text-xs mt-1">Tap a quick-add button above to get started.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {[...(data.logs)].reverse().map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900"
                  >
                    <div className="flex items-center gap-3">
                      <Droplets className="h-4 w-4 text-blue-500" />
                      <div>
                        <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
                          {log.amountMl}ml
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(log.loggedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      onClick={() => deleteMutation.mutate({ id: log.id })}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Hydration Tips */}
        <Card className="border-0 shadow-sm bg-gradient-to-br from-sky-50 to-blue-50 dark:from-sky-950/20 dark:to-blue-950/20">
          <CardContent className="pt-4 pb-4">
            <p className="text-sm font-semibold text-blue-700 dark:text-blue-300 mb-2">💡 Hydration Tips</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Drink a glass of water first thing in the morning</li>
              <li>• Keep a water bottle visible at your desk</li>
              <li>• Drink a glass before each meal to aid digestion</li>
              <li>• Increase intake during exercise or hot weather</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Reminder Dialog */}
      <Dialog open={showReminderDialog} onOpenChange={setShowReminderDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-500" />
              Water Reminder
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Set a browser notification to remind you to drink water throughout the day.
            </p>

            {notifPermission === "denied" && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-xs text-destructive">
                Notifications are blocked. Please allow notifications in your browser settings and reload the page.
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="text-sm">Remind me every</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  min={1}
                  max={8}
                  value={draftInterval}
                  onChange={(e) => setDraftInterval(Math.max(1, Math.min(8, parseInt(e.target.value) || 1)))}
                  className="w-20 text-center"
                />
                <span className="text-sm text-muted-foreground">hour(s)</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm">Start time</Label>
                <Input type="time" value={draftStart} onChange={(e) => setDraftStart(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm">End time</Label>
                <Input type="time" value={draftEnd} onChange={(e) => setDraftEnd(e.target.value)} />
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              A test notification will fire immediately when you save. Keep this tab open for reminders to work — browser notifications require an active tab.
            </p>

            <div className="flex gap-2">
              {reminderActive && (
                <Button variant="outline" className="flex-1 gap-2 text-destructive hover:text-destructive" onClick={() => { handleDisableReminder(); setShowReminderDialog(false); }}>
                  <BellOff className="w-4 h-4" />Disable
                </Button>
              )}
              <Button
                className="flex-1 gap-2"
                onClick={handleSaveReminder}
                disabled={notifPermission === "denied"}
              >
                <Bell className="w-4 h-4" />
                {reminderActive ? "Update Reminder" : "Enable Reminder"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
