import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Flame, Trophy, Calendar, Star, Zap, Target, Award } from "lucide-react";

const BADGES = [
  { id: "first_log", icon: "🥗", title: "First Bite", desc: "Log your first food", threshold: 1, field: "totalLogDays" as const },
  { id: "week_streak", icon: "🔥", title: "Week Warrior", desc: "7-day logging streak", threshold: 7, field: "currentStreak" as const },
  { id: "month_streak", icon: "💪", title: "Iron Will", desc: "30-day logging streak", threshold: 30, field: "currentStreak" as const },
  { id: "10_days", icon: "⭐", title: "10 Days Strong", desc: "Log food for 10 total days", threshold: 10, field: "totalLogDays" as const },
  { id: "30_days", icon: "🏅", title: "Consistent", desc: "Log food for 30 total days", threshold: 30, field: "totalLogDays" as const },
  { id: "100_days", icon: "🏆", title: "Century Club", desc: "Log food for 100 total days", threshold: 100, field: "totalLogDays" as const },
];

export default function Streaks() {
  const { data: streak, isLoading } = trpc.streak.get.useQuery();

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="max-w-2xl mx-auto space-y-4">
          {[1, 2, 3].map(i => <div key={i} className="h-32 bg-muted rounded-xl animate-pulse" />)}
        </div>
      </DashboardLayout>
    );
  }

  const current = streak?.currentStreak ?? 0;
  const longest = streak?.longestStreak ?? 0;
  const total = streak?.totalLogDays ?? 0;

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Flame className="h-6 w-6 text-orange-500" />
            Streaks & Achievements
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Stay consistent — every day you log counts
          </p>
        </div>

        {/* Current Streak Hero */}
        <Card className="border-0 shadow-md bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/30 dark:to-amber-950/30">
          <CardContent className="pt-6 pb-6 text-center">
            <div className="text-6xl mb-2">🔥</div>
            <p className="text-5xl font-black text-orange-500">{current}</p>
            <p className="text-sm font-semibold text-orange-700 dark:text-orange-300 mt-1">
              {current === 1 ? "day streak" : "day streak"}
            </p>
            {current === 0 && (
              <p className="text-xs text-muted-foreground mt-2">
                Log food today to start your streak!
              </p>
            )}
            {current > 0 && (
              <p className="text-xs text-muted-foreground mt-2">
                Keep it up — log food today to continue!
              </p>
            )}
          </CardContent>
        </Card>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <Zap className="h-5 w-5 mx-auto mb-1 text-amber-500" />
              <p className="text-xl font-bold text-foreground">{current}</p>
              <p className="text-xs text-muted-foreground">Current streak</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <Trophy className="h-5 w-5 mx-auto mb-1 text-yellow-500" />
              <p className="text-xl font-bold text-foreground">{longest}</p>
              <p className="text-xs text-muted-foreground">Best streak</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm text-center">
            <CardContent className="pt-4 pb-4">
              <Calendar className="h-5 w-5 mx-auto mb-1 text-blue-500" />
              <p className="text-xl font-bold text-foreground">{total}</p>
              <p className="text-xs text-muted-foreground">Total days</p>
            </CardContent>
          </Card>
        </div>

        {/* Next Milestone */}
        {(() => {
          const nextMilestone = [7, 14, 30, 60, 100, 200, 365].find(m => m > current);
          if (!nextMilestone) return null;
          const pct = Math.round((current / nextMilestone) * 100);
          return (
            <Card className="border-0 shadow-sm">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-center gap-3 mb-3">
                  <Target className="h-5 w-5 text-indigo-500" />
                  <div>
                    <p className="text-sm font-semibold">Next milestone: {nextMilestone}-day streak</p>
                    <p className="text-xs text-muted-foreground">{nextMilestone - current} more days to go</p>
                  </div>
                  <span className="ml-auto text-sm font-bold text-indigo-500">{pct}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-indigo-500 h-2 rounded-full transition-all duration-700"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </CardContent>
            </Card>
          );
        })()}

        {/* Badges */}
        <div>
          <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
            <Award className="h-4 w-4 text-amber-500" />
            Badges
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {BADGES.map((badge) => {
              const value = badge.field === "currentStreak" ? current : total;
              const earned = value >= badge.threshold;
              return (
                <Card
                  key={badge.id}
                  className={`border-0 shadow-sm transition-all ${earned ? "bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-950/30 dark:to-yellow-950/30" : "opacity-50 grayscale"}`}
                >
                  <CardContent className="pt-4 pb-4 flex items-center gap-3">
                    <span className="text-3xl">{badge.icon}</span>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{badge.title}</p>
                      <p className="text-xs text-muted-foreground">{badge.desc}</p>
                      {!earned && (
                        <p className="text-xs text-indigo-500 mt-0.5">
                          {badge.threshold - value} more to unlock
                        </p>
                      )}
                      {earned && (
                        <p className="text-xs text-amber-600 mt-0.5 font-medium">✓ Earned!</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Motivation */}
        <Card className="border-0 shadow-sm bg-gradient-to-br from-emerald-50 to-green-50 dark:from-emerald-950/20 dark:to-green-950/20">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-4 w-4 text-emerald-600" />
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">Why streaks matter</p>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Research shows that consistent food tracking — even for just 3 weeks — leads to significantly better dietary choices and awareness. Users who log for 7+ consecutive days are 3x more likely to reach their nutrition goals.
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
