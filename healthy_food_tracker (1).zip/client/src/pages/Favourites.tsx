import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Heart, Plus, Search, Trash2, Zap } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { NutriScoreBadge } from "@/components/NutriScoreBadge";

const MEAL_OPTIONS = [
  { value: "breakfast", label: "🌅 Breakfast" },
  { value: "lunch", label: "☀️ Lunch" },
  { value: "dinner", label: "🌙 Dinner" },
  { value: "snacks", label: "🍎 Snacks" },
];

export default function Favourites() {
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const [selectedMeal, setSelectedMeal] = useState<"breakfast" | "lunch" | "dinner" | "snacks">("lunch");

  const { data: favourites = [], isLoading } = trpc.favourites.list.useQuery();

  const removeMutation = trpc.favourites.remove.useMutation({
    onSuccess: () => {
      utils.favourites.list.invalidate();
      toast.success("Removed from favourites");
    },
  });

  const quickLogMutation = trpc.favourites.quickLog.useMutation({
    onSuccess: () => {
      utils.dashboard.stats.invalidate();
      toast.success("Logged to " + selectedMeal + "!");
    },
    onError: () => toast.error("Failed to log"),
  });

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500" />
              Favourites
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              Quick-log your most-eaten foods in one tap
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate("/search")}>
            <Search className="h-4 w-4 mr-1" />
            Find Foods
          </Button>
        </div>

        {/* Meal Selector */}
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <Zap className="h-4 w-4 text-amber-500 shrink-0" />
              <p className="text-sm font-medium">Log to:</p>
              <Select value={selectedMeal} onValueChange={(v) => setSelectedMeal(v as typeof selectedMeal)}>
                <SelectTrigger className="w-40 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MEAL_OPTIONS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">then tap any food below</p>
            </div>
          </CardContent>
        </Card>

        {/* Favourites List */}
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-20 bg-muted rounded-xl animate-pulse" />
            ))}
          </div>
        ) : favourites.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <Heart className="h-12 w-12 mx-auto mb-3 opacity-20 text-rose-400" />
              <p className="text-base font-medium text-foreground mb-1">No favourites yet</p>
              <p className="text-sm text-muted-foreground mb-4">
                Search for foods and tap the heart icon to save them here for quick logging.
              </p>
              <Button onClick={() => navigate("/search")}>
                <Search className="h-4 w-4 mr-2" />
                Search Foods
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {favourites.map((fav) => (
              <Card
                key={fav.favourite.id}
                className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer group"
                onClick={() => quickLogMutation.mutate({ productId: fav.favourite.productId, mealType: selectedMeal })}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    {/* Quick log indicator */}
                    <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center shrink-0 group-hover:bg-emerald-100 transition-colors">
                      <Plus className="h-5 w-5 text-emerald-600" />
                    </div>

                    {/* Product info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-foreground truncate">{fav.product.name}</p>
                        {fav.product.nutriScore && (
                          <NutriScoreBadge score={fav.product.nutriScore as "A" | "B" | "C" | "D" | "E"} size="sm" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {fav.product.brand && `${fav.product.brand} · `}
                        {fav.product.calories ? `${fav.product.calories} kcal/100g` : fav.product.category ?? ""}
                      </p>
                    </div>

                    {/* Remove button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-rose-500 shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeMutation.mutate({ productId: fav.favourite.productId });
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {favourites.length > 0 && (
          <p className="text-center text-xs text-muted-foreground pb-4">
            Tap any food card to instantly log it to {selectedMeal}
          </p>
        )}
      </div>
    </DashboardLayout>
  );
}
