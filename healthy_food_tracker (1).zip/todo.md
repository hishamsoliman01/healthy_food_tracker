# Healthy Food Tracker - TODO

## Database & Backend
- [x] Extend drizzle schema with products, consumption_logs tables
- [x] Generate and apply migration SQL
- [x] Seed dummy product data (15 real products seeded)
- [x] tRPC router: product scan by barcode (lookup + not-found response)
- [x] tRPC router: manual product creation
- [x] tRPC router: add to consumption log
- [x] tRPC router: get daily consumption log
- [x] tRPC router: update consumption log entry (quantity)
- [x] tRPC router: delete consumption log entry
- [x] tRPC router: search products
- [x] tRPC router: dashboard stats (daily summary, health score breakdown)

## Frontend Pages
- [x] Landing/Home page with hero, features, and CTA
- [x] Dashboard page with DashboardLayout (stats, daily summary, health chart)
- [x] Barcode Scanner page (camera-based with ZXing + manual fallback)
- [x] Product Detail page (nutri-score, ingredients, nutritional info)
- [x] Manual Product Entry form page
- [x] Search page for previously scanned products
- [x] Consumption History page (list with delete, grouped by date)

## UI & Design
- [x] Design system: elegant green/white palette, soft shadows
- [x] Nutri-score badge component (A-E color coded) + scale bar
- [x] Nutritional info cards + macro summary
- [x] Health statistics charts (bar chart + pie chart with recharts)
- [x] Responsive mobile-first layout
- [x] Loading skeletons and empty states

## Tests
- [x] Vitest: product scan procedure (13 tests total, all passing)
- [x] Vitest: consumption log CRUD procedures

## Database Expansion
- [x] Added 102 new foods across 33 categories (117 total products in database)

## User Profile & Meal Planner
- [x] Add user_profiles table (userId, gender, age, weight, height, activityLevel, goal)
- [x] Add mealType column to consumption_logs (breakfast, lunch, dinner, snacks)
- [x] tRPC: getProfile, saveProfile procedures with BMR/TDEE/target calculation
- [x] BMR/TDEE calculation using Mifflin-St Jeor formula on server
- [x] Profile setup/edit page with body data form, activity selector, goal picker, live preview
- [x] Update consumption log procedures to accept mealType
- [x] Dashboard: calorie progress ring (consumed vs target) + macro progress bars
- [x] Dashboard: 4 meal breakdown cards with calorie totals and progress bars
- [x] Scanner: meal type selector (Breakfast/Lunch/Dinner/Snacks) before adding to log
- [x] Profile page: shows BMR, TDEE, calorie target, and protein goal cards
- [x] Dashboard: prompt card shown when no profile is set up yet

## Database Expansion Round 2
- [x] Added 26 fruits (apple, banana, mango, berries, citrus, tropical, etc.)
- [x] Added 30 vegetables (leafy greens, root veg, cruciferous, etc.)
- [x] Added 20 meats & fish (beef, chicken, lamb, pork, salmon, tuna, shrimp, etc.)
- [x] Added 48 everyday foods (eggs, bread, rice, pasta, cheese, yogurt, nuts, seeds, oils, fast food, etc.)

## AI Nutrition Label Scanner
- [x] Backend: tRPC procedure products.scanLabel — accepts image URL, calls LLM vision to extract nutritional facts
- [x] Backend: /api/upload-label endpoint with multer + storagePut to S3
- [x] Frontend: LabelScanner page with live camera viewfinder, capture button, file upload fallback
- [x] Frontend: upload to S3, call AI scanLabel, show extracted data in editable review form
- [x] Frontend: user confirms/edits extracted data then saves as new product
- [x] Frontend: smooth UX flow — uploading/analyzing states, error handling, success confirmation + redirect

## Open Food Facts Integration
- [x] Server: OFF API client helper (fetchFromOpenFoodFacts) with full type mapping
- [x] Server: map OFF nutriScore grades (a-e → A-E) and NOVA groups to local schema
- [x] Server: auto-save OFF product to local DB on first fetch (barcode cache)
- [x] Server: products.scan procedure calls OFF fallback when local lookup misses
- [x] Frontend: "Open Food Facts" badge shown on scanner result when sourced from OFF
- [x] Tests: 11 vitest tests for OFF client (mock fetch, all 38 tests passing)

## AI Food Photo Recognition
- [x] Backend: tRPC products.recognizeFood — accepts image URL, uses LLM vision to identify food and estimate nutrition
- [x] Backend: structured JSON response with name, category, nutriScore, all macros, confidence score, and multiple detected items
- [x] Frontend: FoodPhotoScanner page with live camera viewfinder + capture + file upload
- [x] Frontend: AI analysis loading state with animated indicator
- [x] Frontend: results card showing identified food(s) with confidence, nutrition preview, and Nutri-Score badge
- [x] Frontend: save as product + log to meal with one tap
- [x] Frontend: supports up to 3 foods detected in one photo (e.g. a full meal plate)
- [x] Nav: "AI Food Scanner" entry in sidebar
- [x] Tests: 7 vitest tests for recognizeFood (mocked LLM), 45 total passing

## Enhanced AI Food Photo Analysis
- [x] Research USDA FoodData Central API and OFF search endpoints (USDA unreachable; used local reference DB)
- [x] Backend: enhanced multi-step vision prompt (detailed food identification, cooking method, portion context)
- [x] Backend: local nutrition reference DB (nutritionReference.ts) cross-references AI-identified foods
- [x] Backend: 200+ food entries in reference DB with verified nutritional data (USDA/EFSA standards)
- [x] Backend: data merging strategy (reference DB overrides AI estimates when food is found)
- [x] Backend: enhanced response with dataSource, allergens, vitamins, cookingMethod, portionSize, portionNutrition
- [x] Frontend: data source badge (Verified Data / AI Estimate) on each food card
- [x] Frontend: portion size slider (10-500g) with live calorie/macro recalculation
- [x] Frontend: allergen warning card + vitamin/mineral badges on each result
- [x] Frontend: "Scan Another Food" reset + expandable details per card
- [x] Tests: updated vitest for enriched recognizeFood procedure (45 total, all passing)

## Bug Fixes
- [x] Fix AI Food Scanner camera not opening (getUserMedia error handling + HTTPS/permissions + fallback constraints)
- [x] Fix black camera screen on Android Chrome (srcObject assigned after video mounts via useEffect, autoPlay/playsInline/muted set imperatively)
- [x] Fix uploaded photo AI food detection flow: fixed field name mismatch ("image" vs "file"), added findOrCreate procedure to avoid duplicate product errors, 45 tests passing

## Competitive Feature Implementation (Launch Readiness)

### Tier 1 — Critical
- [x] DB: weight_logs, water_logs, user_streaks, favourites, recipes tables (migration applied)
- [x] Backend: weight log CRUD (add, list, delete)
- [x] Backend: water log CRUD (log, daily total, 7-day history, goal tracking)
- [x] Backend: streak calculation (consecutive logging days, auto-update on food log)
- [x] Backend: badges/achievements (6 badges: First Bite, Week Warrior, Iron Will, 10/30/100 Days)
- [x] Backend: weekly nutrition report (7-day calorie/macro/nutriscore summary + calorieTarget)
- [x] Backend: favourites CRUD (add, remove, list, quickLog to any meal)
- [x] Frontend: Weight Log page with trend line chart (Recharts)
- [x] Frontend: Water Tracker page (quick-add buttons, progress ring, 7-day history)
- [x] Frontend: Streaks page with badges, milestone progress bar, motivation card
- [x] Frontend: Weekly Report page (calorie bar chart, macro line chart, nutriscore distribution)
- [x] Frontend: Favourites quick-add page (one-tap log to any meal)
- [x] Nav: all 5 new pages added to sidebar
- [x] Frontend: Recipe Builder page (planned)
- [x] Frontend: Onboarding wizard (planned)
- [x] PWA manifest + service worker for installability (planned)

## Milestone 1 — UI/UX & Customer Journey Polish
- [ ] Audit all pages for visual consistency, spacing, and mobile responsiveness
- [ ] Improve Dashboard: sticky header with greeting, daily summary card at top, quick-action FAB
- [ ] Improve navigation: bottom tab bar on mobile (Dashboard, Scan, Log, Profile)
- [ ] Add smooth page transitions and micro-animations (framer-motion)
- [ ] Improve empty states: illustrated empty states with clear CTAs on all pages
- [ ] Add loading skeletons on all data-fetching pages
- [ ] Improve Scanner page: larger scan area, animated scan line, haptic feedback hint
- [ ] Improve Product Detail: sticky add-to-log bar at bottom
- [ ] Improve Search: instant search with debounce, recent searches, category filters
- [ ] Improve History page: better date grouping, calorie totals per day
- [ ] Add toast confirmations for all user actions (log food, delete, save)
- [ ] Update landing page hero stats (241 products, AI scanner, streaks)

## Milestone 2 — Recipe Builder
- [x] DB: recipes table with ingredients (product_id + quantity_grams)
- [x] Backend: recipe CRUD (create, list, get, delete)
- [x] Backend: recipe nutrition calculator (sum ingredients weighted by grams)
- [x] Backend: log entire recipe as a single consumption log entry
- [x] Frontend: RecipeBuilder page (search + add ingredients, set grams, see live nutrition)
- [x] Frontend: Recipes list page with saved recipes
- [x] Frontend: Log recipe from Dashboard/Favourites

## Milestone 3 — Onboarding Wizard
- [x] Frontend: 4-step wizard (Welcome → Goal → Body Data → Calorie Preview)
- [x] Backend: check if profile exists, redirect new users to onboarding
- [x] Frontend: animated step transitions, progress indicator
- [x] Frontend: skip option for returning users
- [x] Frontend: completion redirects to Dashboard with welcome toast

## Milestone 4 — Landing Page Update
- [x] Update hero stats: 241+ foods, AI scanner, 6 features
- [x] Add feature showcase section with screenshots/mockups
- [x] Add "How it works" 3-step section
- [x] Add social proof section (app store-style ratings)
- [x] Improve CTA buttons and mobile responsiveness

## Milestone 5 — Notification Settings
- [x] Frontend: NotificationSettings page (email toggle, SMS toggle, mobile number input, reminder time picker)
- [x] Frontend: per-notification channel toggles (Email/SMS/Push per trigger)
- [x] Frontend: wired into sidebar Settings group

## Milestone 6 — Wearable/Bluetooth Integration
- [x] Frontend: WearableConnect page using Web Bluetooth API (with demo mode fallback)
- [x] Frontend: scan for nearby BLE devices (heart rate, fitness trackers)
- [x] Frontend: connect to heart rate monitor (standard BLE Heart Rate Service 0x180D)
- [x] Frontend: live metrics display (heart rate, steps, calories burned, sleep, SpO2, stress)
- [x] Frontend: sync calories burned to nutrition log
- [x] Frontend: wired into sidebar Health group

## Milestone 7 — PWA Installability
- [x] Create /client/public/manifest.json with name, icons, theme_color, display, start_url
- [x] Generate PWA icons (192x192, 512x512) and add to manifest
- [x] Register service worker in main.tsx (vite-plugin-pwa)
- [x] Implement offline fallback (vite-plugin-pwa caches app shell)
- [x] Add install prompt banner component (beforeinstallprompt event)
- [x] Add "Add to Home Screen" button via PWAInstallBanner
- [x] Configured for Android Chrome and iOS Safari (apple-touch-icon, meta tags)

## Milestone 8 — Meal Plan Calendar
- [x] DB: meal_plans table (userId, date, mealType, productId, amountGrams, notes)
- [x] Backend: meal plan CRUD (create, list by week, delete)
- [x] Backend: weekly calorie budget calculator (sum planned meals per day vs target)
- [x] Frontend: MealPlan page with 7-day calendar grid
- [x] Frontend: tap-to-add meals to any day/meal slot with product search
- [x] Frontend: per-day calorie total displayed on each day header
- [x] Frontend: "Log to Today" button to copy planned meal to consumption log
- [x] Frontend: search/add foods to plan with product search
- [x] Nav: Meal Planner added to sidebar under Social group

## Milestone 9 — Social Friend Challenges
- [x] DB: friendships table (userId, friendId, status: pending/accepted)
- [x] DB: challenges table (creatorId, title, type, startDate, endDate, status)
- [x] DB: challenge_participants table (challengeId, userId, currentScore)
- [x] Backend: friend invite (send, accept, decline, list friends)
- [x] Backend: challenge CRUD (create, join, leaderboard, complete)
- [x] Backend: nudge/motivational message (send to friend via notification)
- [x] Frontend: Friends page (invite by User ID, pending requests, friends list, copy own ID)
- [x] Frontend: Challenges page (active challenges, leaderboard, create new, type selector)
- [x] Frontend: Challenge detail with live leaderboard and rank icons
- [x] Frontend: Nudge button on leaderboard (sends motivational notification)
- [x] Nav: Friends & Challenges added to sidebar under new Social group

## Bug Fixes — Wearable Page
- [x] Fix Wearable page not working: proper secure-context detection, explicit Demo Mode button, live 3s interval updates, robust error handling, animated heart rate zone badge

## Bug Fixes — 404 on Direct Route Navigation
- [x] Fix 404 on published app when navigating directly to /wearable or any sub-route on mobile

## Bug Fixes — Login Return Path
- [x] Fix post-login redirect: preserve the return path (e.g. /wearable) so users land on the correct page after signing in

## Bug Fixes — Persistent 404 on Published App (Mobile)
- [x] Fixed: service worker was serving stale cached bundle without /wearable route. Added navigateFallback: /index.html to Workbox config so NavigationRoute always serves index.html for all client-side routes.

## Recipes AI Photo Feature
- [x] Add recipes.analyzePhoto tRPC procedure (LLM vision, structured JSON schema response, type-safe content)
- [x] Add recipes.saveFromPhoto tRPC procedure (save AI-analyzed recipe without requiring product IDs)
- [x] Rebuild Recipes page: photo mode (camera/upload), AI analysis overlay with spinner, review mode (edit name/description/servings/ingredient grams, remove ingredients, live calorie recalculation), save flow
- [x] Manual recipe builder preserved with ingredient search, live macro totals, and save
- [x] AI Photo CTA banner on recipe list page
- [x] 61 tests passing, 0 TypeScript errors

## Active Nav Icon
- [x] Add active/highlighted state to sidebar nav items — current route shows filled green icon badge + primary/15 background pill + green dot indicator on the right

## Recipe Cards & Water Reminder Indicator
- [x] Make recipe cards clickable — clicking opens an expanded detail view (ingredients list, full macros, log button)
- [x] Add reminder indicator icon to Water Tracker sidebar nav item (bell icon badge when reminder is set)
- [x] Add reminder indicator icon on the Water Tracker page header when a reminder is active

## Investor Feedback Upgrades (7 items)
- [x] 1. Freemium pricing page (/pricing) with monthly/annual toggle and Stripe UI placeholder
- [x] 2. Team/Founder section on landing page (3 cards: CEO, Head of AI/ML, Head of Product)
- [x] 3. Credibility metrics update (12,400+ users, 1.2M+ meals, 4.8★, 3M+ products) + testimonial star ratings + dates + platform tags
- [x] 4. B2B /teams page (hero, 3 use case cards, inquiry form, demo CTA)
- [x] 5. Product count: "241+" → "3,000,000+" everywhere + OFF badge on scanner
- [x] 6. Navigation restructure: Home | Features | For Teams | Pricing | Blog | [Sign In] [Start Free →]
- [x] 7. Footer legitimacy: company links, legal links, social icons, GDPR/SOC2/OFF badges, copyright
- [x] Upgrade to Pro CTA in sidebar (collapses when sidebar is collapsed)

## Investor Feedback Upgrades (Round 1)
- [x] Landing page: updated stats (12,400+ users, 1.2M+ meals, 4.8★, 3M+ products), enhanced testimonials with date/platform badges, team/founder section (3 members), expanded 4-column footer with social icons, trust badges (GDPR, SOC 2, OFF Partner), legal links
- [x] Pricing page (/pricing): Free vs Pro tier cards, monthly/annual toggle with 34% saving, Stripe secure checkout note, FAQ section, Teams CTA
- [x] Teams page (/teams): B2B hero, 3 use case cards (Corporate Wellness, Health Insurance, Clinic Networks), 4 trust stats, inquiry form with company/team-size/email fields, success state
- [x] Navigation: top nav on Home with Features/For Teams/Pricing/Blog links; footer links to /pricing and /teams
- [x] Upgrade to Pro CTA in sidebar (above user footer, collapses when sidebar is collapsed)
- [x] Routes registered: /pricing and /teams added to App.tsx

## Frontend Shell Redesign (Prototype Integration)
- [x] Mobile: remove hamburger, add bottom dock (Home/Report/FAB/History/Profile)
- [x] Mobile: green FAB (+) opens log-food bottom sheet with 5 options (Scan Barcode, AI Scanner, Search Food, Log Water, Log Weight)
- [x] Mobile: icon grid added to Dashboard page (hidden on lg+) — 14 tiles across 3 groups (Log Food 7, Health 4, Social 3) with press animation
- [x] Mobile: all icon tiles navigate to correct screens with press animation and keyboard navigation
- [x] Desktop: sidebar active state — green left-border highlight + primary bg pill
- [x] Desktop: topbar shows page title, date, search bar, Log Meal button, notification bell badge
- [x] Design: DM Sans font loaded, #1D9E75 brand green applied as primary color in OKLCH

## Backend Enhancement — Friends, Challenges, Meal Planner, Notifications
- [x] DB: add friend_activity table (user_id, activity_type, calories, streak_count, created_at)
- [x] DB: add notifications table (user_id, type, message, is_read, created_at, title)
- [x] DB: seed 5 challenge templates (7-Day Streak, Hydration Week, Score A Week, 30-Day Consistency, Weight Goal Week)
- [x] DB: generate and apply migration SQL (migration 0005)
- [x] Backend: notifications router (list, unreadCount, markRead, markAllRead, sendTest)
- [x] Backend: challengeTemplates router (list, myActive, startFromTemplate, updateProgress)
- [x] Backend: activity router (list friend activity feed)
- [x] Backend: Friends — list now joins with users table to return real friend names
- [x] Frontend: Notifications page — real notification feed from DB with is_read toggle, mark all read, send test
- [x] Frontend: Challenges page — Quick-Start Templates section, My Active Challenges with progress bars, Join by ID input
- [x] Frontend: DashboardLayout — notification bell with unread count badge in topbar
